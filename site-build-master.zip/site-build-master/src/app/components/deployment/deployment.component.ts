import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DataService } from '../../services/data.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-deployment',
  templateUrl: './deployment.component.html',
  styleUrls: ['./deployment.component.css']
})
export class DeploymentComponent implements OnInit {

  selectedDeploymentDate = 'current';
  finalDate;
  varDate = null;
  element;
  previousDeployment = null;
  dateRangeStart;
  dateRangeEnd;

  constructor(
    private dialog: MatDialog,
    private dataService: DataService
  ) { }

  ngOnInit(): void {
    if (this.selectedDeploymentDate === 'current') {
      this.finalDate = new Date();
    }
    if (this.selectedDeploymentDate === 'customRange') {
      this.dateRangeEnd = new Date();
      this.dateRangeStart = 0;
    }
    this.dataService.getDeploymentStatus().subscribe((response) => {
      console.log("Responses: ", response);
      this.previousDeployment = response;
      this.previousDeployment.PUBLISHED_ON = new Date(this.previousDeployment.PUBLISHED_ON);
    });
  }

  changeEnvironmentRadio(event) {
    this.selectedDeploymentDate = event.value;
    if (this.selectedDeploymentDate === 'current') {
      this.finalDate = new Date();
    }
  }

  dateChanged(event) {
    console.log('Date changed: ', event);    
  }


  displayDate() {
    console.log(`Date: ${this.varDate}`);
  }

  submitInformation() {
    let date;
    let dateStart;
    if (this.selectedDeploymentDate === 'current') {
      this.finalDate = new Date();
    }
    date = new Date(this.finalDate);
    if (this.selectedDeploymentDate === 'customRange') {
      date = new Date(this.dateRangeEnd);
      dateStart = new Date(this.dateRangeStart);
    } else {
      dateStart = this.previousDeployment ? this.previousDeployment.PUBLISHED_ON : 'No Previous Deployment Found';
    }
    console.log("Date: ", date.getDay(), date.getDate(), date.getMonth()+1, date.getFullYear(), date.getMinutes(), date.getHours());

    const dateObject = {
      year: date.getFullYear(),
      month: date.getMonth()+1,
      date: date.getDate(),
      hour: date.getHours(),
      minute: date.getMinutes()
    };

    const dialogRef = this.dialog.open(PopUpComponent, {
      maxWidth: '850px',
      maxHeight: '350px',
      autoFocus: false,
      data: { dateEnd: date, selectionType: this.selectedDeploymentDate, dateStart: dateStart }
    });

    const updateObject = {
      currentDate: dateObject,
      previousDate: this.previousDeployment ? this.previousDeployment.PUBLISHED_ON : 'No Previous Deployment Found',
      previousDateTimestamp: this.previousDeployment ? this.previousDeployment.PUBLISHED_ON_TIMESTAMP : 'No Previous Deployment Found'
    }

    if (this.selectedDeploymentDate === 'customRange') {
      updateObject.previousDate = this.dateRangeStart;
      updateObject.previousDateTimestamp = Date.parse(this.dateRangeStart);
    }

    dialogRef.afterClosed().subscribe((result) => {
      console.log("Result: ", result);
      if (result.submitted) {
        this.dataService.updateDeploymentDate(updateObject).subscribe((result) => {
          console.log("Result from server: ", result);
          if(result){
            Swal.fire({
              icon: 'success',
              title: 'Updated Deployment Status',
              showConfirmButton: false,
              timer: 3000
            }).then(()=>{
                location.reload();
            });
          } else {
            Swal.fire({
              icon: 'error',
              title: 'Error In Updating Deployment Status',
              timer: 3000
            })
          }
        });
      }
    });
  }

}

export interface DialogData {
  dateEnd: Date, 
  selectionType: string, 
  dateStart: Date
}
@Component({
  selector: 'pop-up',
  template: `<div>
    <div>
      <h3>Selected deployment time</h3>
      Previous Deployment Date: <b>{{dateStart}}</b><br>
      Current Deployment Date: <b>{{dateEnd}}</b><br>
    </div><br> 
    <div>
      <span (click)="onButtonClick(true)"><button mat-flat-button color="primary">Submit</button></span>
      <span style="margin-left: 5px" (click)="onButtonClick(false)"><button mat-flat-button color="accent">Cancel</button></span>
    </div>
  </div>`
})
export class PopUpComponent implements OnInit {

  dateStart;
  dateEnd;
  type = 'current';

  ngOnInit(): void {
    // if (this.data.selectionType === 'customRange') {
    // }
    this.dateStart = this.data.dateStart
    this.dateEnd = this.data.dateEnd;
  };
  constructor(public dialogRef: MatDialogRef<PopUpComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData){}


  onButtonClick(val) {
    this.dialogRef.close({ submitted: val });
  }
}
