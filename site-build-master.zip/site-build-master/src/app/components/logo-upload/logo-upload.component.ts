import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { SharedDataService } from '../../services/shared-data.service';

@Component({
  selector: 'app-logo-upload',
  templateUrl: './logo-upload.component.html',
  styleUrls: ['./logo-upload.component.css']
})
export class LogoUploadComponent implements OnInit {

  constructor(private sharedDataService: SharedDataService) { }

  @Input('siteName') siteName = '';
  @Input('inPreviewPage') isPreviewPage;
  @Output() smallLogoUrl = new EventEmitter<any>();
  @Output() largeLogoUrl = new EventEmitter<any>();
  fileList1: string[];

  setFileList(event: FileList) {
    console.log(event);
    this.fileList1 = Array.from(event).map(f => f.name);
  }

  logoStatus = false;

  smallLogoProgress;
  largeLogoProgress;

  ngOnInit(): void {
    this.getUpdatedHighlightStatus();
    this.sharedDataService.getLargeLogoStatus().subscribe((res) => {
      this.largeLogoProgress = res;
    })
    this.sharedDataService.getSmallLogoStatus().subscribe((res) => {
      this.smallLogoProgress = res;
    });
  }

  emitSmallLogoURL(obj) {
    this.smallLogoUrl.emit(obj);
  }
  emitLargeLogoURL(obj) {
    this.largeLogoUrl.emit(obj);
  }

  getUpdatedHighlightStatus() {
    let highlights = null;
    this.sharedDataService.highlightsObservables.subscribe((result) => {
      highlights = result;
      let smallLogoStatus;
      let largeLogoStatus;

      if (highlights) {
        smallLogoStatus = highlights['small_logo'];
        largeLogoStatus = highlights['large_logo'];
      }

      if (smallLogoStatus || largeLogoStatus) {
        this.logoStatus = true;
      }
    });
  }

}
