import { Component, Input, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { DataService } from '../../services/data.service';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { SharedDataService } from '../../services/shared-data.service';
import { EnvironmentService } from '../../services/common/environment.service';
import { MatAccordion } from '@angular/material/expansion';
import { SiteCreatePageComponent } from '../../pages/site-create-page/site-create-page.component';

@Component({
  selector: 'app-site-build-details',
  templateUrl: './site-build-details.component.html',
  styleUrls: ['./site-build-details.component.css']
})
export class SiteBuildDetailsComponent implements OnInit {

  @Input('apiResult') result;
  @Input('disableInputs') disableInputs = false;
  @Input('expandAll') expandAllFromParent = false;
  @Input('showSubmitButtons') showSubmitButtons = false;
  @Input('draftConfigs') draftConfigs = false;
  @Input('configChanges') configChanges = false;
  @Input('siteName') siteName = '';
  @ViewChild(MatAccordion) accordion: MatAccordion;
  
  form: FormGroup;

  constructor(private sharedDataService: SharedDataService, formBuilder: FormBuilder, private envService: EnvironmentService, private siteCreateComponent: SiteCreatePageComponent) {
    this.form = formBuilder.group(this.formGroupObject);
    this.checkedList = [];
  }

  siteUrl = this.envService.getAbsoluteUrl();

  loading =  true;
  apiResult = null;
  configData = null;
  configSchema = null;
  siteId = null;

  configKeysArray = [];
  configsFieldsMap = new Map();
  configsDataMap = {};

  formGroupObject = {};

  checking = 'dummyData';
  showDropDown = false;

  checkedList : any[];
  currentSelected : {};

  languageList = [];
  languageListCodes = [];
  selectedLanguageList = [];
  selectedLanguageListCodes = [];
  toggledDefaultLanguages = [];
  highlightedSiteConfigs: any = {};

  fields = ['SiteURL', 'HomeStyle', 'silent_logon', 'Media','EnableDashboardManager', 'BulkloadGateway', 'CourseAICC', 'DriveAssignment', 'CourseListID', 'HidePrivacyStatement', 'EnableDMARCDomains'];

  readOnlyFields = ['SiteURL', 'ProfileColumn'];

  generalInfoArray = [];
  toolsControlArray = [];
  bulkloadManagementArray = [];
  securityArray = [];
  LMSIntegrationArray = [];
  moduleSettingsArray = [];
  siteAppConfigSchema: any;

  generalInfoArrayIndex = 0;
  toolsControlArrayIndex = null;
  bulkloadManagementArrayIndex = null;
  securityArrayIndex = null;
  LMSIntegrationArrayIndex = null;
  moduleSettingsArrayIndex = null;
  indexesArray = [];

  isInternationalSite = null;

  items = ['General Info', 'Tool Control', 'BulkLoad Management', 'Security', 'LMS Integration', 'Module Settings'];
  expandedIndex = 0;
  itemsArray = [];
  generalInfoAccordion = null;
  toolsControlAccordion = null;
  bulkloadManagementAccordion = null;
  securityAccordion = null;
  LMSIntegrationAccordion = null;
  moduleSettingsAccordion = null;
  accordionIndexes = [];
  accordionsExpanded = false;
  latestAuditLog = null;
  latestAuditUsername = '';
  latestAuditTimestamp = '';
  isCurrentConfigStatusDraft = null;
  userDataFieldSyncStatus = false;
  configsFromDraft = [];

  ngOnInit(): void {
    this.generalInfoAccordion = false;
    this.toolsControlAccordion = false;
    this.bulkloadManagementAccordion = false;
    this.securityAccordion = false;
    this.LMSIntegrationAccordion = false;
    this.moduleSettingsAccordion = false;
    this.accordionIndexes = [
      this.generalInfoAccordion,
      this.toolsControlAccordion,
      this.bulkloadManagementAccordion,
      this.securityAccordion,
      this.LMSIntegrationAccordion,
      this.moduleSettingsAccordion
    ]
    if (this.expandAllFromParent) {
      this.openAllAccordions();
      if (this.accordion) {
        this.accordion.openAll();
      }
    }
    if (this.result) {
      this.configData = this.result['data'].site_configs;
      if (this.siteUrl.includes('internal.catalyst')) {
        this.siteUrl = this.siteUrl.replace('internal', this.siteName ? this.siteName : 'internal');
      }
      this.configData['SiteURL'] = this.siteUrl;
      this.loading = false;
      if (!this.disableInputs) {
        this.sharedDataService.getConfigSchemaData().next(this.configData);
      }
      if (this.showSubmitButtons) {
        this.sharedDataService.getSiteConfigDraftChanges().subscribe((res2) => {
          this.configsFromDraft = res2 as unknown as [];
        });
      }
    }
    if (this.showSubmitButtons) {
      this.sharedDataService.getSiteConfigDraftChanges().subscribe((res2) => {
        this.configsFromDraft = res2 as unknown as [];
      });
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes && changes.siteName) {
      this.siteName = changes.siteName.currentValue;
      if (this.siteUrl.includes('internal.catalyst')) {
        this.siteUrl = this.siteUrl.replace('internal', this.siteName ? this.siteName : 'internal');
      }
      if (this.configData) {
        this.configData['SiteURL'] = this.siteUrl;
      }
    }
    if (changes.result && changes.result.currentValue !== null && changes.result.currentValue.schema && changes.result.currentValue.data) {
      this.loading = false;
      this.apiResult = changes.result.currentValue;
      this.configSchema = this.apiResult.schema.properties.site_configs.properties;
      this.configData = this.apiResult.data.site_configs;
      this.siteId = this.sharedDataService.getSiteId();
      this.isCurrentConfigStatusDraft = this.apiResult.status === 'DRAFT';
      this.userDataFieldSyncStatus = this.apiResult.userFieldSyncStatus;
      this.formatSchema(this.configSchema);
      // this.toggleInternational(this.configData["internationalize_site"], 0, 2);

      Object.keys(this.configSchema).forEach(key => {
        this.configKeysArray.push(key);
      });

      if (!this.configData) {
        this.configData = this.result.data.site_configs;
      }
      this.configData['SiteURL'] = this.siteUrl;
      this.configData['internationalize_site'] = (this.configData.ProfileColumn === 'Language') ? true : false;

      let languageDropdown = null;
      this.getLanguagesFromSchema(this.configSchema['DefaultLanguage'].enum);
      if (this.apiResult.data.user_configs) {
        if (this.apiResult.data.user_configs && this.apiResult.data.user_configs['custom_field']) {
          if (this.apiResult.data.user_configs['custom_field'].length > 0) {
            this.getLanguagesFromUserData(this.apiResult.data.user_configs['custom_field'][this.apiResult.data.user_configs['custom_field'].length-1]['DROPDOWN_ENUM']);
            languageDropdown = this.apiResult.data.user_configs['custom_field'][this.apiResult.data.user_configs['custom_field'].length-1]['DROPDOWN_ENUM'];
          }
        } else {
          if (this.apiResult.data.user_configs['Language']) {
            this.getLanguagesFromUserData(this.apiResult.data.user_configs['Language']['DROPDOWN_ENUM']);
            languageDropdown = this.apiResult.data.user_configs['Language']['DROPDOWN_ENUM'];
          }
        }
      }

      if (!this.disableInputs) {
        if (!this.configData['internationalize_site']) {
          this.toggleLanguageFields(false, this.configKeysArray.indexOf('internationalize_site'));
        }
      }
      this.createConfigMap(this.configKeysArray);
      if (!this.disableInputs) {
        this.sharedDataService.getConfigSchemaData().next(this.configData);
      }
      if (languageDropdown && !languageDropdown.includes(this.configData.DefaultLanguage)) {
        let dropdownValue = this.configData && this.configData.DefaultLanguage ?  this.selectLanguageToggle({ checked: true }, this.configData.DefaultLanguage.split(" - ")[1].trim()) : "English - en";
        if (this.apiResult.data.user_configs['Language']) {
          this.apiResult.data.user_configs['Language']['DROPDOWN_ENUM'] = dropdownValue;
        }
        if (this.apiResult.data.user_configs && this.apiResult.data.user_configs['custom_field'] && this.apiResult.data.user_configs['custom_field'].length > 0) {
          if (this.apiResult.data.user_configs['custom_field'][this.apiResult.data.user_configs['custom_field'].length-1]['COLUMN_NAME'] === 'Language') {
            this.apiResult.data.user_configs['custom_field'][this.apiResult.data.user_configs['custom_field'].length-1]['DROPDOWN_ENUM'] = dropdownValue;
            this.sharedDataService.getUserSchemaData().next(this.apiResult.data.user_configs);
          }
        }
      } else if (!languageDropdown) {
        if (this.apiResult.data.user_configs['Language']) {
          this.apiResult.data.user_configs['Language']['DROPDOWN_ENUM'] = "English - en";
        }
        if (this.apiResult.data.user_configs && this.apiResult.data.user_configs['custom_field'] && this.apiResult.data.user_configs['custom_field'].length > 0) {
          if (this.apiResult.data.user_configs['custom_field'][this.apiResult.data.user_configs['custom_field'].length-1]['COLUMN_NAME'] === 'Language') {
            this.apiResult.data.user_configs['custom_field'][this.apiResult.data.user_configs['custom_field'].length-1]['DROPDOWN_ENUM'] = "English - en";
            this.sharedDataService.getUserSchemaData().next(this.apiResult.data.user_configs);
          }
        }
        this.selectedLanguageListCodes.push("en");
      }

      if (this.showSubmitButtons) {
        this.sharedDataService.getSiteConfigDraftChanges().subscribe((res2) => {
          this.configsFromDraft = res2 as unknown as [];
        });
      } else {
        let tempChanges = [];
        Object.keys(this.configChanges['site_configs']).forEach((eachVal) => {
          tempChanges.push(eachVal);
        });
        this.configsFromDraft = tempChanges;
      }

      this.highlightedSiteConfigs = this.sharedDataService.getAuditLogsHighlights();
      this.highlightedSiteConfigs = this.highlightedSiteConfigs.site_configs;
      this.latestAuditLog = this.sharedDataService.getLatestAuditLog();
      let latestLogFromLocalStorage = JSON.parse(localStorage.getItem('latestLog'));
      this.latestAuditUsername = this.latestAuditLog && this.latestAuditLog.USER_NAME ? this.latestAuditLog.USER_NAME : 
                                 latestLogFromLocalStorage && latestLogFromLocalStorage.userName ? latestLogFromLocalStorage.userName :'LRN User';
      this.latestAuditTimestamp = this.latestAuditLog && this.latestAuditLog.TIMESTAMP ? ` on ${this.latestAuditLog.TIMESTAMP}` : 
                                  latestLogFromLocalStorage && latestLogFromLocalStorage.timestamp ? ` on ${latestLogFromLocalStorage.timestamp}` : '';
      console.log('Latest audit log details: ', this.latestAuditLog, latestLogFromLocalStorage, this.latestAuditUsername, this.latestAuditTimestamp);
    }
  }


  formatSchema(site_configs) {
    this.toolsControlArray = [];
    this.generalInfoArray = [];
    this.bulkloadManagementArray = [];
    this.securityArray = [];
    this.LMSIntegrationArray = [];
    this.moduleSettingsArray = [];
    Object.keys(site_configs).forEach((key) => {
      if (key && site_configs[key] && key !== 'ProfileColumn') {
        site_configs[key]['id'] = key;
        site_configs[key]['value'] = this.configData[key];
        switch(site_configs[key].tag){
            case 'generalInfo' :
                this.generalInfoArray.push(site_configs[key]);
                break;
            case 'toolsControl':
                if (this.configData['ProfileColumn'] === 'Language') {
                  if (key !== 'ProfileColumn') {
                    this.toolsControlArray.push(site_configs[key]);
                  }
                } else {
                  if (key !== 'DefaultLanguage' && key !== 'ProfileColumn') {
                    this.toolsControlArray.push(site_configs[key]);
                  }
                }
                this.toolsControlArrayIndex = this.generalInfoArray.length + this.generalInfoArrayIndex;
                break;
            case 'bulkloadManagement':
                this.bulkloadManagementArray.push(site_configs[key]);
                this.bulkloadManagementArrayIndex = this.toolsControlArray.length + this.toolsControlArrayIndex;
                break;
            case 'security':
                this.securityArray.push(site_configs[key]);
                this.securityArrayIndex = this.bulkloadManagementArray.length + this.bulkloadManagementArrayIndex;
                break;
            case 'LMSIntegration':
                this.LMSIntegrationArray.push(site_configs[key]);
                this.LMSIntegrationArrayIndex = this.securityArray.length + this.securityArrayIndex;
                break;
            case 'moduleSettings':
                this.moduleSettingsArray.push(site_configs[key]);
                this.moduleSettingsArrayIndex = this.LMSIntegrationArray.length + this.LMSIntegrationArrayIndex;
                break;
        }
      }
    })
    this.toolsControlArray = this.toolsControlArray.filter(e => e !== null);
    this.itemsArray = [this.generalInfoArray, this.toolsControlArray, this.bulkloadManagementArray, this.securityArray, this.LMSIntegrationArray, this.moduleSettingsArray];
    this.indexesArray = [this.generalInfoArrayIndex, this.toolsControlArrayIndex, this.bulkloadManagementArrayIndex, this.securityArrayIndex, this.LMSIntegrationArrayIndex, this.moduleSettingsArrayIndex];
  }
  selectLanguageToggle(event, language) {
    this.selectedLanguageListCodes = this.selectedLanguageListCodes.filter(code => code !== undefined);
    this.selectedLanguageListCodes = this.selectedLanguageListCodes.map(code => {
      return code.replace(/"|\ /g,'');
    });
    if (event.checked) {
      this.selectedLanguageListCodes.push(language);
    } else {
      this.selectedLanguageListCodes = this.selectedLanguageListCodes.filter((lang) => lang !== language);
    }
    this.selectedLanguageListCodes = [...new Set(this.selectedLanguageListCodes)];
    this.selectedLanguageListCodes.sort();
    let dropdownStr = '';
    if (this.selectedLanguageListCodes.length > 0) {
      this.selectedLanguageListCodes.forEach(eachLang => {
        dropdownStr += `"${this.languageList[eachLang]} - ${eachLang}", `;
      });
      dropdownStr = dropdownStr.substring(0, dropdownStr.length - 2);
    }
    this.sharedDataService.getLanguageArray().next(dropdownStr);
    return dropdownStr;
  }

  getLanguagesFromUserData(dropdownVal) {
    if (dropdownVal) {
      const languages = dropdownVal.split(", ");
      languages.push("English - en");
      languages.forEach(eachLanguage => {
        this.selectedLanguageList.push({
          code: eachLanguage.split(" - ")[1],
          label: eachLanguage.split(" - ")[0]
        });
        this.selectedLanguageListCodes.push(eachLanguage.split(" - ")[1]);
      });
      console.log("getLanguagesFromUserData", this.selectedLanguageListCodes)
      this.selectedLanguageListCodes.sort();
    } else {
      this.selectedLanguageListCodes.push("en");
    }
    this.selectedLanguageListCodes = [...new Set(this.selectedLanguageListCodes)];
    this.selectedLanguageListCodes = this.selectedLanguageListCodes.filter(code => code !== undefined);
    this.selectedLanguageListCodes = this.selectedLanguageListCodes.map(code => {
      return code.replace(/"|\ /g,'');
    });
  };

  getLanguagesFromSchema(languageArray) {
    languageArray.forEach(eachLanguage => {
      this.languageList[eachLanguage.split(" - ")[1]] = eachLanguage.split(" - ")[0];
      this.languageListCodes.push(eachLanguage.split(" - ")[1]);
    });
  }

  expandAll(event) {
    for(let i in this.accordionIndexes) {
      if(event.checked) {
        this.accordionIndexes[i] = true;
      } else {
        this.accordionIndexes[i] = false;
      }
    }
  }

  isAllAccordionsExpanded(){
    for(let i in this.accordionIndexes) {
      if(this.accordionIndexes[i] === true){
        this.accordionsExpanded = true;
      } else {
        this.accordionsExpanded = false;
        return;
      }
    }
  }

  openAllAccordions() {
    for(let i in this.accordionIndexes) {
      this.accordionsExpanded = true;
    }
  }

  toggleExpandAll(event) {
    this.isAllAccordionsExpanded();
    if (event.checked) {
      this.accordion.openAll();
      this.accordionsExpanded = true;
      for(let i in this.accordionIndexes) {
        this.accordionIndexes[i] = this.accordionsExpanded;
      }
    } else {
      this.accordion.closeAll();
      this.accordionsExpanded = false;
      for(let i in this.accordionIndexes) {
        this.accordionIndexes[i] = this.accordionsExpanded;
      }
    }
  }

  createConfigMap(configKeysArray) {
    configKeysArray.forEach(key => {
      this.configsFieldsMap.set(key, this.configSchema[key].type);
      this.configsDataMap[key] = this.configData[key];
      this.formGroupObject[key] = new FormControl(this.configData[key]);
    });
  }

  getSelectedValue(status: Boolean, value: String) {
    if (status) {
      this.checkedList.push(value);
    } else {
      var index = this.checkedList.indexOf(value);
      this.checkedList.splice(index, 1);
    }
    this.sharedDataService.getLanguageArray().next(this.checkedList.join(', '));
    this.currentSelected = { checked: status, name: value };
  }

  toggleLanguageFields(toggle, index) {
    let languageFields = ['ProfileColumn', 'DefaultLanguage'];
    if (!toggle) {
      languageFields.forEach(field => {
        let localIndex = this.configKeysArray.indexOf(field);
        this.configKeysArray.splice(localIndex, 1);
        localIndex++;
      });
    } else {
      let localIndex = index;
      languageFields.forEach(field => {
        if (!this.configKeysArray.includes(field)) {
          this.configKeysArray.splice(localIndex+1, 0, field);
        }
        localIndex++;
      });
    }
    this.createConfigMap(this.configKeysArray);
  }

  checkForLanguageFieldInCustomFields() {
    let languagePresent = false;
    const customFields = this.apiResult.data.user_configs['custom_field'];
    customFields.forEach(eachField => {
      if (eachField['DISPLAY_NAME'] === 'Language') {
        languagePresent = true;
      }
    });
    return languagePresent;
  }

  toggle(event, key?:string, data?:string){
    if (key === 'internationalize_site') {
      if ((this.configData['internationalize_site'] === false || this.configData['internationalize_site'] === null) && event.checked === true && this.checkForLanguageFieldInCustomFields()) {
        alert(`Language already present in User Data Fields, you cannot enable internationalization, please change the existing field first`);
        this.configData['internationalize_site'] = this.configData['internationalize_site'] === false ? null : false;
        this.configData['ProfileColumn'] = null;
        this.configData['DefaultLanguage'] = "English - en";
        return;
      }
    }

    if (key === 'DefaultLanguage') {
      const selectedDefaultLanguage = event.value.split("-")[1].trim();
      const object = {
        code: `${event.value.split("-")[1].trim()}`,
        label: `${event.value.split("-")[0].trim()}`
      };
      let languageExistsFromTheBeginning = false;
      this.selectedLanguageList.forEach(eachObject => {
        if (JSON.stringify(eachObject) === JSON.stringify(object)) {
          languageExistsFromTheBeginning = true;
        }
      });
      if (!languageExistsFromTheBeginning) {
        if (!this.selectedLanguageListCodes.includes(selectedDefaultLanguage)) {
          this.selectLanguageToggle({ checked: false }, this.toggledDefaultLanguages.pop());
          this.selectLanguageToggle({ checked: true }, selectedDefaultLanguage);
          this.toggledDefaultLanguages.push(selectedDefaultLanguage);
        }
      } else {
        if (this.selectedLanguageListCodes.includes(selectedDefaultLanguage)) {
          this.selectLanguageToggle({ checked: false}, this.toggledDefaultLanguages.pop());
          this.selectLanguageToggle({ checked: true }, selectedDefaultLanguage);
        }
      }
    }

    if (event.type === 'input') {
      this.configData[key] = data;
    } else if (event.checked === true || event.checked === false) {
      this.configData[key] = event.checked;
    } else if (event.source.controlType === 'mat-select') {
      this.configData[key] = event.value;
    }
    if (key === 'internationalize_site') {
      const index = this.configKeysArray.indexOf('internationalize_site');
      if (this.configData['internationalize_site']) {
        this.toggleLanguageFields(true, index);
        this.configData['ProfileColumn'] = 'Language';
        this.configData['DefaultLanguage'] = "English - en";
      } else {
        this.toggleLanguageFields(false, index);
        this.configData['ProfileColumn'] = null;
        this.configData['DefaultLanguage'] = "English - en";
      }
    }
    if(!this.disableInputs) {
      this.sharedDataService.getConfigSchemaData().next(this.configData);
    }
  }

  toggleInternational(obj, incrementIndex, decrementIndex) {
    this.isInternationalSite = obj;
    if(!this.isInternationalSite) {
      this.bulkloadManagementArrayIndex = this.bulkloadManagementArrayIndex - decrementIndex;
      this.securityArrayIndex = this.securityArrayIndex - decrementIndex;
      this.LMSIntegrationArrayIndex = this.LMSIntegrationArrayIndex - decrementIndex;
      this.moduleSettingsArrayIndex = this.moduleSettingsArrayIndex - decrementIndex;
      this.indexesArray = [this.generalInfoArrayIndex, this.toolsControlArrayIndex, this.bulkloadManagementArrayIndex, this.securityArrayIndex, this.LMSIntegrationArrayIndex, this.moduleSettingsArrayIndex];
    } 
    if(this.isInternationalSite) {
      this.bulkloadManagementArrayIndex = this.bulkloadManagementArrayIndex + incrementIndex;
      this.securityArrayIndex = this.securityArrayIndex + incrementIndex;
      this.LMSIntegrationArrayIndex = this.LMSIntegrationArrayIndex + incrementIndex;
      this.moduleSettingsArrayIndex = this.moduleSettingsArrayIndex + incrementIndex;
      this.indexesArray = [this.generalInfoArrayIndex, this.toolsControlArrayIndex, this.bulkloadManagementArrayIndex, this.securityArrayIndex, this.LMSIntegrationArrayIndex, this.moduleSettingsArrayIndex];
    }
  }

  submitForm(status) {
    this.siteCreateComponent.submitForm(status);
  }


}
