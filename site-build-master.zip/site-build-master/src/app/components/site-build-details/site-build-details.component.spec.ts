import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteBuildDetailsComponent } from './site-build-details.component';

describe('SiteBuildDetailsComponent', () => {
  let component: SiteBuildDetailsComponent;
  let fixture: ComponentFixture<SiteBuildDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SiteBuildDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteBuildDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
