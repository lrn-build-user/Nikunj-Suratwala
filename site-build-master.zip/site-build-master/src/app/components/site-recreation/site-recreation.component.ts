import { Component, OnInit, ViewChild } from '@angular/core';
import { EnvironmentService } from '../../services/common/environment.service';
import { DataService } from '../../services/data.service';
import { FormControl, Validators } from '@angular/forms';
import { MatStepper } from '@angular/material/stepper';
import Swal from 'sweetalert2';
import { Router } from '@angular/router'
import { Observable } from 'rxjs/internal/Observable';
import { map, startWith } from 'rxjs/operators';
@Component({
  selector: 'app-site-recreation',
  templateUrl: './site-recreation.component.html',
  styleUrls: ['./site-recreation.component.css']
})

export class SiteRecreationComponent implements OnInit {

  constructor(private envService: EnvironmentService,
    private dataService : DataService,
    private router : Router) { }
    @ViewChild('stepper') stepper: MatStepper;
  siteControl = new FormControl('', Validators.required)

  isInternalSite = false;
  inActiveSitesListUS = [];
  inActiveSitesListEU = [];
  isSiteSelected = false;
  selectedSite = null;
  inActiveSitesFetched = false;
  isLinear = true
  siteStatusUpdated = false;
  siteName = '';

  selectedEnvironment = 'US';

  myControlUS = new FormControl();
  myControlEU = new FormControl();
  optionsUS: string[] = [];
  optionsEU: string[] = [];
  filteredOptionsUS: Observable<string[]>;
  filteredOptionsEU: Observable<string[]>;

  ngOnInit(): void {
    if (this.envService.getAbsoluteUrl().includes("internal.catalyst")) {
      this.isInternalSite = true;
    } else {
      this.isInternalSite = false;
    }
    // this.getAllDecommissionedSites();
    this.filteredOptionsUS = this.myControlUS.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value)),
    );
    this.filteredOptionsEU = this.myControlEU.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value)),
    );
   }

  private _filter(value: string): string[] {
    this.selectedSite = value;
    if (this.selectedEnvironment === 'US') {
      this.optionsUS = this.inActiveSitesListUS;
      const filterValue = value.toLowerCase();
      return this.optionsUS.filter(option => option.toLowerCase().includes(filterValue));
    } else {
      this.optionsEU = this.inActiveSitesListEU;
      const filterValue = value.toLowerCase();
      return this.optionsEU.filter(option => option.toLowerCase().includes(filterValue));
    }
  }

  getSelectedSiteName(val) {
    this.selectedSite = val;
  }

  getAllDecommissionedSites(){
    this.inActiveSitesListEU = [];
    this.inActiveSitesListUS = [];
    this.selectedSite = null;
    this.optionsUS = [];
    this.optionsEU = [];
    this.filteredOptionsUS = this.myControlUS.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value)),
    );
    this.filteredOptionsEU = this.myControlEU.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value)),
    );
    this.dataService.getAllDecommissionedSites('US').subscribe((result) =>{
      this.inActiveSitesListUS = result.decommissionedSites
      this.inActiveSitesFetched = true;
    },(error) => {
      if (error && error.status === 401) {
        location.pathname = "/site-build/unauthorized";
      } else {
        this.router.navigateByUrl('/error');
      }
    });
    this.dataService.getAllDecommissionedSites('EU').subscribe((result) =>{
      this.inActiveSitesListEU = result.decommissionedSites
      this.inActiveSitesFetched = true;
    },(error) => {
      if (error && error.status === 401) {
        location.pathname = "/site-build/unauthorized";
      } else {
        this.router.navigateByUrl('/error');
      }
    });
  }

  changeEnvironmentRadio(event) {
    this.selectedEnvironment = event.value;
  }

  update(e){
    this.selectedSite = e.value
    this.isSiteSelected = true;
  }

  updateSiteStatus(){
    const siteObj = {
      siteName : this.selectedSite,
      siteEnv : this.selectedEnvironment
    }
    this.dataService.updateSiteRecommissionStatus(siteObj).subscribe((result) => {
      this.siteStatusUpdated = true;
      if(result){
        Swal.fire({
          icon: 'success',
          title: 'Site Recommissioned',
          showConfirmButton: false,
          timer: 3000
        }).then(()=>{
            location.reload();
        });
      } else {
        Swal.fire({
          icon: 'error',
          title: 'there is an error',
          timer: 3000
        })
      }
    }, (error) => {
      if (error && error.status === 401) {
        location.pathname = "/site-build/unauthorized";
      } else {
        this.router.navigateByUrl('/error');
      }
    });
  }
  recommissionSite() {
    const siteObj = {
      siteName : this.siteName,
      siteEnv : this.selectedEnvironment
    }
    Swal.fire({
      title: 'Confirm Site Recommission',
      html: `Are you sure you want to Recommission  <br> <b>${this.siteName}</b>`,
      confirmButtonText: 'Confirm',
      showCancelButton: true,
      cancelButtonText: 'Reset',
      position: 'top',
      confirmButtonColor: '#00A59C'
    }).then((result) => {
      if(result.isConfirmed){
        (async () => {
          const { value: siteNameInAlert } = await Swal.fire({
            title: 'Confirm Site Recommission',
            input: 'text',
            inputLabel: 'Please type the site name to confirm',
            showCancelButton: true,
            position: 'top',
            confirmButtonColor: '#00A59C',
            inputValidator: (value) => {
              if (!value) {
                return 'You need to enter the site name to proceed'
              }
            }
          })
          if (siteNameInAlert && siteNameInAlert === this.siteName ) {
            Swal.fire({
              toast: true,
              position: 'top-right',
              text: `Recommissioning ${this.siteName} site`,
              timer: 3000,
              showConfirmButton: false,
            })
            this.dataService.updateSiteRecommissionStatus(siteObj).subscribe((result) => {
              this.siteStatusUpdated = true;
            if(result) {
              Swal.fire({
                text: `Site ${this.siteName} has been Recommissioned successfully`,
                timer: 1500,
                showConfirmButton: false,
              }).then(()=>{
                location.reload();
              })
            } else {
              Swal.fire('Something went wrong');
            }
          }, (error) => {
            if (error && error.status === 401) {
              location.pathname = "/site-build/unauthorized";
            } else {
              this.router.navigateByUrl('/error');
            }
          });
        }
        })()
      } 
    })
  }

}
