import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteRecreationComponent } from './site-recreation.component';

describe('SiteRecreationComponent', () => {
  let component: SiteRecreationComponent;
  let fixture: ComponentFixture<SiteRecreationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SiteRecreationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteRecreationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
