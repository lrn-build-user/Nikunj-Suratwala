import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FileUploadService } from '../../services/common/file-upload.service';
import { SharedDataService } from '../../services/shared-data.service';

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css']
})
export class FileUploadComponent implements OnInit {

  @Input('fileName') fileName = '';
  @Input('siteName') siteName = '';
  @Input('disabled') disabled = '';
  @Input('inPreviewPage') isPreviewPage;
  @Output() smallLogoURL = new EventEmitter<any>();
  @Output() largeLogoURL = new EventEmitter<any>();
  @Output() smallDarkLogoURL = new EventEmitter<any>();
  @Output() largeDarkLogoURL = new EventEmitter<any>();

  shortLink: String = '';
  loading: boolean =  false;
  uploadStatus = null;
  allowedImageTypes = ['jpg', 'jpeg', 'ai', 'gif', 'png'];
  filePath: string;

  public imagePath;
  imgURL: any;
  public message: string;
  remoteUrlImg = null;

  smallLogo = null;
  smallDarkLogo = null;
  largeLogo = null;
  largeDarkLogo = null;

  smallLogoValid = false;
  smallDarkLogoValid = false;
  largeLogoValid = false;
  largeDarkLogoValid = false;

  largeLogoUploaded = false;
  largeDarkLogoUploaded = false;
  smallLogoUploaded = false;
  smallDarkLogoUploaded = false;

  constructor(private fileUploadService: FileUploadService, private sharedDataService: SharedDataService) { }

  ngOnInit(): void {
    if (window.location.hostname !== 'localhost') {
      this.remoteUrlImg = 'https://' + window.location.hostname.replace('.catalyst', '-lcec') + `/${this.fileName}.gif`;
    } else {
      this.remoteUrlImg = `https://slotest-lcec.qa7.lrn.com/${this.fileName}.gif`;
    }
  }
 
  preview(files) {

    this.uploadStatus = null;
    this.smallLogoValid = false;
    this.largeLogoValid = false
    this.smallDarkLogoValid = false;
    this.largeDarkLogoValid = false;

    if (files.length === 0)
      return;
    
    let imageValid = false;

    if (files.length > 0) {
      this.message = '';
      this.imgURL = null;
      imageValid = false;
      this.smallLogoUploaded = false;
      this.largeLogoUploaded = false;
      this.largeDarkLogoUploaded = false;
      this.smallDarkLogoUploaded = false;
    }


    var mimeType = files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      this.message = "Only images are supported.";
      imageValid = false;
      return;
    } 

    if (files[0].size > 5242880) {
      this.message = "Please upload images with size less than 5MB";
      imageValid = false;
      return;
    }

    imageValid = true;
 
    var reader = new FileReader();
    this.imagePath = files;
    reader.readAsDataURL(files[0]); 
    reader.onload = (_event) => { 
      this.imgURL = reader.result;
      if(this.fileName === 'LOGO_S') {
        this.smallLogoURL.emit(this.imgURL)
      }

      if(this.fileName === 'LOGO_L') {
        this.largeLogoURL.emit(this.imgURL);
      }
      if(this.fileName === 'LOGO_DARK_S') {
        this.smallDarkLogoURL.emit(this.imgURL)
      }

      if(this.fileName === 'LOGO_DARK_L') {
        this.largeDarkLogoURL.emit(this.imgURL);
      }
    }

    console.log("Image valid?", imageValid, files[0], this.siteName);
    if (this.fileName === 'LOGO_L') {
      this.largeLogo = files[0];
      this.largeLogoValid = true;
    }
    if (this.fileName === 'LOGO_S') {
      this.smallLogo = files[0];
      this.smallLogoValid = true;
    }
    if (this.fileName === 'LOGO_DARK_L') {
      this.largeDarkLogo = files[0];
      this.largeDarkLogoValid = true;
    }
    if (this.fileName === 'LOGO_DARK_S') {
      this.smallDarkLogo = files[0];
      this.smallDarkLogoValid = true;
    }
  }

  uploadLogoStatus(fileName) {
    this.uploadStatus = 'done';
    if (fileName === 'LOGO_L') {
      this.largeLogoUploaded = true;
      this.largeLogoValid = false;
    }
    if (fileName === 'LOGO_S') {
      this.smallLogoUploaded = true;
      this.smallLogoValid = false;
    }
    if (fileName === 'LOGO_DARK_L') {
      this.largeDarkLogoUploaded = true;
      this.largeDarkLogoValid = false;
    }
    if (fileName === 'LOGO_DARK_S') {
      this.smallDarkLogoUploaded = true;
      this.smallDarkLogoValid = false;
    }
  }

  getLogoValidStatus(fileName) {
    if (fileName === 'LOGO_L') {
      return this.largeLogoValid;
    }
    if (fileName === 'LOGO_S') {
      return this.smallLogoValid;
    }
    if (fileName === 'LOGO_DARK_L') {
      return this.largeDarkLogoValid;
    }
    if (fileName === 'LOGO_DARK_S') {
      return this.smallDarkLogoValid;
    }
  }

  updateLogoStatusInSharedService(fileName, value) {
    if (fileName === 'LOGO_L') {
      this.sharedDataService.getLargeLogoStatus().next(value);
    }
    if (fileName === 'LOGO_S') {
      this.sharedDataService.getSmallLogoStatus().next(value);
    }
    if (fileName === 'LOGO_DARK_L') {
      this.sharedDataService.getLargeDarkLogoStatus().next(value);
    }
    if (fileName === 'LOGO_DARK_S') {
      this.sharedDataService.getSmallDarkLogoStatus().next(value);
    }
  }

  getLogo(fileName) {
    if (fileName === 'LOGO_L') {
      return this.largeLogo;
    }
    if (fileName === 'LOGO_S') {
      return this.smallLogo;
    }
    if (fileName === 'LOGO_DARK_L') {
      return this.largeDarkLogo;
    }
    if (fileName === 'LOGO_DARK_S') {
      return this.smallDarkLogo;
    }
  }

  uploadLogo(fileName) {
    this.uploadStatus = 'sync';
    if (this.getLogoValidStatus(fileName)) {
      this.updateLogoStatusInSharedService(fileName, 'sync');
      this.fileUploadService.upload(this.getLogo(fileName), fileName, this.siteName).subscribe((res) => {
        this.uploadLogoStatus(fileName);
        this.updateLogoStatusInSharedService(fileName, true);
      });
    }
  }

  uploadSmallLogo() {
    this.uploadStatus = 'sync';
    if (this.smallLogoValid) {
      this.sharedDataService.getSmallLogoStatus().next('sync');
      this.fileUploadService.upload(this.smallLogo, 'LOGO_S', this.siteName).subscribe((res) => {
        this.uploadStatus = 'done';
        this.smallLogoUploaded = true;
        this.smallLogoValid = false;
        this.sharedDataService.getSmallLogoStatus().next(this.smallLogoUploaded);
      });
    }
  };

  uploadLargeLogo() {
    this.uploadStatus = 'sync';
    if (this.largeLogoValid) {
      this.sharedDataService.getLargeLogoStatus().next('sync');
      this.fileUploadService.upload(this.largeLogo, 'LOGO_L', this.siteName).subscribe((res) => {
        this.uploadStatus = 'done';
        this.largeLogoUploaded = true;
        this.largeLogoValid = false;
        this.sharedDataService.getLargeLogoStatus().next(this.largeLogoUploaded);
      });
    }
  };

}
