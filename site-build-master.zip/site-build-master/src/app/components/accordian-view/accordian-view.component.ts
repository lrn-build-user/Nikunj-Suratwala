import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { EnvironmentService } from '../../services/common/environment.service';
import { SharedDataService } from '../../services/shared-data.service';

@Component({
  selector: 'app-accordian-view',
  templateUrl: './accordian-view.component.html',
  styleUrls: ['./accordian-view.component.css'],
})
export class AccordianViewComponent implements OnInit {
  @Input('apiResult') result;
  @Input('disableInputs') disableInputs = false;
  @Input('siteName') siteName = '';
  @Input('accordianConfigArray') accordianConfigArray;
  @Input('accordianStartIndex') accordianConfigArrayIndex;
  @Input('draftConfigs') draftConfigs;
  @Output() isInternationalEnabled = new EventEmitter<any>();
  form: FormGroup;


  constructor(
    private sharedDataService: SharedDataService, formBuilder: FormBuilder, private envService: EnvironmentService ){
    this.form = formBuilder.group(this.formGroupObject);
    this.checkedList = [];
  }
  siteUrl = this.envService.getAbsoluteUrl();
  configData = null;
  loading = true;
  apiResult = null;
  formGroupObject = {};
  checkedList : any[];
  currentSelected : {};

  configSchema: any;
  customConfigSchema : any;
  isInternationalizatioEnabled : boolean;
  selectedLanguageListCodes = [];
  siteId = null;


  languageList = [];
  languageListCodes = [];
  selectedLanguageList = [];
  languageFieldsObject = [];
  languageFieldObjectID = ['ProfileColumn','DefaultLanguage'];
  toggledDefaultLanguages = [];
  languageListCodeLength = 0;

  siteUrlIndex = null;
  defaultLanguageIndex = null;
  internationalizeIndex = null;
  profileColumnIndex = null;

  highlightedSiteConfigs: any = {};
  readOnlyFields = ['SiteURL', 'ProfileColumn'];

  currentPage = 1;
  numberOfPages = 5;
  startRows = 0;
  numberOfRows = 12;
  currentPaginationIndex = 0;
  maxPaginationIndex = 5;
  showRefreshBar = false;
  currentPaginationValues = [];
  currentLanguageList = [];

  pageArray = [];

  

  ngOnInit(): void {
    if (this.result) {
      if (this.siteUrl.includes('internal.catalyst')) {
        this.siteUrl = this.siteUrl.replace(
          'internal',
          this.siteName ? this.siteName : 'internal'
        );
      }
      this.configData['SiteURL'] = this.siteUrl;
      this.loading = false;
      if (!this.disableInputs) {
        this.sharedDataService.getConfigSchemaData().next(this.configData);
      }
    }
    this.accordianConfigArray = this.accordianConfigArray.filter(e => e !== null);
    this.accordianConfigArray.forEach((key, index) => {
      if(key.id === 'SiteURL')
        this.siteUrlIndex = index;
      if(key.id === 'DefaultLanguage')
        this.defaultLanguageIndex = index;
      if(key.id === 'internationalize_site')
        this.internationalizeIndex = index;
      if(key.id === 'ProfileColumn')
        this.profileColumnIndex = index;
    })
    if(this.internationalizeIndex !== null) {
      // this.toggleLanguageFields(this.configData['internationalize_site'], this.internationalizeIndex)
      this.calculateNumberOfPages();
      this.currentPageLanguageList(1);
    }
    this.buildLanguageFieldsObject();
    console.log("Draft configs accordian nginit: ", this.draftConfigs)
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes && changes.siteName) {
      this.siteName = changes.siteName.currentValue;
      if (this.siteUrl.includes('internal.catalyst')) {
        this.siteUrl = this.siteUrl.replace('internal', this.siteName ? this.siteName : 'internal');
      }
      if (this.configData) {
        this.configData['SiteURL'] = this.siteUrl;
      }
    }
    if(changes.result && changes.result.currentValue !== null && changes.result.currentValue.schema && changes.result.currentValue.data) {
      this.loading = false;
      this.apiResult = changes.result.currentValue
      this.configSchema = this.apiResult.schema.properties.site_configs.properties;
      this.configData = this.apiResult.data.site_configs;
      this.siteId = this.sharedDataService.getSiteId();
      if (!this.configData) {
        this.configData = this.result.data.site_configs;
      }
      this.configData['SiteURL'] = this.siteUrl;
      this.configData['internationalize_site'] = (this.configData.ProfileColumn === 'Language') ? true : false;
      
      let languageDropdown = null;
      if(this.defaultLanguageIndex !== null) {
      this.getLanguagesFromSchema(this.accordianConfigArray[this.defaultLanguageIndex].enum);
      }
      if(this.apiResult.data.user_configs) {
        if(this.apiResult.data.user_configs  && this.apiResult.data.user_configs['custom_field']){
          if (this.apiResult.data.user_configs['custom_field'].length > 0) {
            this.getLanguagesFromUserData(this.apiResult.data.user_configs['custom_field'][this.apiResult.data.user_configs['custom_field'].length-1]['DROPDOWN_ENUM']);
            languageDropdown = this.apiResult.data.user_configs['custom_field'][this.apiResult.data.user_configs['custom_field'].length-1]['DROPDOWN_ENUM'];
          }
        } else {
          if (this.apiResult.data.user_configs['Language']) {
            this.getLanguagesFromUserData(this.apiResult.data.user_configs['Language']['DROPDOWN_ENUM']);
            languageDropdown = this.apiResult.data.user_configs['Language']['DROPDOWN_ENUM'];
          }
        }
      }
      if (!this.disableInputs ) {
        if (!this.configData['internationalize_site'] && this.internationalizeIndex !== null) {
           this.toggleLanguageFields(false, this.internationalizeIndex);
        }
      }

      if (!this.disableInputs) {
        this.sharedDataService.getConfigSchemaData().next(this.configData);
      }
      if (languageDropdown && !languageDropdown.includes(this.configData.DefaultLanguage)) {
        console.log("Default language: ", this.configData.DefaultLanguage);
        let dropdownValue = this.configData && this.configData.DefaultLanguage ?  this.selectLanguageToggle({ checked: true }, this.configData.DefaultLanguage.split(" - ")[1].trim()) : "English - en";
        if (this.apiResult.data.user_configs['Language']) {
          this.apiResult.data.user_configs['Language']['DROPDOWN_ENUM'] = dropdownValue;
        }
        if (this.apiResult.data.user_configs && this.apiResult.data.user_configs['custom_field'] && this.apiResult.data.user_configs['custom_field'].length > 0) {
          if (this.apiResult.data.user_configs['custom_field'][this.apiResult.data.user_configs['custom_field'].length-1]['COLUMN_NAME'] === 'Language') {
            this.apiResult.data.user_configs['custom_field'][this.apiResult.data.user_configs['custom_field'].length-1]['DROPDOWN_ENUM'] = dropdownValue;
            this.sharedDataService.getUserSchemaData().next(this.apiResult.data.user_configs);
          }
        }
      } else if (!languageDropdown) {
        if (this.apiResult.data.user_configs['Language']) {
          this.apiResult.data.user_configs['Language']['DROPDOWN_ENUM'] = "English - en";
        }
        if (this.apiResult.data.user_configs && this.apiResult.data.user_configs['custom_field'] && this.apiResult.data.user_configs['custom_field'].length > 0) {
          if (this.apiResult.data.user_configs['custom_field'][this.apiResult.data.user_configs['custom_field'].length-1]['COLUMN_NAME'] === 'Language') {
            this.apiResult.data.user_configs['custom_field'][this.apiResult.data.user_configs['custom_field'].length-1]['DROPDOWN_ENUM'] = "English - en";
            this.sharedDataService.getUserSchemaData().next(this.apiResult.data.user_configs);
          }
        }
        this.selectedLanguageListCodes.push("en");
      }
      this.getLanguagesFromSchema(this.configSchema['DefaultLanguage'].enum);
      this.highlightedSiteConfigs = this.sharedDataService.getAuditLogsHighlights();
      this.highlightedSiteConfigs = this.highlightedSiteConfigs.site_configs;
    }
  }

  getLanguagesFromSchema(languageArray) {
    languageArray.forEach(eachLanguage => {
      this.languageList[eachLanguage.split(" - ")[1]] = eachLanguage.split(" - ")[0];
      this.languageListCodes.push(eachLanguage.split(" - ")[1]);
    });
  }

  calculateNumberOfPages() {
    this.languageListCodeLength = this.languageListCodes.length;
    this.numberOfPages = Math.ceil(this.languageListCodes.length / 12);
    for(let i = 0; i<this.numberOfPages; i++){
      this.pageArray.push(i+1);
    }
  }

  getLanguagesFromUserData(dropdownVal) {
    if (dropdownVal) {
      const languages = dropdownVal.split(", ");
      languages.push("English - en");
      languages.forEach(eachLanguage => {
        this.selectedLanguageList.push({
          code: eachLanguage.split(" - ")[1],
          label: eachLanguage.split(" - ")[0]
        });
        this.selectedLanguageListCodes.push(eachLanguage.split(" - ")[1]);
      });
      this.selectedLanguageListCodes.sort();
    } else {
      this.selectedLanguageListCodes.push("en");
    }
    this.selectedLanguageListCodes = [...new Set(this.selectedLanguageListCodes)];
    this.selectedLanguageListCodes = this.selectedLanguageListCodes.filter(code => code !== undefined);
    this.selectedLanguageListCodes = this.selectedLanguageListCodes.map(code => {
      return code.replace(/"|\ /g,'');
    });
  };

  toggleLanguageFields(toggle, index) {
    if(!toggle) {
      this.languageFieldObjectID.forEach(key => {
        this.accordianConfigArray.forEach((field, index) => {
          if(field && key === field.id){
            this.accordianConfigArray.splice(index, 1);
            let key = this.accordianConfigArray[0];
            if(key.tag === 'bulkloadManagement' || key.tag === 'security' || key.tag === 'LMSIntegration' || key.tag === 'moduleSettings') {
              this.accordianConfigArrayIndex = this.accordianConfigArrayIndex-1;
            }
          }
        })
      })
    } else {
      this.accordianConfigArray.splice(index+1, 0, this.languageFieldsObject[1]);
      let key = this.accordianConfigArray[0];
      if(key.tag === 'bulkloadManagement' || key.tag === 'security' || key.tag === 'LMSIntegration' || key.tag === 'moduleSettings') {
      this.accordianConfigArrayIndex = this.accordianConfigArrayIndex + 1;
    }
    }
  }

  buildLanguageFieldsObject() {
    this.languageFieldsObject = [this.configSchema['ProfileColumn'], this.configSchema['DefaultLanguage']];
    this.languageFieldsObject[0]['id'] = this.languageFieldObjectID[0];
    this.languageFieldsObject[0]['value'] = this.configData['ProfileColumn'] ? this.configData['ProfileColumn'] : null;
    this.languageFieldsObject[1]['id'] = this.languageFieldObjectID[1];
    this.languageFieldsObject[1]['value'] = this.configData['DefaultLanguage'] ? this.configData['DefaultLanguage'] : 'English - en';
  }

  selectLanguageToggle(event, language) {
    this.selectedLanguageListCodes = this.selectedLanguageListCodes.filter(code => code !== undefined);
    this.selectedLanguageListCodes = this.selectedLanguageListCodes.map(code => {
      return code.replace(/"|\ /g,'');
    });
    if (event.checked) {
      this.selectedLanguageListCodes.push(language);
    } else {
      this.selectedLanguageListCodes = this.selectedLanguageListCodes.filter((lang) => lang !== language);
    }
    this.selectedLanguageListCodes = [...new Set(this.selectedLanguageListCodes)];
    this.selectedLanguageListCodes.sort();
    let dropdownStr = '';
    if (this.selectedLanguageListCodes.length > 0) {
      this.selectedLanguageListCodes.forEach(eachLang => {
        dropdownStr += `"${this.languageList[eachLang]} - ${eachLang}", `;
      });
      dropdownStr = dropdownStr.substring(0, dropdownStr.length - 2);
    }
    this.sharedDataService.getLanguageArray().next(dropdownStr);
    return dropdownStr;
  }

  getSelectedValue(status: Boolean, value: String) {
    if (status) {
      this.checkedList.push(value);
    } else {
      var index = this.checkedList.indexOf(value);
      this.checkedList.splice(index, 1);
    }
    this.sharedDataService.getLanguageArray().next(this.checkedList.join(', '));
    this.currentSelected = { checked: status, name: value };
  }

  checkForLanguageFieldInCustomFields() {
    let languagePresent = false;
    const customFields = this.apiResult.data.user_configs['custom_field'] ? this.apiResult.data.user_configs['custom_field']: [];
    customFields.forEach(eachField => {
      if (eachField['DISPLAY_NAME'] === 'Language') {
        languagePresent = true;
      }
    });
    return languagePresent;
  }

  toggle(event, key?:string, data?:string){
    if(key === 'internationalize_site') {
      this.getLanguagesFromSchema(this.configSchema['DefaultLanguage'].enum);
    }
    if (key === 'internationalize_site') {
      if ((this.configData['internationalize_site'] === false || this.configData['internationalize_site'] === null) && event.checked === true && this.checkForLanguageFieldInCustomFields()) {
        alert(`Language already present in User Data Fields, you cannot enable internationalization, please change the existing field first`);
        this.configData['internationalize_site'] = this.configData['internationalize_site'] === false ? null : false;
        this.configData['ProfileColumn'] = null;
        this.configData['DefaultLanguage'] = "English - en";
        return;
      }
    }

    if (key === 'DefaultLanguage') {
      const selectedDefaultLanguage = event.value.split("-")[1].trim();
      const object = {
        code: `${event.value.split("-")[1].trim()}`,
        label: `${event.value.split("-")[0].trim()}`
      };
      let languageExistsFromTheBeginning = false;
      this.selectedLanguageList.forEach(eachObject => {
        if (JSON.stringify(eachObject) === JSON.stringify(object)) {
          languageExistsFromTheBeginning = true;
        }
      });
      if (!languageExistsFromTheBeginning) {
        if (!this.selectedLanguageListCodes.includes(selectedDefaultLanguage)) {
          this.selectLanguageToggle({ checked: false }, this.toggledDefaultLanguages.pop());
          this.selectLanguageToggle({ checked: true }, selectedDefaultLanguage);
          this.toggledDefaultLanguages.push(selectedDefaultLanguage);
        }
      } else {
        if (this.selectedLanguageListCodes.includes(selectedDefaultLanguage)) {
          this.selectLanguageToggle({ checked: false}, this.toggledDefaultLanguages.pop());
          this.selectLanguageToggle({ checked: true }, selectedDefaultLanguage);
        }
      }
    }

    if (event.type === 'input') {
      this.configData[key] = data;
    } else if (event.checked === true || event.checked === false) {
      this.configData[key] = event.checked;
    } else if (event.source.controlType === 'mat-select') {
      this.configData[key] = event.value;
    }
    if (key === 'internationalize_site') {
      if (this.configData['internationalize_site']) {
        this.toggleLanguageFields(true, this.internationalizeIndex);
        this.configData['ProfileColumn'] = 'Language';
        this.configData['DefaultLanguage'] = "English - en";
        this.isInternationalEnabled.emit(this.configData['internationalize_site'])
      } else {
        this.toggleLanguageFields(false, this.internationalizeIndex);
        this.configData['ProfileColumn'] = null;
        this.configData['DefaultLanguage'] = "English - en";
        this.isInternationalEnabled.emit(this.configData['internationalize_site'])

      }
    }
    if(!this.disableInputs) {
      this.sharedDataService.getConfigSchemaData().next(this.configData);
    }
  }

  currentPageLanguageList(page) {
    
    if(page < 1) {
      page = 1;
    }
    if(page > this.numberOfPages) {
      page = this.numberOfPages;
    }
    this.currentPage = page;
    let startIndex = null;
    if(page == 1) {
      startIndex = 0;
    } else {
      startIndex = 12 * (page-1);
    }
    let tempArr = JSON.parse(JSON.stringify(this.languageListCodes));
    this.currentLanguageList = [];
    if((this.languageListCodeLength - startIndex) >= this.numberOfRows) {
      this.currentLanguageList = tempArr.splice(startIndex, this.numberOfRows);
    } else {
      this.currentLanguageList = tempArr.splice(startIndex, (this.languageListCodeLength-startIndex));
    }
    // this.temporaryListCodes = [];
  }

  moveToPage(page) {
    this.currentPageLanguageList(page);
  }
}
