import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SamlMetadataFileComponent } from './saml-metadata-file.component';

describe('SamlMetadataFileComponent', () => {
  let component: SamlMetadataFileComponent;
  let fixture: ComponentFixture<SamlMetadataFileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SamlMetadataFileComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SamlMetadataFileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
