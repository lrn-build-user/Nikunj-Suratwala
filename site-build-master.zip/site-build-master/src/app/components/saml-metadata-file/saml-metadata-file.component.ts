import { Component,Inject, OnInit,Input } from '@angular/core';
import { FileUploadService } from '../../services/common/meta-file-upload.service';
import { ActivatedRoute } from '@angular/router';
import { NgForm, AbstractControl, FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import * as $ from "jquery";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { toInteger } from 'lodash';

@Component({
  selector: 'app-saml-metadata-file',
  templateUrl: './saml-metadata-file.component.html',
  styleUrls: ['./saml-metadata-file.component.css']
})
export class SamlMetadataFileComponent implements OnInit {

  

	// Variable to store shortLink from api response
	baseUrl =location.origin;
	shortLink: string = "";
	loading: boolean = false; // Flag variable
	file: any = File; // Variable to store file
	filesList: any =[];
	spFilesList: any =[];
	filesVersionList: any =[];
	company :string = '';
	spMetadataShortLink : string = "";
	public isFLDataRendred: boolean = false;
	public isFLNoDataAvailable: boolean = false;
	public isSPDataRendred: boolean = false;
	public isSPNoDataAvailable: boolean = false;
	public isTempNoDataAvailable: boolean = false;
	public isTempDataRendred: boolean = false;
	public showRefreshBar: boolean = false;
	public showMessageBar: boolean = false;
	public responseMessageText: string = '';
	public fileUploadForm: FormGroup;

	
	// Inject service
	@Input('showSubmitButtons') showSubmitButtons = false;
	constructor(private fileUploadService: FileUploadService,
		 private route : ActivatedRoute,
		 private formBuilder: FormBuilder,		
		 public dialog: MatDialog) {
			if(this.baseUrl.includes("localhost")){
				this.baseUrl = this.baseUrl.replace("localhost:4200","localhost:3001");
			}
			this.fileUploadForm = this.formBuilder.group({
				metaDataFile: ''
			  });
		  }

	ngOnInit(): void {
		
	this.fetchList();
	this.fetchVersionsList();
	this.fetchSPList();
	}

	// On file Select
	onChange(event : any) {
		this.file = event.target.files[0];
		//console.log("file tyoe is : "+this.file.name)
		if(this.file.type == "text/xml" || this.file.type == "application/xml") {
			var fileName = this.file.name;
			if(fileName.startsWith("metadata"))
			this.responseMessageText ="";
			else{
				this.fileUploadForm.reset();
				this.file = File;
            this.responseMessageText ="File Name should start with metadata";
			}
            //console.log("correct file format");
           
          }
          else {
            //call validation
			this.file = File;
            this.fileUploadForm.reset();
            this.responseMessageText ="File Type should be in xml";
		  }
	}

	// OnClick of button Upload
	onUpload() {
		this.loading = !this.loading;
		//console.log(this.file);
		this.fileUploadService.upload(this.file,this.company).subscribe(
			(event: any) => {
				//console.log("event value is : "+event)
				if (typeof (event) === 'object') {
					this.shortLink = event.message;
					this.responseMessageText = event.message;
					this.loading = false; // Flag variable
					this.fetchList();
					this.fetchVersionsList();
					setTimeout(function () {
						$(
						  "#uploadFileModal"
						)
						  .removeClass("in")
						  .addClass("out")
						  .hide();
						$("#overlay").removeClass("modal-backdrop in");
						$(document.body).removeClass("modal-open");
						//window.location.reload();
						this.ngOnInit();
					  }, 2000);
				}
			}
		);
		
	}

	fetchList() {		
		this.fileUploadService.fetchFiles(this.company).subscribe(
			(event: any) => {
				if (event.length > 0 && typeof (event) === 'object') {
					this.filesList = event;
					this.isFLDataRendred =true;
				} else if(event.length === 0){
					this.isFLNoDataAvailable = true;
					this.isFLDataRendred =true;
				}
			}
		);
	}
	
	fetchVersionsList() {		
		this.fileUploadService.fetchFilesVersions(this.company).subscribe(
			(event: any) => {
				if (event.length > 0 && typeof (event) === 'object') {
					this.filesVersionList =  event;
					this.filesVersionList.forEach(item => {
						//console.log("date is "+item.name.split("_",1)+"     -     "+new Date(toInteger(item.name.split("_",1))).toDateString())
						item.backUpDate = new Date(toInteger(item.name.split("_",1))).toDateString() + " - "+new Date(toInteger(item.name.split("_",1))).toLocaleTimeString();
					  });										
					this.isFLDataRendred =true;
				} else if(event.length === 0){
					this.isFLNoDataAvailable = true;
					this.isFLDataRendred =true;
				}
			}
		);
	}
	
	fetchSPList() {		
		this.fileUploadService.fetchSPFiles(this.company).subscribe(
			(event: any) => {
				// if (typeof (event) === 'object') {
				// 	this.spFilesList = event;
				// }
				if (event.length > 0 && typeof (event) === 'object') {
					this.spFilesList = event;
					this.isSPDataRendred =true;
				} else if(event.length === 0){
					this.isSPNoDataAvailable = true;
					this.isSPDataRendred =true;
				}
			}
		);
	}
	generateSPmetadata(fileName: any) {		
		this.fileUploadService.generateSPmetadata(fileName,this.company).subscribe(
			(event: any) => {
				if (typeof (event) === 'object') {
					this.spMetadataShortLink = event.message;
					this.fetchSPList();
				}
			}
		);
	}

	downloadMetadata(linkUrl: any){
		//console.log("downloadSPmetadata function called")
		this.fileUploadService.downloadFile(linkUrl,this.company).subscribe(response =>
			{
				let fileName = response.headers.get("Content-Disposition")?.split(";")[1].split("=")[1];
				//console.log("fileName : "+fileName);
				if(fileName != undefined){
				const search = "\"" ;
    			const replacer = new RegExp(search, 'g')
    			fileName = fileName.replace(replacer,'');
				let blob:Blob = response.body as Blob;
				let a = document.createElement('a');
				a.download=fileName;
				a.href = window.URL.createObjectURL(blob);
				a.click();
				}else{
					window.open(this.baseUrl+linkUrl);
				}
			}
		);
	}


	public uploadFiles() {
		this.fileUploadForm.controls['metaDataFile'].setValue('');
		this.responseMessageText='';
		//console.log('im here');
		$("#overlay").addClass("modal-backdrop in");
		$("#uploadFileModal")
		  .removeClass("out")
		  .addClass("in")
		  .show();
	
	  }
	  /**
	 * cancelclicked
	 */
	  public closeModal() {
		$(
		  "#uploadFileModal"
		)
		  .removeClass("in")
		  .addClass("out")
		  .hide();
		$("#overlay").removeClass("modal-backdrop in");
		// this.resetCheckboxes();
		$(document.body).removeClass("modal-open");
		// if (this.deleteStatus){
		//window.location.reload();
		this.ngOnInit();
		// }
	  }

}
