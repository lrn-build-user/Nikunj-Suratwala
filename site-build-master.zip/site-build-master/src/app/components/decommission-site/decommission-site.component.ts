import { Component, OnInit } from '@angular/core';
import { EnvironmentService } from '../../services/common/environment.service';
import { DataService } from '../../services/data.service';
import { FormControl, Validators } from '@angular/forms';
import Swal from 'sweetalert2';
import { Router } from '@angular/router'
import { Observable } from 'rxjs/internal/Observable';
import { map, startWith } from 'rxjs/operators';
@Component({
  selector: 'app-decommission-site',
  templateUrl: './decommission-site.component.html',
  styleUrls: ['./decommission-site.component.css']
})
export class DecommissionSiteComponent implements OnInit {

  constructor(private envService: EnvironmentService,
    private dataService : DataService,
    private router : Router) { }
  
  siteControl = new FormControl('', Validators.required)

  isInternalSite = false;
  activeSitesListUS = [];
  activeSitesListEU = [];
  isSiteSelected = false;
  selectedSite = null;
  activeSitesFetched = false;
  isLinear = true
  siteStatusUpdated = false;
  myControlUS = new FormControl();
  myControlEU = new FormControl();
  optionsUS: string[] = [];
  optionsEU: string[] = [];
  filteredOptionsUS: Observable<string[]>;
  filteredOptionsEU: Observable<string[]>;
  selectedEnvironment = 'US';
  siteName = '';

  ngOnInit(): void {
    if (this.envService.getAbsoluteUrl().includes("internal.catalyst")) {
      this.isInternalSite = true;
    } else {
      this.isInternalSite = false;
    }
    this.filteredOptionsUS = this.myControlUS.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value)),
    );
    this.filteredOptionsEU = this.myControlEU.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value)),
    );
  }

  private _filter(value: string): string[] {
    this.selectedSite = value;
    if (this.selectedEnvironment === 'US') {
      this.optionsUS = this.activeSitesListUS;
      const filterValue = value.toLowerCase();
      return this.optionsUS.filter(option => option.toLowerCase().includes(filterValue));
    } else {
      this.optionsEU = this.activeSitesListEU;
      const filterValue = value.toLowerCase();
      return this.optionsEU.filter(option => option.toLowerCase().includes(filterValue));
    }
  }

  getSelectedSiteName(val) {
    this.selectedSite = val;
  }

  changeEnvironmentRadio(event) {
    this.selectedEnvironment = event.value;
    this.selectedSite = null;
  }
    
  getAllActiveSites(){
    this.activeSitesListUS = [];
    this.activeSitesListEU = [];
    this.selectedSite = null;
    this.optionsUS = [];
    this.optionsEU = [];
    this.filteredOptionsUS = this.myControlUS.valueChanges.pipe(
      startWith(''),
      map(valueUS => this._filter(valueUS)),
    );
    this.filteredOptionsEU = this.myControlEU.valueChanges.pipe(
      startWith(''),
      map(valueEU => this._filter(valueEU)),
    );
    this.dataService.getAllActiveSites('US').subscribe((result) => {
      this.activeSitesListUS = result.activeSites;
      this.activeSitesFetched = true;
    }, (error)=>{
      if (error && error.status === 401) {
        location.pathname = "/site-build/unauthorized";
      } else {
        this.router.navigateByUrl('/error');
      }
    })
    this.dataService.getAllActiveSites('EU').subscribe((result) => {
      this.activeSitesListEU = result.activeSites;
      this.activeSitesFetched = true;
    }, (error)=>{
      if (error && error.status === 401) {
        location.pathname = "/site-build/unauthorized";
      } else {
        this.router.navigateByUrl('/error');
      }
    })
  }

  update(e){
    this.selectedSite = e.value
    this.isSiteSelected = true;
  }

  updateSiteStatus(){
    this.dataService.updateSiteStatus(this.selectedSite, this.selectedEnvironment).subscribe((result) => {
      this.siteStatusUpdated = true;
      console.log(result);
      if(result){
        Swal.fire({
          icon: 'success',
          title: 'Site Decommissioned',
          showConfirmButton: false,
          timer: 3000
        }).then(()=>{
            location.reload();
        });
      } else {
        Swal.fire({
          icon: 'error',
          title: 'there is an error',
          timer: 3000
        })
      }
    }, (error) => {
      if (error && error.status === 401) {
        location.pathname = "/site-build/unauthorized";
      } else {
        this.router.navigateByUrl('/error');
      }
    });
  }

  decommissionSite() {
    Swal.fire({
      title: 'Confirm Site Decommission',
      html: `Are you sure you want to Decommission  <br> <b>${this.siteName}</b>`,
      confirmButtonText: 'Confirm',
      showCancelButton: true,
      cancelButtonText: 'Reset',
      position: 'top',
      confirmButtonColor: '#00A59C'
    }).then((result) => {
      if(result.isConfirmed){
        (async () => {
          const { value: siteNameInAlert } = await Swal.fire({
            title: 'Confirm Site Decommission',
            input: 'text',
            inputLabel: 'Please type the site name to confirm',
            showCancelButton: true,
            position: 'top',
            confirmButtonColor: '#00A59C',
            inputValidator: (value) => {
              if (!value) {
                return 'You need to enter the site name to proceed'
              }
            }
          })
          if (siteNameInAlert && siteNameInAlert === this.siteName ) {
            Swal.fire({
              toast: true,
              position: 'top-right',
              text: `Decommissioning ${this.siteName} site`,
              timer: 3000,
              showConfirmButton: false,
            })
            this.dataService.updateSiteStatus(this.siteName, this.selectedEnvironment).subscribe((result) => {
              this.siteStatusUpdated = true;
            if(result) {
              Swal.fire({
                text: `Site ${this.siteName} has been Decommissioned successfully`,
                timer: 1500,
                showConfirmButton: false,
              }).then(()=>{
                location.reload();
              })
            } else {
              Swal.fire('Something went wrong');
            }
          }, (error) => {
            if (error && error.status === 401) {
              location.pathname = "/site-build/unauthorized";
            } else {
              this.router.navigateByUrl('/error');
            }
          });
        }
        })()
      } 
    })
  }

}
