import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DecommissionSiteComponent } from './decommission-site.component';

describe('DecommissionSiteComponent', () => {
  let component: DecommissionSiteComponent;
  let fixture: ComponentFixture<DecommissionSiteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DecommissionSiteComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DecommissionSiteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
