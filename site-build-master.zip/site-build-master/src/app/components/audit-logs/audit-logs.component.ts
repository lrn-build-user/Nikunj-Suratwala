import { Component, Inject, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { EnvironmentService } from '../../services/common/environment.service';
import { DataService } from '../../services/data.service';
import { SharedDataService } from '../../services/shared-data.service';
import { DataFilterComponent } from '../data-filter/data-filter.component';
import { NewSiteStepperComponent } from '../new-site-stepper/new-site-stepper.component';
import { PrintPdfComponent } from '../print-pdf/print-pdf.component';

@Component({
  selector: 'app-audit-logs',
  templateUrl: './audit-logs.component.html',
  styleUrls: ['./audit-logs.component.css']
})
export class AuditLogsComponent implements OnInit {

  @Input('environment') environment = 'US';

  constructor(private dataService: DataService,
    private sharedDataService: SharedDataService,
    private router: Router,
    private envService: EnvironmentService,
    private newSiteStepperComponent: NewSiteStepperComponent,
    private dialog: MatDialog) { }

  totalHistoryItems = 5;
  numberOfPages = 5;
  numberOfRows = 25;
  currentPaginationIndex = 0;
  maxPaginationIndex = 5;
  currentPaginationValues = [];
  pagesArray = [];

  startRows = 0;

  currentPage = 1;

  historyList;

  loadingTable = true;

  currentSiteConfigs = null;
  currentUserConfigs = null;

  schema = null;
  completeSchemaResult = null;

  fullConfigsView = [];
  configChangesView = [];
  changesData = null;

  changesViewOpened = false;
  fullConfigsViewOpened = false;
  previouslyOpenedChanges = -1;
  previouslyOpenedFullConfigs = -1;

  siteConfigsObject = {};
  usersDataObject = {};
  apiConfigsObject = {};
  isInternalSite = false;
  sitesList = ['All Sites'];
  selectedFilterSite = 'All Sites';
  selectedFilterDate = 'Week';
  filterDates = ['Week', '30 days', 'Quarter'];
  filterDatesMap = {'Week': 7, '30 days': 30, 'Quarter': 90 };
  changesListAuditLogs = {};

  showRefreshBar = false;
  fieldsToIgnore = ['REPORT_POSITION','SOURCE_OF_DATA','INSTRUCTION_TEXT','SIZE', 'COLUMN_NAME', 'ATTRIBUTE_TYPE', 'FIELD_TYPE', 'MAPPED_FIELD_NAME',
  'FIELD_DISPLAY_NAME', 'FIELD_POSITION', 'FIELD_MATCH', 'FIELD_NAME', 'FIELD_LENGTH'];

  transformedUserData = null;

  readonly DataFilterComponent = DataFilterComponent;
  range = new FormGroup({
    start: new FormControl(),
    end: new FormControl(),
  });

  isTouchUIActivated = false;

  myControl = new FormControl();
  options: string[] = [];
  filteredOptions: Observable<string[]>;
  fetchRequestedByUser: boolean = false;
  dateSelectionError: boolean = false;

  changesFromDraft: string[] = [];

  ngOnInit(): void {
    if (this.envService.getAbsoluteUrl().includes("internal.catalyst")) {
      this.isInternalSite = true;
    } else {
      this.isInternalSite = false;
    }
    if (this.currentPage > this.numberOfPages) {
      this.currentPage = this.numberOfPages;
    }
    let endDate = new Date(this.range.value.end).getTime();
    let startDate = new Date(this.range.value.start).getTime();
    if (((startDate !== 0 && endDate === 0) || (startDate === 0 && endDate !== 0)) && this.fetchRequestedByUser) {
      alert("Please select both start and end dates");
      this.showRefreshBar = false;
      this.dateSelectionError = true;
      return;
    }

    if (startDate !== 0 && endDate !== 0) {
      if ((endDate - startDate) < (86400000-1)) {
        endDate += 86400000;
      }
    }
    if (startDate === 0 && endDate === 0) {
      endDate = new Date(Date.now()).getTime();
    }
    startDate += 86400000;
    endDate += (startDate === endDate) ? 86400000 : (86400000*2);
    startDate -= 66600000;
    endDate -= 66600000;

    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value)),
    );
    const params = {
      startRows: this.startRows,
      numberOfRows: this.numberOfRows,
      siteName: (this.selectedFilterSite !== 'All Sites' && this.isInternalSite) ? this.selectedFilterSite : (this.isInternalSite) ? 'INTERNAL' : 'OTHERSITE',
      dateRange: { start: startDate, end: endDate },
      fromInternalSite: this.isInternalSite,
      environment: this.environment
    };
    this.dataService.getAuditLogs(params).subscribe(result => {
      this.historyList = result.docs;
      this.totalHistoryItems = result.count;
      this.loadingTable = false;
      this.numberOfPages = Math.ceil(this.totalHistoryItems / this.numberOfRows);
      this.maxPaginationIndex = Math.ceil(this.totalHistoryItems / this.numberOfRows);
      this.maxPaginationIndex /= 5;
      this.pagesArray = Array.from(Array(this.numberOfPages-1).keys());

      let tempUser:any = {};
      let tempSite:any = {};
      let smallLogo: boolean = false;
      let largeLogo: boolean = false;
      tempUser['ADDED_FIELDS'] = [];

      this.sharedDataService.setLatestAuditLog(this.historyList[0]);
      const latestLog = {
        userName: this.historyList[0].USER_NAME,
        timestamp: this.historyList[0].TIMESTAMP
      }
      localStorage.setItem('latestLog', JSON.stringify(latestLog));

      this.historyList.forEach((eachDoc) => {
        if (eachDoc.STATUS === 'IN_PROGRESS') {
          tempSite = this.mergeDeep(tempSite , eachDoc.CHANGES_CURRENT && eachDoc.CHANGES_CURRENT.site_configs ? eachDoc.CHANGES_CURRENT.site_configs : {});
          tempUser = this.mergeDeep(tempUser , eachDoc.CHANGES_CURRENT && eachDoc.CHANGES_CURRENT.user_configs ? eachDoc.CHANGES_CURRENT.user_configs : {});
          if (eachDoc.USER_FIELDS_ADDED && eachDoc.USER_FIELDS_ADDED.length > 0) {
            tempUser['ADDED_FIELDS'] = tempUser['ADDED_FIELDS'].concat(eachDoc.USER_FIELDS_ADDED);
            tempUser['ADDED_FIELDS'] = [... new Set(tempUser['ADDED_FIELDS'])]
          }
          if (eachDoc && eachDoc.CHANGES && eachDoc.CHANGES.includes('Small Logo Added')) {
            smallLogo = true;
          }
          if (eachDoc && eachDoc.CHANGES && eachDoc.CHANGES.includes('Large Logo Added')) {
            largeLogo = true;
          }
        }
      });

      this.changesListAuditLogs['site_configs'] = tempSite;
      this.changesListAuditLogs['user_configs'] = tempUser;
      this.changesListAuditLogs['small_logo'] = smallLogo;
      this.changesListAuditLogs['large_logo'] = largeLogo;
      this.sharedDataService.setAuditLogsHighlights(this.changesListAuditLogs);

      this.getDraftChanges(this.historyList);
      // this.sharedDataService.setSiteConfigDraftChanges(this.changesFromDraft);
      this.sharedDataService.getSiteConfigDraftChanges().next(this.changesFromDraft);

      this.currentPaginationValues = [];
      let tempPages = Math.min(5, (this.numberOfPages - this.currentPaginationIndex * 5));
      for(let i = 1; i <= tempPages; i++) {
        this.currentPaginationValues.push(i);
      }
      if (this.startRows === 0) {
        let status = false;
        this.historyList.forEach(record => {
          if (record.STATUS === 'IN_PROGRESS') {
            status = true;
          }
        });
        this.sharedDataService.getPendingLogsStatus().next(status);
      }
    }, error => {
      console.log("Error in fetching audi logs:", this.loadingTable, error);
      if(error.status === 401){
        location.pathname = "/site-build/unauthorized"
      }  else {
        this.router.navigateByUrl('/error');
      }
    });

    this.sharedDataService.getConfigSchemaData().subscribe(configs => {
      this.currentSiteConfigs = configs;
    });

    this.sharedDataService.getUserSchemaData().subscribe(configs => {
      this.currentUserConfigs = configs;
      this.transformedUserData = this.transformCustomUserData(this.currentUserConfigs);
    });

    if (this.isInternalSite) {
      this.schema = this.newSiteStepperComponent.schema;

      this.dataService.getSiteNamesFromMongo(this.environment).subscribe(sites => {
        this.sitesList = ['All Sites'].concat(sites);
        this.options = this.sitesList;
      }, (error) => {
        if (error && error.status === 401) {
          location.pathname = "/site-build/unauthorized";
        } else {
          this.router.navigateByUrl('/error');
        }
      });
    }

    this.sharedDataService.getCompleteSchema().subscribe(schema => {
      this.schema = schema;
      this.siteConfigsObject['schema'] = schema;
      this.usersDataObject['schema'] = schema;
      this.apiConfigsObject['schema'] = schema;
    });

    this.sharedDataService.getSchemaApiResult().subscribe(result => {
      this.completeSchemaResult = result;
    });

    for(let i=0; i<this.numberOfRows; i++) {
      this.fullConfigsView.push(false);
      this.configChangesView.push(false);
    }

    setTimeout(() => {
      this.showRefreshBar = false;
    }, 1500);
  }

  getSelectedSiteName(val) {
    this.selectedFilterSite = val;
  }

  private _filter(value: string): string[] {
    this.options = this.sitesList;
    const filterValue = value.toLowerCase();
    return this.options.filter(option => option.toLowerCase().includes(filterValue));
  }

  isObject(item) {
    return (item && typeof item === 'object' && !Array.isArray(item));
  }

  mergeDeep(target, ...sources) {
    if (!sources.length) return target;
    const source = sources.shift();

    if (this.isObject(target) && this.isObject(source)) {
      for (const key in source) {
        if (this.isObject(source[key])) {
          if (!target[key]) Object.assign(target, { [key]: {} });
          this.mergeDeep(target[key], source[key]);
        } else {
          Object.assign(target, { [key]: source[key] });
        }
      }
    }
    return this.mergeDeep(target, ...sources);
  }

  buildSiteConfigsArray(configs, previousConfigs) {
    // { SiteName: 'apple', SiteURL: 'apple.com' }
    const tempConfigArray = [];
    Object.keys(configs).forEach(key => {
      tempConfigArray.push({
        key: this.schema.properties.site_configs.properties[key].title,
        value: `${configs[key]}`,
        previousValue: `${previousConfigs[key]}`
      });
    });
    return tempConfigArray;
  }

  clone(obj) {
    if (obj == null || typeof obj != "object") return obj;

    var temp = new obj.constructor();
    for (var key in obj) temp[key] = this.clone(obj[key]);

    return temp;
  }

  transformCustomUserData = (userData) => {
    const newTempObj = this.clone(userData);
    const customFields = userData['custom_field'] ? userData['custom_field'] : []
    customFields.forEach((customField) => {
      newTempObj[customField.COLUMN_NAME] = customField;
    });
    delete newTempObj['custom_field'];
    return newTempObj;
  }

  buildUserConfigsArray(configs, previousConfigs) {
    // { Email: { REPORT_POSITION: 2}}
    const tempConfigArray = [];

    if (configs === null) {
      return tempConfigArray;
    }

    Object.keys(configs).forEach(key => {
      let tempHtml = '', previousHtml = '';
      Object.keys(configs[key]).forEach(field => {
        if (!this.fieldsToIgnore.includes(field)) {
          tempHtml += `<div><span style="font-weight: 500; color: brown">${this.schema.definitions.user_fields.properties[field].title}</span> - <span style="margin-left: 5px; font-size:13px; color: #090909">${configs[key][field]}</span></div>`;
          previousHtml += `<div><span style="font-weight: 500; color: brown">${this.schema.definitions.user_fields.properties[field].title}</span> - <span style="margin-left: 5px; font-size:13px; color: #090909">${previousConfigs && previousConfigs[key] && previousConfigs[key][field] ? previousConfigs[key][field]: null}</span></div>`;
        }
      });
      tempConfigArray.push({
        key: this.transformedUserData[key]['DISPLAY_NAME'],
        value: tempHtml,
        previousValue: previousHtml
      });
    });
    return tempConfigArray;
  }

  viewChanges(index) {
    if (this.previouslyOpenedChanges !== -1) {
      this.toggleChangesView(this.previouslyOpenedChanges);
      // if (this.previouslyOpenedFullConfigs !== -1) {
      //   if (this.fullConfigsView[this.previouslyOpenedFullConfigs]) {
      //     this.toggleFullConfigsView(this.previouslyOpenedFullConfigs);
      //     // this.previouslyOpenedFullConfigs = this.previouslyOpenedChanges;
      //   }
      // }
    }
    this.configChangesView[index] = true;
    this.previouslyOpenedChanges = index;
    this.changesViewOpened = true;
  }

  viewConfigs(index) {
    if (this.schema) {
      this.apiConfigsObject['data'] = {
        site_configs: {},
        user_configs: {}
      };

      this.apiConfigsObject['data']['site_configs'] = this.historyList[index].CONFIGS.site_configs;
      this.apiConfigsObject['data']['user_configs'] = this.historyList[index].CONFIGS.user_configs;

      if (this.previouslyOpenedFullConfigs !== -1) {
        this.toggleFullConfigsView(this.previouslyOpenedFullConfigs);
        // if (this.previouslyOpenedChanges !== -1) {
        //   if (this.configChangesView[this.previouslyOpenedChanges]) {
        //     this.toggleChangesView(this.previouslyOpenedChanges);
        //     // this.previouslyOpenedChanges = this.previouslyOpenedFullConfigs;
        //   }
        // }
      }

      this.fullConfigsView[index] = true;
      this.previouslyOpenedFullConfigs = index;
      this.fullConfigsViewOpened = true;
    }
  }

  viewFullConfigsInDialog(index) {
    this.apiConfigsObject['data'] = {
      site_configs: {},
      user_configs: {}
    };

    this.apiConfigsObject['data']['site_configs'] = this.historyList[index].CONFIGS.site_configs;
    this.apiConfigsObject['data']['user_configs'] = this.historyList[index].CONFIGS.user_configs;
    this.apiConfigsObject['schema'] = this.schema;

    const dialogRef = this.dialog.open(AuditLogsDialogComponent, {
      width: '1200px',
      data: { view: 'full configs', apiConfigsObject: this.apiConfigsObject, changes: this.historyList[index]['CHANGES_CURRENT'],
      user: this.historyList[index].USER_NAME, timestamp: this.historyList[index].TIMESTAMP_RAW, header: 'Full Configuration' }
    });

    dialogRef.afterClosed().subscribe(result => {
    });
  };

  viewChangesInDialog(index) {
    const dialogRef = this.dialog.open(AuditLogsDialogComponent, {
      width: '850px',
      data: { view: 'changes', changes: this.historyList[index]['CHANGES'],
        user: this.historyList[index].USER_NAME, timestamp: this.historyList[index].TIMESTAMP_RAW, header: 'Review Changes' 
      }
    });

    dialogRef.afterClosed().subscribe(result => {
    });
  };

  viewPDFChangesInDialog(index) {
    this.apiConfigsObject['data'] = {
      site_configs: {},
      user_configs: {}
    };
    this.apiConfigsObject['data']['site_configs'] = this.historyList[index].CONFIGS.site_configs;
    this.apiConfigsObject['data']['user_configs'] = this.historyList[index].CONFIGS.user_configs;
    this.apiConfigsObject['schema'] = this.schema;
    const dialogRef = this.dialog.open(PrintPdfComponent, {
      width: '1250px',
      data: { view: 'full configs', apiConfigsObject: this.apiConfigsObject, changes: this.historyList[index]['CHANGES_CURRENT'],
      user: this.historyList[index].USER_NAME, timestamp: this.historyList[index].TIMESTAMP_RAW, header: 'Full Configuration' }
    });

    dialogRef.afterClosed().subscribe(result => {
    });
  };

  refreshAuditLogs() {
    this.showRefreshBar = true;
    this.ngOnInit();
  }

  toggleChangesView(index) {
    this.configChangesView[index] = !this.configChangesView[index];
    // this.changesViewOpened = this.configChangesView[index];
  }

  toggleFullConfigsView(index) {
    this.fullConfigsView[index] = !this.fullConfigsView[index];
    // this.fullConfigsViewOpened = this.fullConfigsView[index];
  }

  previousPage(currentPage) {
    if (currentPage > 1) {
      this.currentPage = parseInt(currentPage) - 1;
      this.startRows = (this.currentPage - 1) * this.numberOfRows;
      this.ngOnInit();
    }
  };

  nextPage(currentPage) {
    if (currentPage < this.numberOfPages) {
      this.currentPage = parseInt(currentPage) + 1;
      this.startRows = (this.currentPage - 1) * this.numberOfRows;
      this.ngOnInit();
    }
  };

  goToPage(page, position) {
    if (page > 0 && page <= this.numberOfPages && page > 0) {
      this.currentPage = page;
      this.currentPaginationIndex = Math.floor(this.currentPaginationIndex);
      if ((position === 'right') && (this.currentPage > (5*(this.currentPaginationIndex+1)))) {
        this.currentPaginationIndex = this.currentPaginationIndex + 1;
        if (this.currentPaginationIndex > this.maxPaginationIndex - 1) {
          this.currentPaginationIndex = this.maxPaginationIndex - 1;
        }
      }
      if ((position === 'left') && (this.currentPage <= (5*(this.currentPaginationIndex)))) {
        if (this.currentPaginationIndex > 0) {
          this.currentPaginationIndex = this.currentPaginationIndex - 1;
        }
        if (this.currentPaginationIndex < 0) {
          this.currentPaginationIndex = 0;
        }
      }
      this.startRows = (this.currentPage - 1) * this.numberOfRows;
      this.showRefreshBar = true;
      this.currentPaginationIndex = Math.ceil(this.currentPaginationIndex);
      this.ngOnInit();
    }    
  }

  changePaginationValues(value, position) {
    this.currentPaginationIndex = Math.floor(this.currentPaginationIndex);
    if ((position === 'left' && (Math.floor(value + this.currentPaginationIndex)) >= 0) || (position === 'right' && (Math.floor(value + this.currentPaginationIndex)) <= this.maxPaginationIndex)) {
      this.currentPaginationIndex += value;
      this.currentPaginationIndex = Math.floor(this.currentPaginationIndex);
      if (this.currentPaginationIndex < 0) {
        this.currentPaginationIndex = 0;
      }
      if (this.currentPaginationIndex > this.maxPaginationIndex - 1) {
        this.currentPaginationIndex = this.maxPaginationIndex - 1;
      }
      if (position === 'left') {
        this.currentPage = (this.currentPaginationIndex * 5) + 5;
      }
      if (position === 'right') {
        this.currentPage = (this.currentPaginationIndex * 5) + 1;
      }
      this.startRows = (this.currentPage - 1) * this.numberOfRows;
      this.showRefreshBar = true;
      this.currentPaginationIndex = Math.ceil(this.currentPaginationIndex);
      this.ngOnInit();
    }
  }

  fetchFilteredLogs() {
    this.showRefreshBar = true;
    this.startRows = 0;
    this.currentPage = 1;
    this.currentPaginationIndex = 0;
    this.fetchRequestedByUser = true;
    this.ngOnInit();
  }

  getDraftChanges(logs) {
    let returnControl = false;
    logs.forEach((eachLog) => {
      if (eachLog.DRAFT_STATUS === 'DRAFT') {
        Object.keys(eachLog.CHANGES_CURRENT.site_configs).forEach((currentChangesKey) => {
          if (!returnControl) {
            this.changesFromDraft.push(currentChangesKey);
          }
        });
      } else {
        returnControl = true;
      }
    });
  }

}

@Component({
  selector: 'audit-logs-configs-display',
  templateUrl: './audit-logs-configs.component.html',
})
export class AuditLogsConfigsDisplayComponent implements OnInit {

  siteConfigsKeys = [];

  @Input('data') data = null;

  ngOnInit(): void {
  }

  constructor(
  ) { }
}

export interface DialogData {
  view: string,
  apiConfigsObject: any,
  changes: string,
  user: string,
  timestamp: string,
  header: string
}
@Component({
  selector: 'audit-logs-dialog',
  templateUrl: './audit-logs-dialog.html'
})
export class AuditLogsDialogComponent implements OnInit {
  ngOnInit(): void {};

  constructor(
  public dialogRef: MatDialogRef<AuditLogsDialogComponent>,
  @Inject(MAT_DIALOG_DATA) public data: DialogData) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}