import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { TimerPopUpComponent } from '../../pages/site-create-page/site-create-page.component';
import { EnvironmentService } from '../../services/common/environment.service';
import { DataService } from '../../services/data.service';
import { SharedDataService } from '../../services/shared-data.service';

@Component({
  selector: 'app-additional-configs',
  templateUrl: './additional-configs.component.html',
  styleUrls: ['./additional-configs.component.css']
})
export class AdditionalConfigsComponent implements OnInit {

  constructor(
    private envService: EnvironmentService,
    private sharedDataService: SharedDataService,
    private dataService: DataService,
    private dialog: MatDialog
  ) { }

  newConsoleApi = '';
  visited = false;

  defaultConfigs = {
    "allowSAMLSuperUserAccess": false,
    "allowSAMLLRNUserAccess": false,
    "allowNewCertificationManager": false,
    "showLegacyFilter": false,
    "allowContentManager": false,
    "allowCatalystConnect": false,
    "isSalesSite": false,
    "allowNewCampaignManager": false
  }

  additionalConfigs = null;
  updatedAdditionalConfigs = {};
  tempAdditionalConfigs = {};
  isAdditionalConfigsAdded = false;

  ngOnInit(): void {
    this.newConsoleApi = this.envService.getAbsoluteUrl() + `/newconsole/api/public/initiateSite`;
    this.sharedDataService.getAdditionalConfigs().subscribe((result) => {
      this.additionalConfigs = result;
    });
  }

  onChange(item){
    if(!this.visited){
      for(var i in this.additionalConfigs){
        var key = this.additionalConfigs[i].key;
        this.defaultConfigs[key] = this.additionalConfigs[i].value;
      }
      this.visited = true;
    }
    item.value = !item.value;
    this.tempAdditionalConfigs[item.key] = item.value;
  }

  tempFunction() {
    for(var config in this.additionalConfigs){
      var configKey = this.additionalConfigs[config].key;
      if(this.additionalConfigs[config].value !== this.defaultConfigs[configKey] && configKey in this.tempAdditionalConfigs){
        this.updatedAdditionalConfigs[this.additionalConfigs[config].key] = this.tempAdditionalConfigs[configKey];
        this.isAdditionalConfigsAdded = true;
      }
    }
  }

  submitAdditionalConfigs() {
    const siteId = this.sharedDataService.getSiteId();
    const obj = {
      siteId: siteId,
      additionalConfigs: this.additionalConfigs
    }
    this.dataService.saveAdditionalConfigs(obj).subscribe(response => {
      const timerDialog = this.dialog.open(TimerPopUpComponent, {
        maxWidth: '850px',
        maxHeight: '350px',
        data: { timer: 5, status: true }
      });

      timerDialog.afterClosed().subscribe(() => {
        location.reload();
      });
    }, err => {
        console.log('There is some error. Uh oh', err);
        const timerDialog = this.dialog.open(TimerPopUpComponent, {
          maxWidth: '850px',
          maxHeight: '350px',
          data: { timer: 5, status: false }
        });

        timerDialog.afterClosed().subscribe(() => {
          // this.authService.login();
        });
    });
  }

}
