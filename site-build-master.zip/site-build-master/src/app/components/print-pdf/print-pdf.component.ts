import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import html2pdf from 'html2pdf.js';

@Component({
  selector: 'app-print-pdf',
  templateUrl: './print-pdf.component.html',
  styleUrls: ['./print-pdf.component.css']
})
export class PrintPdfComponent implements OnInit {
  [x: string]: any;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  ngOnInit(): void {
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.renderWidgetInsideWidgetContainer();
    }, 0);
   }

  onNoClick(): void {
    // this.dialogRef.close();
  }

  downloadPdf() {
    console.log("Downloading pdf");
    var element = document.getElementById('print-pdf');
    var opt = {
      margin:       0.75,
      filename:     `${this.data.apiConfigsObject.data.site_configs.SiteName}.pdf`,
      image:        { type: 'jpeg', quality: 0.98 },
      pagebreak:    { mode: ['css', 'legacy'] },
      html2canvas:  { scale: 2 },
      jsPDF:        { unit: 'in', format: 'a3', orientation: 'portrait', precision: 10 }
    };
    html2pdf(element, opt);
  }

}

