import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BulkSiteCreateComponent } from './bulk-site-create.component';

describe('BulkSiteCreateComponent', () => {
  let component: BulkSiteCreateComponent;
  let fixture: ComponentFixture<BulkSiteCreateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BulkSiteCreateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BulkSiteCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
