import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { TimerPopUpComponent } from '../../pages/site-create-page/site-create-page.component';
import { FileUploadService } from '../../services/common/file-upload.service';
import { SharedDataService } from '../../services/shared-data.service';

@Component({
  selector: 'app-bulk-site-create',
  templateUrl: './bulk-site-create.component.html',
  styleUrls: ['./bulk-site-create.component.css']
})
export class BulkSiteCreateComponent implements OnInit {

  constructor(
    private fileUploadService: FileUploadService, 
    private sharedDataService: SharedDataService,
    private dialog: MatDialog
  ) { }

  name:string = "-";
  type:string = "-";
  lines:any = [];
  paramsArray = [];
  file:any;

  ngOnInit(): void {
  }
  
  handleFileSelect(evt) {
    var files = evt.target.files; // FileList object
    var file = files[0];
    console.log("files", files);
    console.log("file", file);
    this.name = file.name;
    console.log("name", this.name);
    this.type = file.type;
    console.log("type", this.type);

    this.file = file;
  }

  uploadFile() {
    if(this.file) {
      this.fileUploadService.bulkFileUpload(this.file, this.name, this.type).subscribe((res) => {
        console.log("file uploaded", res);
      })
      const timerDialog = this.dialog.open(TimerPopUpComponent, {
        maxWidth: '850px',
        maxHeight: '350px',
        data: { timer: 5, status: true, message: 'Uploaded file for bulk site creation' }
      });

      timerDialog.afterClosed().subscribe(() => {
        location.reload();
      });
    }
  }

  buildParams(eachRow) {
    console.log(eachRow[0][1]);
  }

}
