import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteSettingListComponent } from './site-setting-list.component';

describe('SiteSettingListComponent', () => {
  let component: SiteSettingListComponent;
  let fixture: ComponentFixture<SiteSettingListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SiteSettingListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteSettingListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
