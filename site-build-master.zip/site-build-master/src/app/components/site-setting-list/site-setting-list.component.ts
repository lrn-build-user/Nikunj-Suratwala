import { Component, Inject, OnInit, Input, EventEmitter, Output, NgModule, ViewChild, ElementRef } from '@angular/core';
import { SiteSettingsService } from '../../services/common/site-settings.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { NgForm, AbstractControl, FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import * as $ from "jquery";
//declare var $: any;
import { EnvironmentService } from '../../services/common/environment.service';

@Component({
  selector: 'app-site-setting-list',
  templateUrl: './site-setting-list.component.html',
  styleUrls: ['./site-setting-list.component.css']
})
export class SiteSettingListComponent implements OnInit {
  @Input('showSubmitButtons') showSubmitButtons = false;
  constructor(private SiteSettingsSrv: SiteSettingsService,
    private router: Router,
    public dialog: MatDialog,
    private formBuilder: FormBuilder,
    private envService: EnvironmentService
  ) {
    this.siteSettingsForm = this.formBuilder.group({
      company: '',
      settingName: '',
      settingValue: ''
    });
  }
  public responseMessageText: string = '';

  public siteSettingsForm: FormGroup;
  baseUrl =location.origin;
  public totalCount: any = 0;
  // totalCount = 5;
  public numberOfPages: any = 5;
  public numberOfRows: any = 10;
  public currentPaginationIndex: any = 0;
  public maxPaginationIndex: any = 5;
  public currentPaginationValues: any = [];
  public pagesArray: any = [];

  public startRows: any = 0;
  public currentPage: any = 1;

  public loadingTable: boolean = true;
  public settingList: any = [];
  public showRefreshBar: boolean = false;
  public showMessageBar: boolean = false;
  public isAddSettings: boolean = false;
  public settingNameData: any =[];
  public nameData =[""];
  public listData =[""];

  companyName: string = '';
  settingName: string = '';
  settingValue: string = '';
  companyNameValidation: string = '';
  settingNameValidation: string = '';
  settingValueValidation: string = '';
  submitted = false;

  siteUrl = this.envService.getAbsoluteUrl();
  get f(): { [key: string]: AbstractControl } {
    return this.siteSettingsForm.controls;
  }
  selectedSettingName: string = '';

  //event handler for the select element's change event
  selectChangeHandler (event: any) {
    //update the ui
    this.selectedSettingName = event.target.value;
  }
  ngOnInit(): void {
    this.getSiteSAMLSettingsList();
    this.getSAMLSettingNamesList();

    this.siteSettingsForm = this.formBuilder.group({
        company: ['', Validators.required],
        settingName: ['', Validators.required],
        settingValue: ['', Validators.required],
    });
    //this.showMessageBar = false;
   
  }

  // getInputValue(val: string) {
  //   ////console.log("val is : "+val);
  //   this.companyName = val;
  //   // this.loadData();
  // }

  private getSiteSAMLSettingsList() {
    this.SiteSettingsSrv.getSiteSAMLSettingsList().subscribe(
      response => {
        /* this function is executed every time there's a new output */
        this.settingList = response.sitesList;

        this.totalCount = response.sitesList.length;
        this.loadingTable = false;
        if(this.totalCount > 0){
          this.numberOfPages = Math.ceil(this.totalCount / this.numberOfRows);
          this.maxPaginationIndex = Math.ceil(this.totalCount / this.numberOfRows);
          this.maxPaginationIndex /= 5;
          this.pagesArray = Array.from(Array(this.numberOfPages - 1).keys());
  
          this.currentPaginationValues = [];
          let tempPages = Math.min(5, (this.numberOfPages - this.currentPaginationIndex * 5));
          for (let i = 1; i <= tempPages; i++) {
            this.currentPaginationValues.push(i);
          }
        }
        else{
          this.totalCount = 0;

        }
        
      },
      err => {
        /* this function is executed when there's an ERROR */
        if (err.status == 404) {
          location.pathname = "/site-build/unauthorized";
        }
        else {
          this.router.navigateByUrl('/error');
        }
      },
      () => {
        
      }
    );

  }

  private getSAMLSettingNamesList() {
    this.SiteSettingsSrv.getSAMLSettingNamesList().subscribe(
      response => {
        /* this function is executed every time there's a new output */        
        this.settingNameData = response.siteNamesList;
        
      },
      err => {
        /* this function is executed when there's an ERROR */
        if (err.status == 404) {
          location.pathname = "/site-build/unauthorized";
        }
        else {
          this.router.navigateByUrl('/error');
        }
      },
      () => {
        
      }
    );

  }

  public addSettings() {
    // //console.log(p_courseDetails);
    // var __this = this;
    this.showMessageBar = false;
    this.isAddSettings = true;
    var siteUrl = [] = this.baseUrl.split(".",1);
      var siteName = siteUrl[0];
      
    if(siteUrl.includes("http://localhost:4200"))
      this.siteSettingsForm.controls['company'].setValue('slotest');
    else
    this.siteSettingsForm.controls['company'].setValue(siteName.replace("https://",""));
    
    this.compareSettingListAndSettingNameList();
    
    $("#overlay").addClass("modal-backdrop in");
    $("#addSiteSettings")
      .removeClass("out")
      .addClass("in")
      .show();

  } 

  compareSettingListAndSettingNameList(){
    this.nameData = [];
    this.getSiteSAMLSettingsList();
    this.getSAMLSettingNamesList();
    for(var i=0;i<this.settingNameData.length;i++){
      this.nameData.push(this.settingNameData[i].SETTING_NAME);
    }
    for(var j=0;j<this.settingList.length;j++){
      this.listData.push(this.settingList[j].SETTING_NAME);
    }
    //this.ar1.push("select2");
    //console.log("ar1 company stringify from loadData: " + JSON.stringify(this.nameData));
    //console.log("ar2 company stringify from loadData: " + JSON.stringify(this.listData));
    //this.nameData = this.ar1;
    this.nameData = this.nameData.filter(val => !this.listData.includes(val));
  
  }
  /**
 * cancelclicked
 */
  public closeModal() {
    $(
      "#addSiteSettings,#deleteConfirm"
    )
      .removeClass("in")
      .addClass("out")
      .hide();
    $("#overlay").removeClass("modal-backdrop in");
    $(document.body).removeClass("modal-open");
    this.ngOnInit();
  }

  onSubmit(event: any): void {

    if (this.siteSettingsForm.get('company')?.value === '' || this.siteSettingsForm.get('company')?.value === 'company') {
      this.companyNameValidation = ""
    }
    if (this.siteSettingsForm.get('settingName')?.value === '' || this.siteSettingsForm.get('settingName')?.value === 'settingName') {
      this.settingNameValidation = ""
    }
    if (this.siteSettingsForm.get('settingValue')?.value === '' || this.siteSettingsForm.get('settingValue')?.value === 'settingValue') {
      this.settingValueValidation = ""
    }
    //console.log("onSubmit function " + JSON.stringify(this.siteSettingsForm.value, null, 2));
  }
  submitData() {
    //console.log('I m here in submitData');
    //this.ngOnInit();
    let body = {
      company: this.siteSettingsForm.value.company,
      setting_name: this.siteSettingsForm.value.settingName,
      setting_value: this.siteSettingsForm.value.settingValue
    };
    // if (this.siteSettingsForm.get('company')?.value != '' &&
    //   this.siteSettingsForm.get('settingName')?.value != '' &&
    //   this.siteSettingsForm.get('settingValue')?.value != '')
    if(this.siteSettingsForm.get('company')?.value == '' || 
    this.siteSettingsForm.get('company')?.value == undefined)
    body.company = this.companyName;
    if(this.siteSettingsForm.get('settingName')?.value == '' || 
    this.siteSettingsForm.get('settingName')?.value == undefined)
    body.setting_name = this.settingName;
    if(body.setting_value == '' || body.setting_value == undefined || body.setting_value == null)
    return;
    //console.log("submitData after setting up: " + JSON.stringify(body));
        this.SiteSettingsSrv.addSettingsData(body).subscribe(
          response => {
            /* this function is executed every time there's a new output */
            //console.log("VALUE RECEIVED: " + response);
  
            this.showMessageBar = true;
            this.responseMessageText = response;
            setTimeout(function () {
              $(
                "#addSiteSettings"
              )
                .removeClass("in")
                .addClass("out")
                .hide();
              $("#overlay").removeClass("modal-backdrop in");
              $(document.body).removeClass("modal-open");
              //window.location.reload();
            }, 2000);
            this.ngOnInit();
  
          },
          err => {
            /* this function is executed when there's an ERROR */
            if (err.status == 404) {
              location.pathname = "/site-build/unauthorized";
            }
            else {
              this.router.navigateByUrl('/error');
            }
          },
          () => {
            //console.log("COMPLETED");
          }
        );
    
  }
  public editSettings(index: any) {
    this.isAddSettings = false;
    this.showMessageBar = false;
    //console.log("values from edit form is : " + this.settingList[index].COMPANY + " " + this.settingList[index].SETTING_NAME + " " + this.settingList[index].SETTING_VALUE);
    this.companyName = this.settingList[index].COMPANY;
    this.settingName = this.settingList[index].SETTING_NAME;
    this.settingValue = this.settingList[index].SETTING_VALUE;
    this.siteSettingsForm = this.formBuilder.group({
      company: this.companyName,
      settingName: this.settingName,
      settingValue: this.settingValue
    });
    this.selectedSettingName = this.settingName;
    // this.siteSettingsForm = this.formBuilder.group({
    //   company: this.settingList[index].COMPANY,
    //   settingName: this.settingList[index].SETTING_NAME,
    //   settingValue: this.settingList[index].SETTING_VALUE
    // });
    this.siteSettingsForm.controls['company'].setValue(this.companyName);
    this.siteSettingsForm.controls['settingName'].setValue(this.settingName);
    $(document.body).addClass("modal-open");
    $("#overlay").addClass("modal-backdrop in");
    $("#addSiteSettings")
      .removeClass("out")
      .addClass("in")
      .show();
  }

  openDelete(index) {

    const dialogRef = this.dialog.open(SettingDeleteComponent, {
      width: '500px',
      data: {
        company: this.settingList[index].COMPANY,
        id: this.settingList[index].ID,
        header: 'DELETE SAML SETTING NAMES',
        waringText: "Warning: This cannot be undone.",
        message: "Are you sure you want to delete this SAML Settings for the site?",
        confirmButtonText: "Confirm",
        cancelButtonText: "Cancel"
      }
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        let body = {
          company: this.settingList[index].COMPANY,
          setting_name: this.settingList[index].SETTING_NAME,
          setting_value: this.settingList[index].SETTING_VALUE
        };
        //console.log(this.settingList[index]);
        this.SiteSettingsSrv.deleteSettingsData(body).subscribe(
          response => {
            /* this function is executed every time there's a new output */
            //console.log("VALUE RECEIVED: " + response);

            this.showMessageBar = true;
            this.responseMessageText = response;
            this.ngOnInit();
            // setTimeout(function () {
            //   this.ngOnInit();
            // }, 100);

          },
          err => {
            /* this function is executed when there's an ERROR */
            if (err.status == 404) {
              location.pathname = "/site-build/unauthorized";
            }
            else {
              this.router.navigateByUrl('/error');
            }
          },
          () => {
            //console.log("COMPLETED");
          }
        );

      }
    });
  }
}
export interface deleteData {
  company: string,
  id: string,
  header: string,
  message: string,
  confirmButtonText: string,
  cancelButtonText: string,
  waringText: string
}
@Component({
  selector: 'confirmation-dialog',
  templateUrl: 'confirmation-dialog.html',
})
export class SettingDeleteComponent implements OnInit {
  ngOnInit(): void { };

  constructor(
    public dialogRef: MatDialogRef<SettingDeleteComponent>,
    @Inject(MAT_DIALOG_DATA) public data: deleteData) { }

  onNoClick(): void {
    this.dialogRef.close();
  }
  onConfirmClick(): void {
    this.dialogRef.close(true);
  }
}
