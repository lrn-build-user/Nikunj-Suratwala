import { Component, OnInit } from '@angular/core';
import { Input, ViewChild, ElementRef, EventEmitter, Output } from '@angular/core';
import { FileUploadService } from '../../services/common/file-upload.service';
import { SharedDataService } from '../../services/shared-data.service';

@Component({
  selector: 'app-new-file-upload',
  templateUrl: './new-file-upload.component.html',
  styleUrls: ['./new-file-upload.component.css']
})
export class NewFileUploadComponent implements OnInit {

  @Input('fileName') fileName = '';
  @Input('siteName') siteName = '';
  @Input('disabled') disabled = '';

  constructor(private fileUploadService: FileUploadService, private sharedDataService: SharedDataService) {
  }

  shortLink: String = '';
  loading: boolean =  false;
  uploadStatus = null;
  allowedImageTypes = ['jpg', 'jpeg', 'ai', 'gif', 'png'];
  filePath: string;

  public imagePath;
  imgURL: any;
  public message: string;
  remoteUrlImg = null;

  smallLogo = null;
  largeLogo = null;
  smallLogoValid = false;
  largeLogoValid = false;
  smallLogoUploaded = false;
  largeLogoUploaded = false;
  smallLogoDroparea = true;
  showLoader = false;
  fullScreen = false;
  loadingText = '';

 checkLogo(fileName) {
  if(fileName === 'LOGO_S'){
    this.smallLogoDroparea = true;
  } else {
    this.smallLogoDroparea = false;
  }
 }

  preview(files) {

    this.uploadStatus = null;
    this.smallLogoValid = false;
    this.largeLogoValid = false;

    if (files.length === 0)
      return;
    
    let imageValid = false;

    if (files.length > 0) {
      this.message = '';
      this.imgURL = null;
      imageValid = false;
      this.smallLogoUploaded = false;
      this.largeLogoUploaded = false;
    }


    var mimeType = files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      this.message = "Only images are supported.";
      imageValid = false;
      return;
    } 

    if (files[0].size > 5242880) {
      this.message = "Please upload images with size less than 5MB";
      imageValid = false;
      return;
    }

    imageValid = true;
 
    var reader = new FileReader();
    this.imagePath = files;
    reader.readAsDataURL(files[0]); 
    reader.onload = (_event) => { 
      this.imgURL = reader.result; 
    }

    console.log("Image valid?", imageValid, files[0], this.siteName);
    if (this.fileName === 'LOGO_L') {
      this.largeLogo = files[0];
      this.largeLogoValid = true;
    }
    if (this.fileName === 'LOGO_S') {
      this.smallLogo = files[0];
      this.smallLogoValid = true;
    }
  }

  ngOnInit(): void {
    if (window.location.hostname !== 'localhost') {
      this.remoteUrlImg = 'https://' + window.location.hostname.replace('.catalyst', '-lcec') + `/${this.fileName}.gif`;
    } else {
      this.remoteUrlImg = `https://slotest-lcec.qa7.lrn.com/${this.fileName}.gif`;
    }
    this.checkLogo(this.fileName);
  }

  uploadSmallLogo() {
    this.loadingText = 'Uploading small logo';
    this.showLoader = true;
    this.fullScreen = true;
    this.uploadStatus = 'sync';
    if (this.smallLogoValid) {
      this.sharedDataService.getSmallLogoStatus().next('sync');
      this.fileUploadService.upload(this.smallLogo, 'LOGO_S', this.siteName).subscribe((res) => {
        this.uploadStatus = 'done';
        this.showLoader = false;
        this.smallLogoUploaded = true;
        this.smallLogoValid = false;
        this.sharedDataService.getSmallLogoStatus().next(this.smallLogoUploaded);
      });
    }
  };

  uploadLargeLogo() {
    this.uploadStatus = 'sync';
    this.loadingText = 'Uploading large logo';
    this.showLoader = true;
    this.fullScreen = true;
    if (this.largeLogoValid) {
      this.sharedDataService.getLargeLogoStatus().next('sync');
      this.fileUploadService.upload(this.largeLogo, 'LOGO_L', this.siteName).subscribe((res) => {
        this.uploadStatus = 'done';
        this.largeLogoUploaded = true;
        this.largeLogoValid = false;
        this.showLoader = false;
        this.sharedDataService.getLargeLogoStatus().next(this.largeLogoUploaded);
      });
    }
  };

}
