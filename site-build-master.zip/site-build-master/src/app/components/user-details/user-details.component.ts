import { Component, Inject, Input, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { DataService } from '../../services/data.service';
import { SharedDataService } from '../../services/shared-data.service';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { CdkTextareaAutosize } from '@angular/cdk/text-field';
import Swal from 'sweetalert2';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {MatAccordion} from '@angular/material/expansion';
import { SiteCreatePageComponent } from '../../pages/site-create-page/site-create-page.component';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {

  @Input('apiResult') result;
  @Input('disableInputs') disableInputs = false;
  @Input('expandAll') expandAllFromParent = false;
  @Input('showSubmitButtons') showSubmitButtons = false;
  @ViewChild('autosize') autosize: CdkTextareaAutosize;
  @ViewChild(MatAccordion) accordion: MatAccordion;

  constructor(private dataService: DataService, private sharedDataService: SharedDataService, private dialog: MatDialog, private siteCreateComponent: SiteCreatePageComponent) { }

  userData = null;
  userSchema = null;
  userSchemaDefinitions = null;

  loading = true;

  apiResult = null;

  userFieldsArray = [];
  userCustomFieldsArray = [];
  userFieldMap = new Map();

  userColumnsArray = [];
  userColumns = [];
  dropDown = {};

  fieldsToIgnore = ['REPORT_POSITION','SOURCE_OF_DATA','INSTRUCTION_TEXT','SIZE', 'COLUMN_NAME', 'ATTRIBUTE_TYPE', 'FIELD_TYPE']
  mandatoryUserFields = ['Login_name', 'FirstName', 'MiddleName', 'Password', 'LastName', 'Email'];

  mappingFieldsAvailableToAdd = {
    City: 'Location',
    Division: 'Division',
    SuperFirstName: 'Supervisor First Name',
    SuperMiddleName: 'Supervisor MI',
    SuperLastName: 'Supervisor Last Name',
    CostCenter: 'Cost Center',
    HPhone: 'Home Phone',
    HZip: 'Home Zip Code',
    HAddress_1: 'Home Address',
    HAddress_2: 'Home Address',
    EmpID: 'Employee ID',
    HCity: 'Home City',
    HState: 'Home State',
    HCountry: 'Home Country',
    Title: 'Title',
    Address_1: 'Address',
    Address_2: 'Address',
    State: 'State',
    Zip: 'Zip',
    Country: 'Country',
    Phone: 'Phone',
    Language: 'Language',
    Custom_22 : 'Custom_22',
    Custom_23 : 'Custom_23',
    Custom_24 : 'Custom_24',
    Custom_25: 'Custom_25',
    Custom_26 : 'Custom_26',
    Custom_27 : 'Custom_27',
    Custom_28 : 'Custom_28',
    Custom_29  : 'Custom_29',
    Custom_30 : 'Custom_30',
    Custom_31 : 'Custom_31',
    Custom_32 : 'Custom_32',
    Custom_33: 'Custom_33',
    Custom_34 : 'Custom_34',
    Custom_35 : 'Custom_35',
    Custom_36 : 'Custom_36',
    Custom_37 : 'Custom_37',
    Custom_38 : 'Custom_38',
    Custom_39 : 'Custom_39',
    Custom_40 : 'Custom_40',
    Custom_41: 'Custom_41'
  }

  customFieldColumnNamesAvailable = [];

  selectedLanguageArray = null;
  addedFields = [];
  languageCustomFieldData = null;
  languageCustomFieldIndex = -1;
  appConfigData = null;
  internationalizationEnabled = false;
  languageCustomFieldPresent = false;
  userColumnNameArray = [];
  removedFields = [];
  highlightedUserConfigs: any = {};
  panelOpenStateStandard: boolean;
  panelOpenStateCustom: boolean;

  checked = false;
  regexForFields = {
    "Login_name": ["Alphanumeric User Name", "Special character User Name", "Allow numbers only", "Email"],
    "Password": ["At least 1 number is required for password", "At least 1 Upper and 1 Lower case letter, 1 number required for password", "At least 1 Upper and 1 Lower case letter, 1 number and 1 special character for password", "At least 1 numeric number required in the password", "At least 1 Upper and 1 Lower case letter, 1 Number, 1 special character, and no more than 3 repeating characters"],
    "FirstName": ["Allow all special characters (including spaces)", "Alphanumeric User Name", "Special character User Name"],
    "MiddleName": ["Allow all special characters (including spaces)", "Alphanumeric User Name", "Special character User Name"],
    "LastName": ["Allow all special characters (including spaces)", "Alphanumeric User Name", "Special character User Name"],
    "Email": ["Email"],
    "custom_field": ["Allow all special characters (including spaces)", "DD/MM/YYYY date field format", "MM/DD/YYYY date field format", "YYYY/MM/DD date field format", "YYYY-MM-DD date field format", "DD-MON-YYYY date field format", "MON-DD-YYYY date field format"]
  }
 
  ngOnInit(): void {

    if (this.result) {
      if (!this.result.data.user_configs['custom_field']) {
        this.userData = this.modifyUserDataForCustomFields(this.result.data.user_configs);
        this.sharedDataService.getLanguageArray().subscribe(result => {
          this.selectedLanguageArray = result;
          this.userData['custom_field'].forEach((field, index) => {
            if (field['COLUMN_NAME'] === 'Language') {
              this.userData['custom_field'][index]['DROPDOWN_ENUM'] = this.selectedLanguageArray;
            }
          });
        });
      }
    }

    this.panelOpenStateStandard = false;
    this.panelOpenStateCustom = false;

    this.sharedDataService.getConfigSchemaData().subscribe(result => {
      this.appConfigData = result;
      if (this.appConfigData['ProfileColumn'] === 'Language') {
        this.internationalizationEnabled = true;
        if (!this.languageCustomFieldPresent && this.userData) {
          this.addLanguageField();
        }
      } else if (this.appConfigData['ProfileColumn'] === null) {
        this.internationalizationEnabled = false;
        if (this.languageCustomFieldPresent && this.userData) {
          this.removeLanguageField(this.userColumnNameArray.length);
        }
      }
    });
    if (!this.disableInputs) {
      this.sharedDataService.getUserSchemaData().next(this.userData);
    }
    if (!this.highlightedUserConfigs) {
      this.highlightedUserConfigs = {};
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.result.currentValue !== null) {
      this.loading = false;
      this.apiResult = changes.result.currentValue;
      this.userData = this.apiResult.data.user_configs;
      this.userData['Login_name']['SEARCH_CRITERIA'] = true;
      this.userData['Password']['SEARCH_CRITERIA'] = false;
      this.userData['Login_name']['PRIVILEGE_VISIBILITY_LEVEL'] = false;
      this.userData['Password']['PRIVILEGE_VISIBILITY_LEVEL'] = true;
      this.userData['Login_name']['REQUIRED_FIELD'] = true;
      this.userData['Password']['REQUIRED_FIELD'] = true;
      this.userData['Login_name']['PROTECTED_FIELD'] = true;
      this.userData['Password']['PROTECTED_FIELD'] = false;
      this.userSchema = this.apiResult.schema.properties.user_configs;
      this.userSchemaDefinitions = this.apiResult.schema.definitions.user_fields.properties;

      if (!this.userData['custom_field']) {
        this.userData = this.modifyUserDataForCustomFields(this.userData);
      }

      if (this.apiResult['data']['site_configs']['ProfileColumn'] === 'Language') {
        this.internationalizationEnabled = true;
      }

      this.userData['custom_field'].forEach((field, index) => {
        if (field.COLUMN_NAME === 'Language') {
          this.languageCustomFieldData = field;
          this.languageCustomFieldIndex = index;
          this.languageCustomFieldPresent = true;
          if (!this.internationalizationEnabled) {
            this.removeLanguageField(index);
          }
        }
      });

      this.sharedDataService.getConfigSchemaData().subscribe(result => {
        this.appConfigData = result;
        if (this.appConfigData['ProfileColumn'] === 'Language') {
          this.internationalizationEnabled = true;
          if (!this.languageCustomFieldPresent && this.userData) {
            this.addLanguageField();
          }
        } else if (this.appConfigData['ProfileColumn'] === null) {
          this.internationalizationEnabled = false;
          if (this.languageCustomFieldPresent && this.userData) {
            this.removeLanguageField(this.userColumnNameArray.length);
          }
        }
      });

      this.sharedDataService.getLanguageArray().subscribe(result => {
        this.selectedLanguageArray = result;
        this.userData['custom_field'].forEach((field, index) => {
          if (field['COLUMN_NAME'] === 'Language') {
            this.userData['custom_field'][index]['DROPDOWN_ENUM'] = this.selectedLanguageArray;
          }
        });
      });

      if(!this.languageCustomFieldPresent && this.internationalizationEnabled) {
        this.addLanguageField();
      }

      Object.keys(this.userData).forEach(key => {
        if (key !== 'custom_field') {
          this.userFieldsArray.push(key);
        }
      });

      Object.keys(this.apiResult.schema.definitions.user_fields.properties).forEach(column => {
        if (!this.fieldsToIgnore.includes(column))  {
          this.userColumnsArray.push(this.apiResult.schema.definitions.user_fields.properties[column]);
          this.userColumns.push(column);
        }
      });

      this.userData['custom_field'].forEach((eachField) => {
        this.userColumnNameArray.push(eachField.COLUMN_NAME);
        if (this.userCustomFieldsArray.indexOf(eachField.DISPLAY_NAME) === -1) {
          this.userCustomFieldsArray.push(eachField.DISPLAY_NAME);
        }
        delete this.mappingFieldsAvailableToAdd[eachField.COLUMN_NAME];
      });

      Object.keys(this.mappingFieldsAvailableToAdd).forEach(key => {
        this.customFieldColumnNamesAvailable.push(key);
      });
      this.createUserFieldMap(this.userFieldsArray);
      this.sharedDataService.setCustomColumnsOrder(this.userCustomFieldsArray);
      if (!this.disableInputs) {
        this.sharedDataService.getUserSchemaData().next(this.userData);
      }

      Object.keys(this.userData).forEach(field => {
        if (field === 'custom_field') {
          this.userData['custom_field'].forEach((fieldCustom) => {
            if (!this.regexForFields['custom_field'].includes(fieldCustom['FIELD_FORMAT']) && fieldCustom['FIELD_FORMAT'] !== 'Language') {
              this.regexForFields['custom_field'].push(fieldCustom['FIELD_FORMAT']);
            }
          });
        } else {
          if(!this.regexForFields[field].includes(this.userData[field]['FIELD_FORMAT'])) {
            this.regexForFields[field].push(this.userData[field]['FIELD_FORMAT']);
          }
        }
      });

      this.highlightedUserConfigs = this.sharedDataService.getAuditLogsHighlights();
      if (!this.highlightedUserConfigs) {
        this.highlightedUserConfigs = {};
      }
      this.highlightedUserConfigs = this.highlightedUserConfigs.user_configs;
    }
  }

  addLanguageField() {
    this.userCustomFieldsArray.splice(this.userColumnNameArray.length, 0, `Language`);
    this.userColumnNameArray.splice(this.userColumnNameArray.length, 0, `Language`);
    const tempObj = {
      "COLUMN_NAME": `Language`, 
      "MAPPED_FIELD_NAME": `Language`,
      "DISPLAY_NAME": `Language`,
      "FIELD_DISPLAY_NAME": `Language`,
      "REPORT_POSITION": this.userColumnNameArray.length,
      "FIELD_POSITION": this.userColumnNameArray.length,
      "SEARCH_CRITERIA": false,
      "SOURCE_OF_DATA": null,
      "EDIT_ALLOWED": false,
      "PRIVILEGE_VISIBILITY_LEVEL": false,
      "REQUIRED_FIELD": false,
      "FIELD_TYPE": 0,
      "INSTRUCTION_TEXT": null,
      "PROTECTED_FIELD": false,
      "FIELD_FORMAT": "Language",
      "FIELD_MATCH": "Language",
      "BULKLOAD_MAPPING": `LANGUAGE`,
      "MAX_LENGTH": 4,
      "FIELD_LENGTH": 4,
      "SIZE": 40,
      "ATTRIBUTE_TYPE": "text",
      "DROPDOWN_ENUM": "English - en"
    };
    if (this.languageCustomFieldData) {
      // this.userData['custom_field'].splice(this.userColumnNameArray.length, 0, this.languageCustomFieldData);
      this.userData['custom_field'].splice(this.userColumnNameArray.length, 0, tempObj);
    } else {
      this.userData['custom_field'].splice(this.userColumnNameArray.length, 0, tempObj);
    }
    this.updateReportPositionsForUserFields();
    this.addedFields.push(Object.keys(this.mappingFieldsAvailableToAdd)[1]);
    this.sharedDataService.setCustomColumnsOrder(this.userCustomFieldsArray);
    this.languageCustomFieldPresent = true;
    this.languageCustomFieldIndex = this.userColumnNameArray.length;
  };

  removeLanguageField(index) {
    this.userCustomFieldsArray.pop();
    this.userColumnNameArray.pop();
    this.userData['custom_field'].pop();
    this.updateReportPositionsForUserFields();
    this.sharedDataService.setCustomColumnsOrder(this.userCustomFieldsArray);
    this.languageCustomFieldPresent = false;
    this.languageCustomFieldIndex = -1;
    this.sharedDataService.getUserSchemaData().next(this.userData);
  }

  clone(obj) {
    if (obj == null || typeof obj != "object") return obj;

    var temp = new obj.constructor();
    for (var key in obj) temp[key] = this.clone(obj[key]);

    return temp;
  }

  modifyUserDataForCustomFields(data) {
    const tempObj = this.clone(data);
    tempObj['custom_field'] = [];
    Object.keys(tempObj).forEach(key => {
      if (!this.mandatoryUserFields.includes(key)) {
        if (data[key]) {
          tempObj['custom_field'].push(data[key]);
          if (key !== 'custom_field') {
            delete tempObj[key];
          }
        }
      }
    });
    return tempObj;
  }

  createUserFieldMap(userFields) {
    let schemaValues = this.userSchema.properties;
    userFields.forEach(field => {
      this.userFieldMap.set(field, field !== 'custom_field');
    });
  }

  updateReportPositionsForUserFields() {
    const customFields = this.userData['custom_field'];
    customFields.forEach((field, index) => {
      this.userData['custom_field'][index].REPORT_POSITION = index + 7;
      this.userData['custom_field'][index].FIELD_POSITION = index + 7;
    });
  }

  drop(event: CdkDragDrop<string[]>) {
    if (event.previousIndex !== event.currentIndex && confirm('Are you sure you want to change the order?')) {
      moveItemInArray(this.userCustomFieldsArray, event.previousIndex, event.currentIndex);
      moveItemInArray(this.userData['custom_field'], event.previousIndex, event.currentIndex);
      this.updateReportPositionsForUserFields();
      this.sharedDataService.setCustomColumnsOrder(this.userCustomFieldsArray);
    }
  }

  removeElement(index: number) {
    const unshiftValue = this.userData['custom_field'][index]['COLUMN_NAME'];
    Swal.fire({
      title: `Are you sure you want to remove the field ${this.userData['custom_field'][index]['DISPLAY_NAME']}?`,
      confirmButtonText: '<div style="font-size:12px">Okay</div>',
      showCancelButton: true,
      cancelButtonText: '<div style="font-size:12px">Cancel</div>'
    }).then((result) => {
      if(result.isConfirmed) {
        this.removedFields.push(this.userData['custom_field'][index]['DISPLAY_NAME']);
        this.userCustomFieldsArray.splice(index, 1);
        this.userColumnNameArray.splice(index, 1);
        this.userData['custom_field'].splice(index, 1);
        this.updateReportPositionsForUserFields();
        this.sharedDataService.setCustomColumnsOrder(this.userCustomFieldsArray);
        this.sharedDataService.getRemovedFields().next(this.removedFields);
        if (unshiftValue !== 'Language') {
          this.customFieldColumnNamesAvailable.unshift(unshiftValue);
        }
      }
    });
  }

  addElement(index: number) {
    if (this.userColumnNameArray.length > 40) {
      Swal.fire({
        title: 'You cannot add custom fields anymore'
      })
    } else {
      Swal.fire({
        title: `Do you want to add a new field?`,
        confirmButtonText: '<div style="font-size:12px">Okay</div>',
        showCancelButton: true,
        cancelButtonText: '<div style="font-size:12px">Cancel</div>'
      }).then((result) => {
        if(result.isConfirmed) {
          const shiftedValue = this.customFieldColumnNamesAvailable.shift();
          let randomNumber = Math.ceil(Math.random()*100);
          while(this.userCustomFieldsArray.includes(`Custom Field ${randomNumber}`)) {
            randomNumber = Math.ceil(Math.random()*100);
          }
          if (index === 0) {
            this.userCustomFieldsArray.unshift(`Custom Field ${randomNumber}`);
            this.userColumnNameArray.unshift(`${shiftedValue}`);
          } else {
            this.userCustomFieldsArray.splice(index+1, 0, `Custom Field ${randomNumber}`);
            this.userColumnNameArray.splice(index+1, 0, `${shiftedValue}`);
          }
            const tempObj = {
              "COLUMN_NAME": `${shiftedValue}`, 
              "MAPPED_FIELD_NAME": `${shiftedValue}`,
              "DISPLAY_NAME": `Custom Field ${randomNumber}`,
              "FIELD_DISPLAY_NAME": `Custom Field ${randomNumber}`,
              "REPORT_POSITION": index+1,
              "FIELD_POSITION": index+1,
              "SEARCH_CRITERIA": true,
              "SOURCE_OF_DATA": null,
              "EDIT_ALLOWED": false,
              "PRIVILEGE_VISIBILITY_LEVEL": true,
              "REQUIRED_FIELD": false,
              "FIELD_TYPE": false,
              "INSTRUCTION_TEXT": null,
              "PROTECTED_FIELD": true,
              "FIELD_FORMAT": "Allow all special characters (including spaces)",
              "FIELD_MATCH": "Allow all special characters (including spaces)",
              "BULKLOAD_MAPPING": `CUSTOM_FIELD_${randomNumber}`,
              "MAX_LENGTH": 250,
              "FIELD_LENGTH": 250,
              "SIZE": 40,
              "ATTRIBUTE_TYPE": "text",
              "DROPDOWN_ENUM": "",
              "ADDED_ELEMENT": true
            };
            if (this.userData['custom_field'].length > 0) {
              if (this.userData['custom_field'][index]['COLUMN_NAME'] === 'Language') {
                this.userData['custom_field'].splice(index, 0, tempObj);
              } else {
                this.userData['custom_field'].splice(index + 1, 0, tempObj);
              }
            } else {
              this.userData['custom_field'].push(tempObj);
            }
            this.updateReportPositionsForUserFields();
            this.addedFields.push(shiftedValue);
            this.sharedDataService.setCustomColumnsOrder(this.userCustomFieldsArray);
            this.sharedDataService.getUserSchemaData().next(this.userData);
          }
      });
    }
  }

  convertDisplayNameToHeaderName(data) {
    let resultData = '';
    for(let i=0; i<data.length; i++) {
      const char = data[i];
      if (char.match(/[a-zA-Z0-9_]/)) {
        resultData += char.toUpperCase();
      } else {
        if (resultData[resultData.length-1] !== '_') {
          resultData += '_';
        }
      }
    }
    return resultData;
  }

  changeDropdownRegex(event, custom, index, key) {
    if (custom) {
      this.userData['custom_field'][index]['FIELD_FORMAT'] = event.value;
      const regexVal = this.userData['custom_field'][index]['FIELD_FORMAT'];
      if (regexVal.includes("YY")) {
        this.userData['custom_field'][index]['DROPDOWN_ENUM'] = "";
      }
    } else {
      this.userData[key]['FIELD_FORMAT'] = event.value;
    }
  };

  addDropDownValues(index) {
    if (!this.dropDown[index]) {
      // this.dropDown[index] = '';
      this.dropDown[index] = this.userData['custom_field'][index]['DROPDOWN_ENUM'];
    }
    const dialogRef = this.dialog.open(DialogOverviewExampleDialog, {
      width: '550px',
      height: '250px',
      data: { dropDown: this.dropDown[index], displayName: this.userData['custom_field'][index]['DISPLAY_NAME'] }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result?.dropDown !== undefined && result?.dropDown !== '' && result?.dropDown !== null) {
        this.dropDown[index] = result.dropDown;
        this.userData['custom_field'][index]['DROPDOWN_ENUM'] = this.dropDown[index];
        this.sharedDataService.getUserSchemaData().next(this.userData);
      }
    });
  };

  accordionsExpanded = false;
  toggleExpandAll(event) {
    if (this.panelOpenStateStandard && this.panelOpenStateCustom) {
      this.accordionsExpanded = true;
    } else {
      this.accordionsExpanded = false;
    }
    if (event.checked) {
      this.accordion.openAll();
      this.accordionsExpanded = true;
    } else {
      this.accordion.closeAll();
      this.accordionsExpanded = false;
    }
  }

  toggle(event, key, custom, index, field, data?:string) {
    if (custom) {
      if (event.type === 'input') {
        this.userData['custom_field'][index][field] = data;
      } else if (event.checked === true || event.checked === false) {
        this.userData['custom_field'][index][field] = event.checked;
      } else if (event.source.controlType === 'mat-select') {
        this.userData['custom_field'][index][field] = event.value;
      }
    } else {
      if (event.type === 'input') {
        this.userData[key][field] = data;
      } else if (event.checked === true || event.checked === false) {
        this.userData[key][field] = event.checked;
      } else if (event.source.controlType === 'mat-select') {
        this.userData[key][field] = event.value;
      }
    }
    if (field === 'DISPLAY_NAME') {
      data = data.substring(0, 50);
      if (this.userCustomFieldsArray.includes(data) && this.userCustomFieldsArray.indexOf(data) !== index) {
        alert(`Custom field with name "${data}" already exists`);
      }
      if (custom) {
        this.userData['custom_field'][index]['BULKLOAD_MAPPING'] = this.convertDisplayNameToHeaderName(data);
        this.userData['custom_field'][index]['DISPLAY_NAME'] = data;
      } else {
        this.userData[key]['BULKLOAD_MAPPING'] = this.convertDisplayNameToHeaderName(data);
        this.userData[key]['DISPLAY_NAME'] = data;
      }
    }
    if (custom && this.userData['custom_field'][index]['COLUMN_NAME'] === 'Language') {
      this.languageCustomFieldData = this.userData['custom_field'][index];
    }
    if (!this.disableInputs) {
      this.sharedDataService.getUserSchemaData().next(this.userData);
    }
  }

  submitForm(status) {
    this.siteCreateComponent.submitForm(status);
  }
}


export interface DialogData {
  dropDown: string,
  displayName: string
}
@Component({
  selector: 'dialog-overview-example-dialog',
  templateUrl: 'dialog-overview-example-dialog.html',
})
export class DialogOverviewExampleDialog {

  constructor(
    public dialogRef: MatDialogRef<DialogOverviewExampleDialog>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {}

  onNoClick(): void {
    this.data.dropDown = undefined;
    this.dialogRef.close();
  }

  submitValue(val) {
    this.data.dropDown = val;
    this.dialogRef.close(this.data);
  }

}