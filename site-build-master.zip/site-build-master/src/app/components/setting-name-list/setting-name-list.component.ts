import { Component, Inject, OnInit, Input, EventEmitter, Output, NgModule, ViewChild, ElementRef } from '@angular/core';
import { SiteSettingsService } from '../../services/common/site-settings.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { NgForm, AbstractControl, FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import * as $ from "jquery";

@Component({
  selector: 'app-setting-name-list',
  templateUrl: './setting-name-list.component.html',
  styleUrls: ['./setting-name-list.component.css']
})
export class SettingNameListComponent implements OnInit {
  @Input('showSubmitButtons') showSubmitButtons = false;
  constructor(private SiteSettingsSrv: SiteSettingsService,
    private router: Router,
    public dialog: MatDialog,
    private formBuilder: FormBuilder
  ) {
    this.siteSettingNameForm = this.formBuilder.group({
      company: '',
      settingName: '',
      description: '',
      id: ''
    });
  }
  // @Input()
  // public strError: string = "";
  // public strMessage: string = "";
  // public inputJson: any = {};
  // @Output()
  // public strErrorResult: EventEmitter<string> = new EventEmitter<string>();
  // @ViewChild("fileInput", { static: false }) fileInput: ElementRef;
  // @ViewChild('uploadControl') uploadControl: ElementRef;
  baseUrl =location.origin;
  public totalCount: any= 0;
  // totalCount = 5;
  public numberOfPages: any = 5;
  public numberOfRows: any = 10;
  public currentPaginationIndex: any = 0;
  public maxPaginationIndex: any = 5;
  public currentPaginationValues: any = [];
  public pagesArray: any = [];

  public startRows: any = 0;
  public currentPage: any = 1;

  public loadingTable: boolean = true;
  public settingNameList: boolean;
  public showRefreshBar: boolean = false;
  public showMessageBar: boolean = false;

  // settingData: any = [];
  public companyName: string = '';
  public settingName: string = '';
  public id: string = '';
  public message: string = '';
  public companyNameValidation: string = '';
  public settingNameValidation: string = '';
  public description: string = '';
  public descriptionValidation: string = '';
  //idValueValidation: string = '';
  // public isDataRendred: boolean = false;
  // public isNoDataAvailable = false;
  public responseMessageText: string = '';

  public siteSettingNameForm: FormGroup;

  


  ngOnInit(): void {
    
    this.getSAMLSettingNamesList();
    this.siteSettingNameForm = this.formBuilder.group({
      company: ['', Validators.required],
      settingName: ['', Validators.required],
      description: ['', Validators.required],
  });
    //this.showMessageBar = false;
  }
  submitted = false;

  get f(): { [key: string]: AbstractControl } {
    return this.siteSettingNameForm.controls;
  }

  getInputValue(val: string) {
    ////console.log("val is : "+val);
    this.companyName = val;
    this.ngOnInit();
  }

  private getSAMLSettingNamesList() {
    this.SiteSettingsSrv.getSAMLSettingNamesList().subscribe(
      response => {
        /* this function is executed every time there's a new output */
        //console.log("VALUE RECEIVED: " + response);
        this.settingNameList = response.siteNamesList;

        this.totalCount = response.siteNamesList.length;
        
        this.loadingTable = false;
        if(this.totalCount > 0){
          this.numberOfPages = Math.ceil(this.totalCount / this.numberOfRows);
          this.maxPaginationIndex = Math.ceil(this.totalCount / this.numberOfRows);
          this.maxPaginationIndex /= 5;
          this.pagesArray = Array.from(Array(this.numberOfPages - 1).keys());
  
          this.currentPaginationValues = [];
          let tempPages = Math.min(5, (this.numberOfPages - this.currentPaginationIndex * 5));
          for (let i = 1; i <= tempPages; i++) {
            this.currentPaginationValues.push(i);
          }
        }
        else{
          this.totalCount = 0;
        }
        
      },
      err => {
        /* this function is executed when there's an ERROR */
        if (err.status == 404) {
          location.pathname = "/site-build/unauthorized";
        }
        else {
          this.router.navigateByUrl('/error');
        }
      },
      () => {
        //console.log("COMPLETED");
      }
    );

  }
  goToPage(page, position) {
    if (page > 0 && page <= this.numberOfPages && page > 0) {
      this.currentPage = page;
      this.currentPaginationIndex = Math.floor(this.currentPaginationIndex);
      if ((position === 'right') && (this.currentPage > (5 * (this.currentPaginationIndex + 1)))) {
        this.currentPaginationIndex = this.currentPaginationIndex + 1;
        if (this.currentPaginationIndex > this.maxPaginationIndex - 1) {
          this.currentPaginationIndex = this.maxPaginationIndex - 1;
        }
      }
      if ((position === 'left') && (this.currentPage <= (5 * (this.currentPaginationIndex)))) {
        if (this.currentPaginationIndex > 0) {
          this.currentPaginationIndex = this.currentPaginationIndex - 1;
        }
        if (this.currentPaginationIndex < 0) {
          this.currentPaginationIndex = 0;
        }
      }
      this.startRows = (this.currentPage - 1) * this.numberOfRows;
      this.showRefreshBar = true;
      this.currentPaginationIndex = Math.ceil(this.currentPaginationIndex);
      this.ngOnInit();
    }
  }

  changePaginationValues(value, position) {
    this.currentPaginationIndex = Math.floor(this.currentPaginationIndex);
    if ((position === 'left' && (Math.floor(value + this.currentPaginationIndex)) >= 0) || (position === 'right' && (Math.floor(value + this.currentPaginationIndex)) <= this.maxPaginationIndex)) {
      this.currentPaginationIndex += value;
      this.currentPaginationIndex = Math.floor(this.currentPaginationIndex);
      if (this.currentPaginationIndex < 0) {
        this.currentPaginationIndex = 0;
      }
      if (this.currentPaginationIndex > this.maxPaginationIndex - 1) {
        this.currentPaginationIndex = this.maxPaginationIndex - 1;
      }
      if (position === 'left') {
        this.currentPage = (this.currentPaginationIndex * 5) + 5;
      }
      if (position === 'right') {
        this.currentPage = (this.currentPaginationIndex * 5) + 1;
      }
      this.startRows = (this.currentPage - 1) * this.numberOfRows;
      this.showRefreshBar = true;
      this.currentPaginationIndex = Math.ceil(this.currentPaginationIndex);
      this.ngOnInit();
    }
  }

  public closeModal() {
    $(
      "#addSiteSettings,#deleteConfirm"
    )
      .removeClass("in")
      .addClass("out")
      .hide();
    $("#overlay").removeClass("modal-backdrop in");
    $(document.body).removeClass("modal-open");
    this.ngOnInit();
  }
  public editSettingName(index) {
    this.showMessageBar = false;
    //console.log("values from edit form is : " + this.settingNameList[index].COMPANY + " " + this.settingNameList[index].SETTING_NAME + " " + this.settingNameList[index].ID);
    this.companyName = this.settingNameList[index].COMPANY;
    this.settingName = this.settingNameList[index].SETTING_NAME;
    this.description = this.settingNameList[index].DESCRIPTION;
    this.id = this.settingNameList[index].ID;
    this.siteSettingNameForm = this.formBuilder.group({
      company: this.companyName,
      settingName: this.settingName,
      description: this.description,
      id: this.id
    });    
    $(document.body).addClass("modal-open");
    $("#overlay").addClass("modal-backdrop in");
    $("#addSiteSettings")
      .removeClass("out")
      .addClass("in")
      .show();
  }
  public addSettingName() {
    var siteUrl =[] = this.baseUrl.split(".",1);
    this.showMessageBar = false;
    var siteName = siteUrl[0];
    //console.log("siteName from host : "+siteName)
    if(siteUrl.includes("http://localhost:4200"))
      this.siteSettingNameForm.controls['company'].setValue('slotest');
    else
    this.siteSettingNameForm.controls['company'].setValue(siteName.replace("https://",""));
    //console.log('I m here in add')
    $("#overlay").addClass("modal-backdrop in");
    $("#addSiteSettings")
      .removeClass("out")
      .addClass("in")
      .show();
  }

  onSubmit(event: any): void {

    
    if (this.siteSettingNameForm.get('company')?.value === '' || this.siteSettingNameForm.get('company')?.value === 'company') {
      this.companyNameValidation = ""
    }
    if (this.siteSettingNameForm.get('settingName')?.value === '' || this.siteSettingNameForm.get('settingName')?.value === 'settingName') {
      this.settingNameValidation = ""
    }
    if (this.siteSettingNameForm.get('description')?.value === '' || this.siteSettingNameForm.get('description')?.value === 'description') {
      this.descriptionValidation = ""
    }
    
  }
  submitData() {
    let body = {
      company: this.siteSettingNameForm.value.company,
      setting_name: this.siteSettingNameForm.value.settingName,
      description: this.siteSettingNameForm.value.description,
      id: this.siteSettingNameForm.value.id
    };
    
    if (this.siteSettingNameForm.get('company')?.value != '' &&
      this.siteSettingNameForm.get('settingName')?.value != '' &&
      this.siteSettingNameForm.get('description')?.value != '') {
      this.SiteSettingsSrv.addSettingNameData(body).subscribe(
        response => {
          /* this function is executed every time there's a new output */
          //console.log("VALUE RECEIVED: " + response);

          this.showMessageBar = true;
          this.responseMessageText = response;
          setTimeout(function () {
            $(
              "#addSiteSettings"
            )
              .removeClass("in")
              .addClass("out")
              .hide();
            $("#overlay").removeClass("modal-backdrop in");
            $(document.body).removeClass("modal-open");
          }, 2000);
          this.ngOnInit();

        },
        err => {
          /* this function is executed when there's an ERROR */
          if (err.status == 404) {
            location.pathname = "/site-build/unauthorized";
          }
          else {
            this.router.navigateByUrl('/error');
          }
        },
        () => {
          //console.log("COMPLETED");
        }
      );
    }
  }



  openDescription(index) {

    const dialogRef = this.dialog.open(SettingNameDialogComponent, {
      width: '500px',
      data: {
        company: this.settingNameList[index].COMPANY,
        description: this.settingNameList[index].DESCRIPTION,
        header: 'Setting Description'
      }
    });
  }

  openDelete(index) {

    const dialogRef = this.dialog.open(SettingNameDeleteComponent, {
      width: '500px',
      data: {
        company: this.settingNameList[index].COMPANY,
        id: this.settingNameList[index].ID,
        header: 'DELETE SAML SETTING NAMES',
        waringText: "Warning: This cannot be undone.",
        message: "Are you sure you want to delete this SAML Settings for the site?",
        confirmButtonText: "Confirm",
        cancelButtonText: "Cancel"
      }
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        //console.log(this.settingNameList[index]);
        let body = {      
                    company: this.settingNameList[index].COMPANY,
                    setting_name: this.settingNameList[index].SETTING_NAME,
                    description: this.settingNameList[index].DESCRIPTION,
                    id: this.settingNameList[index].ID
        };
        this.SiteSettingsSrv.deleteNameData(body).subscribe(
          response => {
            /* this function is executed every time there's a new output */
            //console.log("VALUE RECEIVED: " + response);

            this.showMessageBar = true;
            this.responseMessageText = response;
            this.ngOnInit();
            // setTimeout(function () {
            //   this.ngOnInit();
            // }, 100);

          },
          err => {
            /* this function is executed when there's an ERROR */
            if (err.status == 404) {
              location.pathname = "/site-build/unauthorized";
            }
            else {
              this.router.navigateByUrl('/error');
            }
          },
          () => {
            //console.log("COMPLETED");
          }
        );

      }
    });
  }
}


export interface descriptionData {
  company: string,
  description: string,
  header: string
}
@Component({
  selector: 'setting-name-dialog',
  templateUrl: './setting-name-dialog.html',
})
export class SettingNameDialogComponent implements OnInit {
  ngOnInit(): void { };

  constructor(
    public dialogRef: MatDialogRef<SettingNameDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: descriptionData) { }

  onNoClick(): void {
    this.dialogRef.close();
  }
}

export interface deleteData {
  company: string,
  id: string,
  header: string,
  message: string,
  confirmButtonText: string,
  cancelButtonText: string,
  waringText: string
}
@Component({
  selector: 'confirmation-dialog',
  templateUrl: 'confirmation-dialog.html',
})
export class SettingNameDeleteComponent implements OnInit {
  ngOnInit(): void { };

  constructor(
    public dialogRef: MatDialogRef<SettingNameDeleteComponent>,
    @Inject(MAT_DIALOG_DATA) public data: deleteData) { }

  onNoClick(): void {
    this.dialogRef.close();
  }
  onConfirmClick(): void {
    this.dialogRef.close(true);
  }
}

