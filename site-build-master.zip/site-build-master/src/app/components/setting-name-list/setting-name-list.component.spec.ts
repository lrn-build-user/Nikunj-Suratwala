import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SettingNameListComponent } from './setting-name-list.component';

describe('SettingNameListComponent', () => {
  let component: SettingNameListComponent;
  let fixture: ComponentFixture<SettingNameListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SettingNameListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SettingNameListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
