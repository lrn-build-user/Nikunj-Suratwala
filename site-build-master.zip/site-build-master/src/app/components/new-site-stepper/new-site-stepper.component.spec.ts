import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewSiteStepperComponent } from './new-site-stepper.component';

describe('NewSiteStepperComponent', () => {
  let component: NewSiteStepperComponent;
  let fixture: ComponentFixture<NewSiteStepperComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewSiteStepperComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NewSiteStepperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
