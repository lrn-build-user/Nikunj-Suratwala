import { Component, OnInit, ViewChild } from '@angular/core';
import { MatStepper } from '@angular/material/stepper';
import {ActivatedRoute, Router} from '@angular/router';
import { SiteCreatePageComponent, TimerPopUpComponent, ChangesPopUpComponent } from '../../pages/site-create-page/site-create-page.component';
import { EnvironmentService } from '../../services/common/environment.service';
import { JSONService } from '../../services/common/json.service';
import { DataService } from '../../services/data.service';
import { SharedDataService } from '../../services/shared-data.service';
import Swal from 'sweetalert2'
import { MatDialog } from '@angular/material/dialog';
import {MatAccordion} from '@angular/material/expansion';

@Component({
  selector: 'app-new-site-stepper',
  templateUrl: './new-site-stepper.component.html',
  styleUrls: ['./new-site-stepper.component.css']
})
export class NewSiteStepperComponent implements OnInit {

  constructor( public route:ActivatedRoute, public router:Router,
    private dataService: DataService, private envService: EnvironmentService,
    private siteCreateComponent: SiteCreatePageComponent, private sharedDataService: SharedDataService,
    private jsonService: JSONService,
    private dialog: MatDialog
  ) {}
  @ViewChild('stepper') stepper: MatStepper;
  @ViewChild(MatAccordion) accordion: MatAccordion;



  selectedEnvironment = 'US';
  selectedSiteType = 'premium';
  siteName = '';
  validatedSite = null;
  companyName = '';
  salesforceId = '';
  partnerId = '';
  siteDetailsValid = false;
  errorMessage = '';
  sitesListFetched = null;
  sitesListForPartnerId = [];
  siteNameValid = false;
  siteNameValidUS = false;
  siteNameValidEU = false;
  siteNameAvailable = false;
  siteNameStatusFetched = null;
  siteCreated = null;
  siteStatus = null;
  largeLogoStatus = false;
  smallLogoStatus = false;
  removedFields = [];
  hyphenValidated = true;
  showFetchedSites = false;

  isInternalSite = null;

  siteConfigs = null;
  userDataConfigs = null;

  previousSiteConfigs = null;
  previousUserConfigs = null;
  newSiteId = null;
  finalSiteName = '';

  panelOpenState = null;

  smallLogoURL = null;
  largeLogoURL = null;

  panelOpenStateSiteEnvironment = null;
  panelOpenStatePartnerDetails = null;
  panelOpenStateLogoUpload = null;
  panelOpenStateSiteConfigs = null;
  panelOpenStateUserConfigs = null;
  accordionArray = [];

  isAdditionalConfigsAdded = false;
  additionalConfigs = [
    {
      title: "New Certification Manager",
      key:"allowNewCertificationManager",
      value:false
    },
    {
      title: "Legacy Filter",
      key:"showLegacyFilter",
      value:false
    },
    {
      title: "Content Manager",
      key:"allowContentManager",
      value:false
    },
    {
      title: "Catalyst Connect",
      key:"allowCatalystConnect",
      value:false
    }
  ];

  defaultSiteConfigs = {
    AllowScormBulletinsContactsPolicies: false,
    RemovePrintButton: false,
    CompanyName: "LRN QA",
    EnableImportManager: false,
    CourseListModuleButton: true,
    UserToolDisablePassword: false,
    EnableCatalystAnalytics: false,
    allowNewCampaignManager: true,
    EnableDMARCDomains: false,
    DMARCDomains: "",
    CourseAICC: false,
    ShowDueDate: true,
    CourseTemplatePreference: "FluidX, FusionPlus",
    CompletionCertificate: true,
    DriveAssignment: true,
    PasswordHelp: true,
    AllowScormLaunch: false,
    DefaultLanguage: "English - en",
    BulkloadEmailNewUser: true,
    SiteName: "Legal Compliance and Ethics Center",
    ShowLoginButton: false,
    EnableDashboardManager: false,
    PasswordChangePrompt: true,
    SiteCustomizer: true,
    BulkloadEmailSubject: "Welcome to the Legal Compliance and Ethics Center",
    WindowTitle: "LCEC: ",
    CERT2: false,
    EnableVirtualCatalyst: false,
    ProfileColumn: null,
    Webmaster: "support@lrn.com",
    Media: "video",
    EnableRegistry: false,
    HomeStyle: "3",
    BulkloadEmailSender: "sysgen@lrn.com",
    ShowHelpButton: true,
    EnableGDPR: false,
    CourseListID: false,
    EnableDataPrivacy: false,
    InitialAudioOn: true,
    AICCCourseReset: false,
    BulkloadGateway: false,
    CourseCustomDescriptionsTitle: "Module List Description",
    AllowScormExport: false,
    UseCaseInsensitivePassword: false,
    RegistrationType: "Type 1 (Client uploading users via files through Bulkload Manager)",
    CourseAkamai: true,
    SSLRequire: true,
    DefaultViewAllModules: false,
    CumulativeTimeTracking: true,
    ProfileColumnDefault: "en",
    AllowSelfReg: true,
    AutoBulkload: true,
    AllowSelfEdit: false,
    SSOEnabled: true,
    SiteURL: `https://internal.catalyst.lrn.com`,
    internationalize_site: true,
  };

  defaultUserConfigs = {
    Login_name: {
        FIELD_POSITION: 1,
        FIELD_NAME: "USERID",
        MAPPED_FIELD_NAME: "Login_name",
        REQUIRED_FIELD: true,
        FIELD_LENGTH: 50,
        FIELD_MATCH: "^\\S+.*\\S+$",
        PROTECTED_FIELD: true,
        FIELD_DISPLAY_NAME: "User Name",
        FIELD_TYPE: 0,
        COLUMN_NAME: "Login_name",
        DISPLAY_NAME: "User Name",
        REPORT_POSITION: 1,
        SEARCH_CRITERIA: true,
        SOURCE_OF_DATA: null,
        EDIT_ALLOWED: true,
        PRIVILEGE_VISIBILITY_LEVEL: false,
        INSTRUCTION_TEXT: null,
        FIELD_FORMAT: "^\\S+.*\\S+$",
        BULKLOAD_MAPPING: "USERID",
        MAX_LENGTH: 50,
        SIZE: 40,
    },
    Password: {
        FIELD_POSITION: 2,
        FIELD_NAME: "PASSWORD",
        MAPPED_FIELD_NAME: "Password",
        REQUIRED_FIELD: true,
        FIELD_LENGTH: 20,
        FIELD_MATCH: "^\\S+$",
        PROTECTED_FIELD: true,
        FIELD_DISPLAY_NAME: "Password",
        FIELD_TYPE: null,
        COLUMN_NAME: "Password",
        DISPLAY_NAME: "Password",
        REPORT_POSITION: 2,
        SEARCH_CRITERIA: true,
        SOURCE_OF_DATA: null,
        EDIT_ALLOWED: false,
        PRIVILEGE_VISIBILITY_LEVEL: false,
        INSTRUCTION_TEXT: null,
        FIELD_FORMAT: "^\\S+$",
        BULKLOAD_MAPPING: "PASSWORD",
        MAX_LENGTH: 20,
        SIZE: 20,
    },
    FirstName: {
        FIELD_POSITION: 3,
        FIELD_NAME: "FNAME",
        MAPPED_FIELD_NAME: "FirstName",
        REQUIRED_FIELD: true,
        FIELD_LENGTH: 250,
        FIELD_MATCH: "^[\\S\\ ]*$",
        PROTECTED_FIELD: false,
        FIELD_DISPLAY_NAME: "First Name",
        FIELD_TYPE: 0,
        COLUMN_NAME: "FirstName",
        DISPLAY_NAME: "First Name",
        REPORT_POSITION: 3,
        SEARCH_CRITERIA: true,
        SOURCE_OF_DATA: null,
        EDIT_ALLOWED: true,
        PRIVILEGE_VISIBILITY_LEVEL: false,
        INSTRUCTION_TEXT: null,
        FIELD_FORMAT: "^[\\S\\ ]*$",
        BULKLOAD_MAPPING: "FNAME",
        MAX_LENGTH: 250,
        SIZE: 15,
    },
    MiddleName: {
        FIELD_POSITION: 4,
        FIELD_NAME: "MI",
        MAPPED_FIELD_NAME: "MiddleName",
        REQUIRED_FIELD: false,
        FIELD_LENGTH: 250,
        FIELD_MATCH: "^[\\S\\ ]*$",
        PROTECTED_FIELD: false,
        FIELD_DISPLAY_NAME: "Middle Initial",
        FIELD_TYPE: 0,
        COLUMN_NAME: "MiddleName",
        DISPLAY_NAME: "Middle Initial",
        REPORT_POSITION: 4,
        SEARCH_CRITERIA: true,
        SOURCE_OF_DATA: null,
        EDIT_ALLOWED: true,
        PRIVILEGE_VISIBILITY_LEVEL: false,
        INSTRUCTION_TEXT: null,
        FIELD_FORMAT: "^[\\S\\ ]*$",
        BULKLOAD_MAPPING: "MI",
        MAX_LENGTH: 250,
        SIZE: 2,
    },
    LastName: {
        FIELD_POSITION: 5,
        FIELD_NAME: "LNAME",
        MAPPED_FIELD_NAME: "LastName",
        REQUIRED_FIELD: true,
        FIELD_LENGTH: 250,
        FIELD_MATCH: "^[\\S\\ ]*$",
        PROTECTED_FIELD: false,
        FIELD_DISPLAY_NAME: "Last Name",
        FIELD_TYPE: 0,
        COLUMN_NAME: "LastName",
        DISPLAY_NAME: "Last Name",
        REPORT_POSITION: 5,
        SEARCH_CRITERIA: true,
        SOURCE_OF_DATA: null,
        EDIT_ALLOWED: true,
        PRIVILEGE_VISIBILITY_LEVEL: false,
        INSTRUCTION_TEXT: null,
        FIELD_FORMAT: "^[\\S\\ ]*$",
        BULKLOAD_MAPPING: "LNAME",
        MAX_LENGTH: 250,
        SIZE: 15,
    },
    Email: {
        FIELD_POSITION: 6,
        FIELD_NAME: "EMAIL",
        MAPPED_FIELD_NAME: "Email",
        REQUIRED_FIELD: false,
        FIELD_LENGTH: 100,
        FIELD_MATCH: "^[\\w\\-\\@\\.]+$",
        PROTECTED_FIELD: false,
        FIELD_DISPLAY_NAME: "E-Mail Address",
        FIELD_TYPE: null,
        COLUMN_NAME: "Email",
        DISPLAY_NAME: "E-Mail Address",
        REPORT_POSITION: 6,
        SEARCH_CRITERIA: true,
        SOURCE_OF_DATA: null,
        EDIT_ALLOWED: false,
        PRIVILEGE_VISIBILITY_LEVEL: false,
        INSTRUCTION_TEXT: null,
        FIELD_FORMAT: "^[\\w\\-\\@\\.]+$",
        BULKLOAD_MAPPING: "EMAIL",
        MAX_LENGTH: 100,
        SIZE: 40,
    },
    custom_field: []
  };

 schema = {
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "properties": {
    "site_id": {
      "type": "integer",
      "title": "Site Id"
    },
    "site_configs": {
      "type": "object",
      "properties": {
        "SiteURL": {
          "type": "string",
          "title": "Site URL",
          "header": "General Info",
          "tag": "generalInfo"
        },
        "SiteName": {
          "type": "string",
          "title": "Site Name",
          "tag": "generalInfo"
        },
        "CompanyName": {
          "type": "string",
          "title": "Company Name",
          "tag": "generalInfo"
        },
        "RegistrationType": {
          "type": "string",
          "title": "Registration Type",
          "enum": ["Type 1 (Client uploading users via files through Bulkload Manager)", "Type 2 (Initial bulkload and then Self-register)", "Type 3 (Self-Registration)"],
          "description": "Registration",
          "default": "Type 1 (Client uploading users via files through Bulkload Manager)",
          "tag": "generalInfo"
        },
        "EnableDashboardManager": {
          "type": "boolean",
          "title": "Enable Dashboard Manager",
          "header": "Tool Enabling",
          "tag": "toolsControl"
        },
        "CERT2": {
          "type": "boolean",
          "title": "Enable Completion Certificate v2",
          "tag": "toolsControl"
        },
        "EnableVirtualCatalyst": {
          "type": "boolean",
          "title": "Enable Catalyst Offline",
          "description": "real-time",
          "tag": "toolsControl"
        },
        "EnableImportManager": {
          "title": "Enable Import Manager",
          "type": "boolean",
          "description": "real-time",
          "tag": "toolsControl"
        },
        "EnableGDPR": {
          "type": "boolean",
          "title": "Enable GDPR",
          "tag": "toolsControl"
        },
        "EnableCatalystAnalytics": {
          "type": "boolean",
          "title": "Enable Catalyst Analytics",
          "tag": "toolsControl"
        },
        "allowNewCampaignManager": {
          "type": "boolean",
          "title": "Enable New Campaign Manager",
          "tag": "toolsControl"
        },
        "EnableRegistry": {
          "type": "boolean",
          "title": "Enable Registry Tab In Console",
          "description": "real-time",
          "tag": "toolsControl"
        },
        "internationalize_site": {
          "type": "boolean",
          "title": "Internationalize Site",
          "tag": "toolsControl"
        },
        "ProfileColumn": {
          "type": "string",
          "title": "Profile Column",
          "tag": "toolsControl"
        },
        "DefaultLanguage": {
          "type": "string",
          "title": "Default Language",
          "enum": [
            "Afrikaans - afZA",
            "Albanian - sqAL",
            "Amharic - amET",
            "Arabic - arSA",
            "Arabic - Egypt - arEG",
            "Arabic (Morocco) - arMA",
            "Bengali - bnIN",
            "Bosnian - bsBS",
            "Bulgarian - bgBG",
            "Burmese - myMM",
            "Catalan - caES",
            "Chinese (Simplified) - zhCN",
            "Chinese (Traditional, Hong Kong) - zhHK",
            "Chinese (Traditional, Taiwan) - zhTW",
            "Croatian - hrHR",
            "Czech - csCZ",
            "Danish - daDK",
            "Dutch - nlNL",
            "English - en",
            "English (International) - enIE",
            "English (United Kingdom) - enUK",
            "Estonian - etEE",
            "Finnish - fiFI",
            "Flemish - nlBE",
            "French (Canada) - frCA",
            "French (Europe) - frFR",
            "German (Germany) - deDE",
            "Greek - elGR",
            "Gujarati - guIN",
            "Hebrew - heIL",
            "Hindi - hiIN",
            "Hmong - hmLA",
            "Hungarian - huHU",
            "Icelandic - isIS",
            "Indonesian - idID",
            "Italian - itIT",
            "Japanese - jaJP",
            "Kannada - knIN",
            "Kazakh - kkKZ",
            "Khmer - kmKM",
            "Korean - koKR",
            "Laotian - loLA",
            "Latvian - lvLV",
            "Lithuanian - ltLT",
            "Macedonian - mkMK",
            "Malay - msMY",
            "Malayalam - mlIN",
            "Marathi - mrIN",
            "Mongolian - mnMN",
            "Montenegrin - meME",
            "Nepali - neNP",
            "Norwegian - noNO",
            "Polish - plPL",
            "Portuguese (Brazil) - ptBR",
            "Portuguese (Portugal) - ptPT",
            "Romanian - roRO",
            "Russian - ruRU",
            "Serbian - srYU",
            "Sinhalese - siSI",
            "Slovakian - skSK",
            "Slovenian - slSI",
            "Somali - soSO",
            "Spanish (Europe) - esES",
            "Spanish (Latin America) - esLA",
            "Swahili - swKE",
            "Swedish - svSE",
            "Tagalog - tlPH",
            "Tamil - taIN",
            "Thai - thTH",
            "Turkish - trTR",
            "Ukrainian - ukUA",
            "Urdu Indian - urIN",
            "Urdu Pakistani - urPK",
            "Vietnamese - viVN",
            "Zulu - zuZA"
          ],
          "description": "Default Language",
          "default": "English - en",
          "tag": "toolsControl"
        },
        "RemoveLanguageFromBLM": {
          "type": "boolean",
          "title": "Remove Language Field From Bulkload Manager",
          "tag": "toolsControl"
        },
        "CourseListModuleButton": {
          "title": "Display Course Catalog Tab",
          "type": "boolean",
          "tag": "toolsControl"
        },
        "EnableDataPrivacy": {
          "title": "Enable Data Privacy",
          "type": "boolean",
          "tag": "toolsControl"
        },
        "BulkloadGateway": {
          "type": "boolean",
          "title": "API Bulkload",
          "header": "Bulkload Management",
          "tag": "bulkloadManagement"
        },
        "BulkloadEmailNewUser": {
          "type": "boolean",
          "title": "Activate Bulkload Confirmation Email",
          "tag": "bulkloadManagement"
        },
        "BulkloadEmailSubject": {
          "type": "string",
          "title": "Bulkload Email Subject",
          "tag": "bulkloadManagement"
        },
        "BulkloadEmailSender": {
          "type": "string",
          "title": "Bulkload Email Sender",
          "pattern": "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+[.]{1}[a-zA-Z]+$",
          "message": {
            "pattern": "Email Format is incorrect, please enter a valid email",
            "required": "Email is a required field"
          },
          "tag": "bulkloadManagement"
        },
        "silent_logon": {
          "type": "string",
          "title": "Silent Logon",
          "enum": ["Silent Logon Only", "Silent Logon and Conventional", "Conventional"],
          "header": "Security",
          "description": "Silent Logon",
          "default": "Silent Logon Only",
          "tag": "security"
        },
        "PasswordChangePrompt": {
          "type": "boolean",
          "title": "Password Prompt Feature",
          "tag": "security"
        },
        "Webmaster": {
          "type": "string",
          "title": "Forgot Your Password From",
          "default": "support@lrn.com",
          "tag": "security"
        },
        "UserToolDisablePassword": {
          "title": "Change Passwords In User Profile",
          "type": "boolean",
          "tag": "security"
        },
        "PasswordHelp": {
          "title": "Forgot Your Password Feature",
          "type": "boolean",
          "tag": "security"
        },
        "CourseAICC": {
          "type": "boolean",
          "title": "LMS Integration",
          "header": "LMS Integration",
          "tag": "LMSIntegration"
        },
        "AllowScormLaunch": {
          "title": "Enable LRN Hosted Feature",
          "type": "boolean",
          "tag": "LMSIntegration"
        },
        "AllowScormExport": {
          "title": "Enable Scorm Export",
          "type": "boolean",
          "tag": "LMSIntegration"
        },
        "AICCCourseReset": {
          "type": "boolean",
          "title": "AICC Course Reset",
          "tag": "LMSIntegration"
        },
        "EnableDMARCDomains": {
          "title": "Enable DMARC Domains",
          "type": "boolean",
          "tag": "moduleSettings"
        },
        "DMARCDomains": {
          "title": "DMARC Domains",
          "type": "string",
          "tag": "moduleSettings"
        },
        "Media": {
          "type": "string",
          "title": "Media Setting",
          "enum": ["audio", "video"],
          "header": "Module Settings",
          "description": "Media Format",
          "tag": "moduleSettings"
        },
        "InitialAudioOn": {
          "title": "Initial Audio / Video",
          "type": "boolean",
          "tag": "moduleSettings"
        },
        "RemovePrintButton": {
          "title": "Display Module Print Button",
          "type": "boolean",
          "tag": "moduleSettings"
        },
        "ShowDueDate": {
          "title": "Show Due Date Column In To-do List",
          "type": "boolean",
          "tag": "moduleSettings"
        },
        "AllowScormBulletinsContactsPolicies": {
          "title": "Allow Access to Bulletins Contacts and Policies",
          "type": "boolean",
          "tag": "moduleSettings"
        },
        "CourseTemplatePreference": {
          "type": "string",
          "title": "Course Template Preferences",
          "enum": ["FluidX", "FusionPlus", "FluidX,FusionPlus,html5plusForMobileDevices"],
          "description": "Course Template Preferences",
          "tag": "moduleSettings"
        }
      },
      "required": [
      ]
    },
    "user_configs": {
      "type": "object",
      "properties": {
          "Login_name": {
              "type": "object",
              "maxLength": 20,
              "title": "User Id",
              "$ref": "#/definitions/user_fields"
          },
          "FirstName": {
              "description": "First Name",
              "type": "object",
              "maxLength": 40,
              "title": "First Name",
              "$ref": "#/definitions/user_fields"
          },
          "MiddleName": {
              "type": "object",
              "maxLength": 20,
              "title": "Middle Initial",
              "$ref": "#/definitions/user_fields"
          },
          "LastName": {
              "description": "Last Name",
              "type": "object",
              "maxLength": 40,
              "title": "Last Name",
              "$ref": "#/definitions/user_fields"
          },
          "Email": {
              "description": "Email Id",
              "title": "Email Id",
              "type": "object",
              "maxLength": 100,
              "pattern": "^[\\w\\-\\@\\.]+$",
              "$ref": "#/definitions/user_fields"
          },
          "custom_field": {
            "type": "array",
            "maxItems": 60,  
            "items": {
              "type": "object",
              "$ref": "#/definitions/custom_user_field"
            }
          }
      },
      "required": []
    }
  },
  "definitions": {
    "user_fields": {
      "type": "object",
      "properties": {
        "COLUMN_NAME": {
          "type": "string",
          "title": "Header Name"
        },
        "DISPLAY_NAME": {
          "type": "string",
          "title": "Display Name"
        },
        "BULKLOAD_MAPPING": {
          "type": "string",
          "title": "Bulkload Mapping"
        },
        "MAX_LENGTH": {
          "type": "integer",
          "title": "Maximum Length of the Field"
        },
        "REPORT_POSITION": {
          "type": "integer",
          "title": "Position"
        },
        "SEARCH_CRITERIA": {
          "type": "boolean",
          "title": "Filter In Reports"
        },
        "EDIT_ALLOWED": {
          "type": "boolean",
          "title": "Edit Allowed"
        },
        "PRIVILEGE_VISIBILITY_LEVEL": {
          "type": "boolean",
          "title": "Hide in User Profile"
        },
        "REQUIRED_FIELD": {
          "type": "boolean",
          "title": "Required Field"
        },
        "FIELD_TYPE": {
          "type": "boolean",
          "title": "Field Type"
        },
        "INSTRUCTION_TEXT": {
          "type": "string",
          "title": "Instruction Text"
        },
        "PROTECTED_FIELD": {
          "type": "boolean",
          "title": "Protected Field"
        },
        "FIELD_FORMAT": {
          "type": "string",
          "title": "Regular Expression for the field"
        },
        "SIZE": {
          "type": "integer",
          "title": "Size of the Field"
        },
        "ATTRIBUTE_TYPE": {
          "type": "string",
          "enum": ["text", "bool", "password"]
        },
        "DROPDOWN_ENUM": {
          "type": "string",
          "title": "Dropdown options"
        },
        "SOURCE_OF_DATA": {
          "type": "string",
          "title": "Source of Data"
        },
        "ADDED_ELEMENT": {
          "type": "boolean",
          "title": "Added Element"
        },
        "COMPANY": {
          "type": "string",
          "title": "Company"
        }
      }
    },
    "custom_user_field": {
      "type": "object",
      "$ref": "#/definitions/user_fields"
    }
  },
  "required": [
    "site_id"
  ]
}

  apiObject = {
    "data": {
      "site_configs": this.defaultSiteConfigs,
      "user_configs": this.defaultUserConfigs,
      "site_id": this.newSiteId
    },
    "schema": this.schema
  }

  ngOnInit() {
    this.panelOpenState = false;
    this.panelOpenStateSiteEnvironment = false;
    this.panelOpenStatePartnerDetails = false;
    this.panelOpenStateLogoUpload = false; 
    this.panelOpenStateSiteConfigs = false;
    this.panelOpenStateUserConfigs = false;
    this.accordionArray = [
      this.panelOpenStateSiteEnvironment,
      this.panelOpenStatePartnerDetails,
      this.panelOpenStateLogoUpload,
      this.panelOpenStateSiteConfigs,
      this.panelOpenStateUserConfigs,
    ]
    this.sharedDataService.getLargeLogoStatus().subscribe((status) => {
      this.largeLogoStatus = status;
    });
    this.sharedDataService.getSmallLogoStatus().subscribe((status) => {
      this.smallLogoStatus = status;
    });
    if (this.envService.getAbsoluteUrl().includes("internal.catalyst")) {
      this.isInternalSite = true;
    } else {
      this.isInternalSite = false;
    }
    this.isInternalSite = true;
    this.sharedDataService.getConfigSchemaData().subscribe(res => {
      this.siteConfigs = res;
    });
    this.sharedDataService.getUserSchemaData().subscribe(res => {
      this.userDataConfigs = res;
    });
    this.sharedDataService.getRemovedFields().subscribe(vals => {
      this.removedFields = vals;
    });
    this.previousSiteConfigs = this.siteCreateComponent.clone(this.defaultSiteConfigs);
    this.previousUserConfigs = this.siteCreateComponent.clone(this.defaultUserConfigs);
    if (window.location.hostname !== 'localhost') {
      this.smallLogoURL = 'https://' + window.location.hostname.replace('.catalyst', '-lcec') + `/LOGO_S.gif`;
      this.largeLogoURL = 'https://' + window.location.hostname.replace('.catalyst', '-lcec') + `/LOGO_L.gif`;
    } else {
      this.smallLogoURL = `https://slotest-lcec.qa7.lrn.com/LOGO_S.gif`;
      this.largeLogoURL = `https://slotest-lcec.qa7.lrn.com/LOGO_L.gif`;
    }
  }

  changeEnvironmentRadio(event) {
    console.log("Changed Radio nutton env: ", event);
    this.selectedEnvironment = event.value;
    this.siteName = '';
    this.sitesListForPartnerId = [];
    this.partnerId = '';
    this.companyName = ''
    this.salesforceId = '';
    this.sitesListFetched = null;
  }

  clickMethod() {
    this.showFetchedSites = !this.showFetchedSites;
  }

  saveSmallLogoURL(obj) {
    this.smallLogoURL = obj;
  }

  saveLargeLogoURL(obj) {
    this.largeLogoURL = obj;
  }

  changeSiteTypeRadio(event) {
    console.log("Changed Radio nutton site type: ", event);
    this.selectedSiteType = event.value;
  }

  inputText() {
    this.errorMessage = '';
    if (this.partnerId !== '') {
      if (!this.sitesListForPartnerId.includes(this.siteName) && this.siteName.length > 1 && this.siteName.trim() !== '') {
        this.siteNameValid = true;
      } else {
        this.siteNameValid = false;
      }
      // this.siteDetailsValid = true;
    }
  }

  onChange(item){
    item.value = !item.value;
  }

  accordionsExpanded = false;
  isAllAccordionsExpanded(){
    for(let i in this.accordionArray) {
      if(this.accordionArray[i] === true){
        this.accordionsExpanded = true;
      } else {
        this.accordionsExpanded = false;
        return;
      }
    }
    
  }
  toggleExpandAll(event) {
    this.isAllAccordionsExpanded();
    if (event.checked) {
      this.accordion.openAll();
      this.accordionsExpanded = true;
      for(let i in this.accordionArray) {
        this.accordionArray[i] = this.accordionsExpanded;
      }
    } else {
      this.accordion.closeAll();
      this.accordionsExpanded = false;
      for(let i in this.accordionArray) {
        this.accordionArray[i] = this.accordionsExpanded;
      }
    }
  }

  validateSalesforceId(event){
    var inp = String.fromCharCode(event.keyCode);
    if (/[a-zA-Z0-9]/.test(inp)) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  fetchSitesListForPartnerId() {
    this.siteName = '';
    if (this.partnerId !== '') {
      this.sitesListFetched = false;
      this.dataService.fetchSitesListForPartnerId(this.partnerId, this.selectedEnvironment).subscribe((result) => {
        this.sitesListForPartnerId = result.sitesList;
        this.siteStatus = result.sitesActiveStatus;
        this.companyName = result.partnerName;
        this.sitesListFetched = true;
        this.siteNameStatusFetched = null;
      }, (error) => {
        if (error && error.status === 401) {
          location.pathname = "/site-build/unauthorized";
        } else {
          this.router.navigateByUrl('/error');
        }
      });
    }
  }

  validateSiteName() {
    this.siteNameStatusFetched = false;
    const validatingSite = this.siteName;
    this.dataService.validateSiteName(this.siteName).subscribe(result => {
      this.siteNameAvailable = result.siteValid;
      this.validatedSite = validatingSite;
      this.siteNameStatusFetched = true;
      this.finalSiteName = this.siteName;
    }, (error) => {
      if (error && error.status === 401) {
        location.pathname = "/site-build/unauthorized";
      } else {
        this.router.navigateByUrl('/error');
      }
    });
  }

  validateHyphen(event) {
    this.hyphenValidated = true;
    console.log(event);
    if(event[event.length-1] === '-' || this.siteName[0] === '-') {
      this.hyphenValidated = false;
    }
    if((this.siteName.match(/-/g) || []).length > 2) {
      this.hyphenValidated = false;
    }
  }

  createSite() {
    this.siteCreated = false;
    const siteObj = {
      siteName: this.siteName,
      companyName: this.companyName,
      partnerId: this.partnerId,
      salesforceId: this.salesforceId,
      siteType: this.selectedSiteType,
      environment: this.selectedEnvironment,
      sitePurpose: 'qa'
    };
    this.dataService.createSite(siteObj).subscribe(result => {
      this.siteCreated = true;
      this.newSiteId = result.siteId;
      console.log("Site Id for the newly created site: ", this.newSiteId);
      this.sitesListForPartnerId.push(this.siteName);
    }, (error) => {
      if (error && error.status === 401) {
        location.pathname = "/site-build/unauthorized";
      } else {
        this.router.navigateByUrl('/error');
      }
    });
  }

  nextFromSiteDetails(stepper: MatStepper) {
    console.log("SiteName: ", this.siteName, "CompanyName: ", this.companyName, "Partner ID: ", this.partnerId, this.siteDetailsValid, stepper);
    if (this.siteDetailsValid) {
      this.dataService.validateSiteDetails(this.siteName, this.companyName, this.partnerId).subscribe((result) => {
        console.log("Result is: ", result);
        if (!result.error) {
          this.errorMessage = '';
          stepper.next();
        } else {
          this.errorMessage = result.error;
          this.siteDetailsValid = false;
        }
      }, (error) => {
        console.log("Error is: ", error);
        this.errorMessage = error;
        this.siteDetailsValid = false;
        if (error && error.status === 401) {
          location.pathname = "/site-build/unauthorized";
        } else {
          this.router.navigateByUrl('/error');
        }
      });
    }
  }

  reloadPage() {
    location.reload();
  }

  clickedSubmitDetailsTab(event) {
    if (event.selectedIndex === 5) {
      const obj = {
        "data": {
          "site_configs": this.siteConfigs,
          "user_configs": this.userDataConfigs,
          "site_id": this.newSiteId
        },
        "schema": this.schema
      }
      this.apiObject = obj;
    }
  }

  submitConfigs() {
    // this.siteCreateComponent.submitForm();
    const siteDiff = this.jsonService.getObjectDiff(this.previousSiteConfigs, this.siteConfigs, false);
    // this.userDataConfigs = this.siteCreateComponent.transformCustomUserData(this.userDataConfigs);
    const userDiff = this.jsonService.getObjectDiff(this.previousUserConfigs, this.userDataConfigs, false);
    console.log("Used to submit!", siteDiff, userDiff);

    this.siteConfigs['SiteURL'] = this.siteConfigs['SiteURL'].replace('internal', `${this.siteName}`);

    var updatedAdditionalConfigs = {
      "siteId": this.newSiteId
    }

    const currentConfigs = {
      "site_id": this.newSiteId,
      "site_configs": this.siteConfigs,
      "user_configs": this.userDataConfigs
    };

    const previousConfigs = {
      "site_id": this.newSiteId,
      "site_configs": this.previousSiteConfigs,
      "user_configs": this.previousUserConfigs
    };

    for(var config in this.additionalConfigs){
      if(this.additionalConfigs[config].value === true){
        updatedAdditionalConfigs[this.additionalConfigs[config].key] = this.additionalConfigs[config].value;
        this.isAdditionalConfigsAdded = true;
      }
    }

    console.log("Previous user configs: ", this.previousUserConfigs);

    let params = {
      "currentConfig": currentConfigs,
      "previousConfig": previousConfigs,
      "additionalConfigs": updatedAdditionalConfigs
    };

    const transformedPreviousConfigs = {
      "site_id": this.newSiteId,
      "site_configs": this.previousSiteConfigs,
      "user_configs": this.siteCreateComponent.transformCustomUserData(this.previousUserConfigs)
    };

    const transformedCurrentConfigs = {
      "site_id": this.newSiteId,
      "site_configs": this.siteConfigs,
      "user_configs": this.siteCreateComponent.transformCustomUserData(this.userDataConfigs)
    };

    var siteDetails = {
      "partnerId": this.partnerId,
      "siteId": this.newSiteId,
      "siteName": this.siteName,
      "companyName": this.companyName,
      "salesforceId": this.salesforceId,
      "additionalConfigs": this.isAdditionalConfigsAdded,
    }

    this.siteCreateComponent.mapDisplayNameWithColumnName(this.userDataConfigs);

    let diff = this.jsonService.getObjectDiff(transformedPreviousConfigs, transformedCurrentConfigs, false);
    let prevDiff = this.jsonService.getObjectDiff(transformedCurrentConfigs, transformedPreviousConfigs, false);

    if(diff && diff['site_configs']) {
      diff = this.siteCreateComponent.deleteConfigsFromDiff(diff);
    }

    if(diff && diff['site_configs'] && Object.keys(diff['site_configs']).length === 0) {
      delete diff['site_configs'];
    }

    if(prevDiff && prevDiff['site_configs']) {
      prevDiff = this.siteCreateComponent.deleteConfigsFromDiff(prevDiff);
    }

    if(prevDiff && prevDiff['site_configs'] && Object.keys(prevDiff['site_configs']).length === 0) {
      delete prevDiff['site_configs'];
    }



    let diffString = this.siteCreateComponent.buildDifferenceString(diff, prevDiff, transformedCurrentConfigs, transformedPreviousConfigs, this.previousUserConfigs, { "schema": this.schema });
    const validateResult = this.siteCreateComponent.validateFormData(transformedCurrentConfigs, this.previousUserConfigs, null);

    const dialogRef = this.dialog.open(ChangesPopUpComponent, {
      maxWidth: '850px',
      maxHeight: '600px',
      autoFocus: false,
      data: { diffString: diffString, diff, prevDiff, tempDiffObjectCurrent: transformedCurrentConfigs, tempDiffObjectPrevious: transformedPreviousConfigs, 
        previousConfigs: previousConfigs['user_configs'], resultApi: this.apiObject, removedFields: this.removedFields,
        additionalConfigsChanges: this.isAdditionalConfigsAdded, additionalConfigs: updatedAdditionalConfigs, newSiteCreation: true, largeLogo: this.largeLogoStatus,
        smallLogo: this.smallLogoStatus
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result.submitted) {
        params = this.siteCreateComponent.handleDefaultConfigs(params);
        params = this.siteCreateComponent.addEnglishLanguage(params);
        params['changesString'] = diffString;
        params['siteDetails'] = siteDetails;
        params['newSite'] = this.siteName;
        params['environment'] = this.selectedEnvironment;
        this.dataService.saveSchemaDetails(params).subscribe(response => {
          const timerDialog = this.dialog.open(TimerPopUpComponent, {
            maxWidth: '850px',
            maxHeight: '350px',
            data: { timer: 5, status: true }
          });

          timerDialog.afterClosed().subscribe(() => {
            location.reload();
          });
        }, err => {
            console.log('There is some error. Uh oh', err);
            const timerDialog = this.dialog.open(TimerPopUpComponent, {
              maxWidth: '850px',
              maxHeight: '350px',
              data: { timer: 5, status: false }
            });

            timerDialog.afterClosed().subscribe(() => {
              // this.authService.login();
            });
        });
      }
    });

    // const swalObject = {
    //   html: diffString,
    //   confirmButtonText: '<div style="font-size:12px">Submit</div>',
    //   showCancelButton: true,
    //   cancelButtonText: '<div style="font-size:12px">Cancel</div>',
    //   width: '600px'
    // };

    // if (!validateResult.status) {
    //   swalObject['title'] = 'There are errors in your configs';
    // } else {
    //   if(diffString === null) {
    //     swalObject['title'] = 'Are you sure you want to submit default configs?';
    //   } else {
    //     swalObject['title'] = 'You have made these changes.. Proceed to submit'
    //   }
    // }

    // Swal.fire(swalObject).then((result) => {
    //   if (result.isConfirmed && validateResult.status) {
    //     params = this.siteCreateComponent.handleDefaultConfigs(params);
    //     params['changesString'] = diffString;
    //     params['newSite'] = this.siteName;
    //     params['siteDetails'] = siteDetails
    //     this.dataService.saveSchemaDetails(params).subscribe(response => {
    //       Swal.fire({
    //         icon: 'success',
    //         title: 'Your configurations have been submitted',
    //         showConfirmButton: false,
    //         timer: 2000
    //       }).then(()=>{
    //         setTimeout(()=>{
    //           location.reload();
    //         }, 5000);
    //       });
    //     }, error => {
    //       console.log('There is some error. Uh oh');
    //       if (error && error.status === 401) {
    //         location.pathname = "/site-build/unauthorized";
    //       } else {
    //         this.router.navigateByUrl('/error');
    //       }
    //     });
    //   }
    // });
  }
}
