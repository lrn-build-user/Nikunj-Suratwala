import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-toast',
  templateUrl: './toast.component.html',
  styleUrls: ['./toast.component.css']
})
export class ToastComponent implements OnInit {

  @Output() close = new EventEmitter<string>();

  constructor() { }

  ngOnInit(): void {
  }

  hideToast() {
    this.close.emit(null);
  }

}
