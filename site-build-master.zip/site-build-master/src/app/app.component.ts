// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-root',
//   templateUrl: './app.component.html',
//   styleUrls: ['./app.component.css']
// })
// export class AppComponent {
//   title = 'site-build-app';
// }


import {Component} from '@angular/core';
import { Router, NavigationEnd } from "@angular/router";
declare let require;

@Component({
    selector: 'app-root',
    templateUrl: './partial/partial.html'
})

export class AppComponent{
  title = 'site-build-app';
    constructor(private router: Router) { }

    ngOnInit() {
        this.router.events.subscribe((evt) => {
            if (evt instanceof NavigationEnd) {
                window.scrollTo(0, 0);
            }
        });
    }
}
