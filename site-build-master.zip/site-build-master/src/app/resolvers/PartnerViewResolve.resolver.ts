import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable, of } from 'rxjs';
import { PartnerViewService } from '../services/common/partnerview.service';

@Injectable()
export class PartnerViewResolve implements Resolve<any> {
    public isLocalhost = window.location.hostname.indexOf('localhost') !== -1;

    constructor(
        public partnerViewService: PartnerViewService
    ) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> | Promise<any> {

        let partnerViewObj = this.partnerViewService.getIsPartnerView();

        return of(partnerViewObj);
    }
}