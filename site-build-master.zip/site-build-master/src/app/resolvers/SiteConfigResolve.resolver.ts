import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from '../services/common/authentication.service';
import { Observable, of } from 'rxjs';
import { PartnerViewService } from '../services/common/partnerview.service';

@Injectable()
export class SiteConfigResolve implements Resolve<any> {
    public isLocalhost = window.location.hostname.indexOf('localhost') !== -1;

    constructor(private authService: AuthService,
                public partnerViewService: PartnerViewService
    ) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> | Promise<any> {
        let self = this;
         let apiUrl = '/api/partner/get-analytics-user-access_v2';

        if(self.isLocalhost) {
            let siteConfig = {
                "tabs": {
                    "dashboard": true,
                    "partners": false,
                    "library": true,
                    "adminTools": true,
                    "analytics": {
                        "tab": true,
                        "url": true
                    },
                    "settings": true,
                    "sitebuild": true
                },
                "menu": {
                    "profileUrl": null,
                    "userGuides": true
                },
                "footer": {
                    "downloadLibrary": false,
                    "browseLibrary": true
                }
            };
            self.partnerViewService.setSiteConfig(siteConfig);

            return of({
                "siteConfig": siteConfig
            });
        } 
        else {
            return self.authService.getCatalystPartnerSiteConfig(apiUrl);
        }
    }
}