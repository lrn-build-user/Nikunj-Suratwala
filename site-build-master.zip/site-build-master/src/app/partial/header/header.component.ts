import { Component, OnInit } from '@angular/core';
import {PartnerViewService} from '../../services/common/partnerview.service';
import { AuthService } from '../../services/common/authentication.service';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { map } from 'rxjs/operators';
declare let require;
declare let localStorage;


@Component({
  selector: 'site-build-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent implements OnInit {

  public isLocalhost = window.location.hostname.indexOf('localhost') !== -1;
  user;
  partnerSite = window.location.hostname.split('.')[0];
  showProfileImage = false;
  profileImageUrl = '';
  constructor(
    public partnerViewService: PartnerViewService,
      private authService: AuthService,
      private http:HttpClient
  ){
  }

  ngOnInit() {
      let self = this;
      if(!this.isLocalhost) {
          setTimeout(()=>{
          self.checkProfileImageUrl()
              .then(data => {
                  self.user = JSON.parse(localStorage.usrObj);
                  self.showProfileImage = data['showProfileImage'] ? data['showProfileImage'] : false;
                  if(self.showProfileImage) {
                      self.getProfileImageUrl()
                          .then(urlData => {
                              self.profileImageUrl = urlData['profileImageUrl'];
                          });
                  }
              });
          },4000);
      }
  }

  checkProfileImageUrl_test() {
      return new Promise((resolve, reject) => {
          resolve({ showProfileImage: true });
      });
  }

  getProfileImageUrl_test() {
      return new Promise((resolve, reject) => {
          resolve({ profileImageUrl: '/dummyurl' });
      });
  }

  executePostRequest(url) {
      let headers = new HttpHeaders(),
          accessToken = localStorage.getItem('x-access-token') || '',
          authToken = localStorage.getItem('auth') || '';
      let tokenString = '';

      if (accessToken) {
          headers=headers.append('x-access-token', accessToken);
      }
      if (authToken) {
          headers=headers.append('Authorization', 'Bearer ' + authToken);
          tokenString = '?token="' + authToken + '"';
      }
      headers=headers.append('Content-Type', 'application/json');
      let sitebuildUsrObj = JSON.parse(localStorage.getItem('usrObj'));
      console.log('site build object', sitebuildUsrObj);
      return this.http.post(url+tokenString, {id: sitebuildUsrObj.userid}, {'headers': headers}).pipe(map((res: Response) => res))
  }

  checkProfileImageUrl() {
      let self = this;

      return new Promise((resolve, reject) => {
          self.executePostRequest('/api/upload/getImageDetails')
              .subscribe(
                  data => {
                      if (data && typeof data === 'string') {
                          resolve({ showProfileImage: false });
                      } else if (data) {
                          resolve({ showProfileImage: false });
                      } else {
                          resolve({ showProfileImage: true });
                      }
                  },
                  error => {
                      console.log("error response object", error);
                      if (JSON.parse(error._body).success === false) {
                          // location.pathname = "/login";
                      }
                  }
              );
      });
  }

  getProfileImageUrl() {
      let self = this;

      return new Promise((resolve, reject) => {
          self.executePostRequest('/api/upload/getImageFromS3')
              .subscribe(
                  data => {
                      if (data && typeof data === 'string') {
                          resolve({ profileImageUrl: data });
                      } else {
                          resolve({ profileImageUrl: '' });
                      }
                  },
                  error => {
                      console.log("error response object:", error);
                      if (JSON.parse(error._body).success === false) {
                          // location.pathname = "/login";
                      }
                  }
              );
      });
  }

  callLogoutApi() {
      let self = this;

      return new Promise((resolve, reject) => {
          self.authService.logout()
              .subscribe(
                  data => {
                      localStorage.clear();
                      location.pathname = "/";
                      resolve(data);
                  },
                  error => {
                      console.log("error response object", error);
                      let errorObj = JSON.parse(error._body);
                      localStorage.clear();
                      location.pathname = "/";
                      if (errorObj.success === false || errorObj.error) {
                          location.pathname = "/";
                      }
                  }
              );
      });
  }

}


