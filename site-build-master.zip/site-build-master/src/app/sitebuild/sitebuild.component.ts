import { Component, OnInit, Input, EventEmitter, Output, NgModule, ViewChild, ElementRef } from '@angular/core';
import { jsonSchema } from './jsonSchema';
import { SitebuildService } from '../services/common/sitebuild.service';
import { PartnerViewService } from '../services/common/partnerview.service';
import { Subscription } from 'rxjs';
import { listLazyRoutes } from '@angular/compiler/src/aot/lazy_routes';
import { JSONService } from '../services/common/json.service';
import { MaterialFileComponent } from '@ajsf/material';
import ajv from 'ajv';
import { DataService } from '../services/data.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-sitebuild',
  templateUrl: './sitebuild.component.html',
  styleUrls: ['./sitebuild.component.scss'],
  providers: [SitebuildService]
})
export class SitebuildComponent implements OnInit {

  @Input()
  public strError: string = "";
  public strMessage: string = "";
  public inputJson: any = {};
  @Output()
  public strErrorResult: EventEmitter<string> = new EventEmitter<string>();
  @ViewChild("fileInput", {static: false}) fileInput: ElementRef;
  @ViewChild('uploadControl') uploadControl: ElementRef;


  schema: {};
  siteBuildDataSubmit: any;
  siteBuildDefaultData: any;
  layout: [];
  formData: {};
  fileComp = {
    input: MaterialFileComponent
  };
  loading = true;

  files = [];

  submittedFormData: object = {};

  constructor(
    private SiteBuildSchemaDataSrv: SitebuildService,
    public partnerViewService: PartnerViewService,
    private jsonService: JSONService,
    private dataService: DataService,
    private router: Router
  ) { }

  jsonFormOptions = {
    loadExternalAssets: false,
  };

  checkJS = {};
  ngOnInit() {
    this.getSiteBuildSchemaDetails();
  }

  private getSiteBuildSchemaDetails() {
    this.dataService.getConfigsForASite().subscribe(
      response => {
        /* this function is executed every time there's a new output */
        console.log("VALUE RECEIVED: " + response);
        this.loading = false;
        this.schema = JSON.parse(JSON.stringify(response.schema));
        this.layout = response.layout;
        this.formData = response.data;
      },
      err => {
        /* this function is executed when there's an ERROR */
        if (err.status == 404) {
          location.pathname = "/site-build/unauthorized";
        }
        else {
          this.router.navigateByUrl('/error');
        }
      },
      () => {
        console.log("COMPLETED");
      }
    );

  }

  onChanges(data: any) {
    if (data.user_configs && data.user_configs.custom_field && data !== this.submittedFormData) {
      this.submittedFormData = data;
      let finalObj = visit(this.submittedFormData, this.schema, this.submittedFormData);
      var isEmptyResult = checkJsonObjEmpty(finalObj);
      if (!isEmptyResult) {
        // this.setSiteBuildSchemaDetails(finalObj);
      }
      this.formData = data;
    }
  }

  onSubmit(data: any) {
    this.submittedFormData = data;
    let finalObj = visit(this.submittedFormData, this.schema, this.submittedFormData);
    var isEmptyResult = checkJsonObjEmpty(finalObj);
    if (!isEmptyResult) {
      let ajv1 = new ajv({ extendRefs: true });
      let validate = ajv1.compile(this.schema);
      if (validate(finalObj)) {
        this.setSiteBuildSchemaDetails(finalObj);
      } else {
        window.alert('Something wrong with the json data');
      }
    }

  }
  private setSiteBuildSchemaDetails(formSubmittedData) {
    this.SiteBuildSchemaDataSrv.setSiteBuildSchemaDetails(formSubmittedData).subscribe(
      response => {
        /* this function is executed every time there's a new output */
        console.log("VALUE RECEIVED: " + response);
        if (!response.message) {
          this.strMessage = JSON.stringify(response.errors);
        }
        this.strMessage = JSON.stringify(response.message);

      },
      err => {
        /* this function is executed when there's an ERROR */
        console.log("ERROR 2:" + err);
        this.strMessage = JSON.stringify(err);
        if (err.status == 404) {
          this.strMessage = "API Not Found";
        }
        else if (err.status == 400) {
          this.strMessage = JSON.stringify(err.errors);
        }
      },
      () => {
        console.log("COMPLETED");
      }
    );
  }

}


function checkJsonObjEmpty(object) {
  return Object.values(object).every(val => val && typeof val === 'object'
    ? checkJsonObjEmpty(val)
    : val === 0 || val === null || val === "null" || val === undefined);
}


function jsonTravers(iterable, functionRef) {
  for (var accessor in iterable) {
    functionRef(accessor, iterable[accessor]);
  }
}
function isIterable(element) {
  return isArray(element) || isObject(element);
}
function isArray(element) {
  return element.constructor == Array;
}
function isObject(element) {
  return element.constructor == Object;
}

function removeProp(obj, propName) {
  for (var p in obj) {
    if (obj.hasOwnProperty(p)) {
      if (p == propName) {
        delete obj[p];
      } else if (isIterable(obj[p])) {
        removeProp(obj[p], propName);
        if (Object.keys(obj[p]).length === 0) {
          delete obj[p]; // The object had no properties, so delete that property
        }
      }
    }
  }
  return obj;
}

function findDefault(inputjson, accessorkey, formkeyval, fromData) {
  if (isIterable(inputjson)) {
    jsonTravers(inputjson, function (accessor, child) {
      if (accessor == accessorkey && child['default'] != undefined) {
        if (child['default'] != '' && child['default'] == formkeyval) {
          removeProp(fromData, accessorkey);
        }
      }
      findDefault(child, accessorkey, formkeyval, fromData);
    });
  }
}

function visit(fromDate, inputData, finalOutData) {
  if (isIterable(fromDate)) {
    jsonTravers(fromDate, function (accessor, child) {
      if (!isIterable(child)) {
        findDefault(inputData, accessor, child, finalOutData);
      }
      visit(child, inputData, finalOutData);
    });
    return finalOutData;
  }
}

