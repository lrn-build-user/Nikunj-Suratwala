import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SitebuildComponent } from './sitebuild.component';

describe('SitebuildComponent', () => {
  let component: SitebuildComponent;
  let fixture: ComponentFixture<SitebuildComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SitebuildComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SitebuildComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
