import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AuthenticatedGuard } from './services/common/AuthenticatedGuard.service';
import { SitebuildComponent } from './sitebuild/sitebuild.component';
import { PartnerViewResolve } from './resolvers/PartnerViewResolve.resolver';
import { LandingPageComponent } from './pages/landing-page/landing-page.component';
import { SiteCreatePageComponent } from './pages/site-create-page/site-create-page.component';
import { UnauthorizedComponent } from './components/unauthorized/unauthorized.component';
import { NewSiteComponent } from './components/new-site/new-site.component';
import { NewSiteStepperComponent } from './components/new-site-stepper/new-site-stepper.component';
import { DecommissionSiteComponent } from './components/decommission-site/decommission-site.component';
import { ErrorPageComponent } from './components/error-page/error-page.component';
import { AuditLogsComponent } from './components/audit-logs/audit-logs.component';
import { DocumentationPageComponent } from './pages/documentation-page/documentation-page.component';
import { SiteRecreationComponent } from './components/site-recreation/site-recreation.component';
import { SettingNameListComponent } from './components/setting-name-list/setting-name-list.component';

const routes: Routes = [
  { path: '', redirectTo: 'site-build/create', pathMatch: 'full' },
  { path:'site-create', component: SitebuildComponent,pathMatch:'full',canActivate:[AuthenticatedGuard]},
  { path: 'site-build', redirectTo: 'site-build/create',  pathMatch: 'full'},
  { path: 'site-build/create', component: SiteCreatePageComponent, pathMatch: 'full', canActivate:[AuthenticatedGuard]},
  { path: 'site-build/unauthorized', component: UnauthorizedComponent, pathMatch: 'full' },
  { path: 'site-build/internal', component: NewSiteComponent, pathMatch: 'full', canActivate:[AuthenticatedGuard]},
  { path: 'site-build/create-new-site', component: NewSiteStepperComponent, pathMatch: 'full', canActivate:[AuthenticatedGuard]},
  { path: 'site-build/decommission-site', component: DecommissionSiteComponent, pathMatch: 'full'},
  { path: 'site-build/recommission-site', component: DecommissionSiteComponent, pathMatch: 'full'},
  { path: 'site-build/audit-logs', component: AuditLogsComponent, pathMatch: 'full', canActivate:[AuthenticatedGuard]},
  { path: 'site-build/docs', component: DocumentationPageComponent, pathMatch: 'full', canActivate:[AuthenticatedGuard]},
  { path: 'error', component: ErrorPageComponent, pathMatch: 'full', canActivate:[AuthenticatedGuard]},
  { path: 'site-build/setting-names', component: SettingNameListComponent, pathMatch: 'full', canActivate:[AuthenticatedGuard]},
  { path: '**', redirectTo: 'site-build/create' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
