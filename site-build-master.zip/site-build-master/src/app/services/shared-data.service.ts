import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SharedDataService {

  constructor() { }

  private siteSchemaConfigData = null;
  private configSchemaData = new Subject<any>();
  private userSchemaData = new Subject<any>();
  private completeSchema = new Subject<any>();
  private schemaApiResult = new Subject<any>();
  private siteId = null;
  private customUserColumns = [];
  private selectedLanguagesArray = new Subject<any>();
  private removedFields = new Subject<any>();
  private largeLogo = new Subject<any>();
  private smallLogo = new Subject<any>();
  private largeDarkLogo = new Subject<any>();
  private smallDarkLogo = new Subject<any>();
  private pendingChangesPresent = new Subject<boolean>();
  private additionalConfigs = new Subject<any>();
  private auditLogsHighlights = new Subject<any>();
  public highlightsObservables = this.auditLogsHighlights.asObservable();
  private latestAuditLog = null;
  // private siteConfigsChanges = [];
  private siteConfigsChanges = new Subject<string[]>();

  setSiteConfigData(data) {
    if (data) {
      this.siteSchemaConfigData = data;
    } 
  };

  getSchemaApiResult() {
    return this.schemaApiResult;
  }

  getCompleteSchema() {
    return this.completeSchema;
  }

  getSiteConfigData() {
    return this.siteSchemaConfigData;
  }

  getConfigSchemaData() {
    return this.configSchemaData;
  }

  getUserSchemaData() {
    return this.userSchemaData;
  }

  getSiteId() {
    return this.siteId;
  }

  setSiteId(id) {
    if (id) {
      this.siteId = id;
    }
  }

  setCustomColumnsOrder(customColumns) {
    if(customColumns && customColumns.length > 0) {
      this.customUserColumns = customColumns;
    }
  }

  getCustomColumnsOrder() {
    return this.customUserColumns;
  }

  getLanguageArray() {
    return this.selectedLanguagesArray;
  };

  getRemovedFields() {
    return this.removedFields;
  }

  setLargeLogoStatus(event){
    this.largeLogo = event;
  }

  setSmallLogoStatus(event){
    this.smallLogo = event;
  }

  setLargeDarkLogoStatus(event){
    this.largeDarkLogo = event;
  }

  setSmallDarkLogoStatus(event){
    this.smallDarkLogo = event;
  }

  getLargeLogoStatus(){
    return this.largeLogo;
  }

  getSmallLogoStatus(){
    return this.smallLogo;
  }

  getLargeDarkLogoStatus(){
    return this.largeDarkLogo;
  }

  getSmallDarkLogoStatus(){
    return this.smallDarkLogo;
  }

  getPendingLogsStatus() {
    return this.pendingChangesPresent;
  }

  getAdditionalConfigs(){
    return this.additionalConfigs;
  }

  getAuditLogsHighlights() {
    return this.auditLogsHighlights;
  }

  setAuditLogsHighlights(mergedHighlights) {
    if (mergedHighlights) {
      this.auditLogsHighlights.next(mergedHighlights);
      this.auditLogsHighlights = mergedHighlights;
    }
  }

  getSiteConfigDraftChanges() {
    return this.siteConfigsChanges;
  }

  setSiteConfigDraftChanges(changes) {
    if (changes) {
      this.siteConfigsChanges = changes;
      console.log("In set config changes: ", changes, this.siteConfigsChanges);
    }
  }

  setLatestAuditLog(log) {
    if (log) {
      this.latestAuditLog = log;
    }
  }

  getLatestAuditLog() {
    return this.latestAuditLog;
  }
}
