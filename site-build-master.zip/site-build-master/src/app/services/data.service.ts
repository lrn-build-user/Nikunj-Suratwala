import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { EnvironmentService } from './common/environment.service';


@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private http: HttpClient, private environment: EnvironmentService) { }

  public getConfigsForASite(): Observable<any> {
    // let headers = new Headers({ "Content-Type": "application/json" });
    let authToken;
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';
    if (authToken) {
      headers = headers.append('Authorization', 'Bearer ' + authToken);
    }

    let url = this.environment.getBaseUrl() + '/config/schema';

    return this.http.get(url, { 'headers': headers })
      .pipe(map((res: Response) => res))
  }

  public saveSchemaDetails(params): Observable<any> {
    let authToken;
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';

    if (authToken) {
        headers= headers.append('Authorization', 'Bearer ' + authToken);
    }

    let url = this.environment.getBaseUrl() + '/config/update';

    return this.http.post(url,params,{ 'headers': headers })
    .pipe(map((res: Response) => res))
  }

  public saveAdditionalConfigs(params): Observable<any> {
    let authToken;
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';

    if (authToken) {
        headers= headers.append('Authorization', 'Bearer ' + authToken);
    }

    let url = this.environment.getBaseUrl() + '/additionalConfigs/update';

    return this.http.post(url,params,{ 'headers': headers })
    .pipe(map((res: Response) => res))
  }

  public getAuditLogs(params): Observable<any> {
    let authToken;
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';

    if (authToken) {
        headers= headers.append('Authorization', 'Bearer ' + authToken);
    }

    let url = this.environment.getBaseUrl() + `/auditLogs`;

    return this.http.post(url, { startRows: params.startRows, numberOfRows: params.numberOfRows, siteName: params.siteName, dateRange: params.dateRange, fromInternalSite: params.fromInternalSite, environment: params.environment }, { 'headers': headers })
    .pipe(map((res: Response) => res))
  }

  public validateSiteDetails(siteName, companyName, partnerId): Observable<any> {
    let authToken;
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';

    if (authToken) {
        headers= headers.append('Authorization', 'Bearer ' + authToken);
    }

    let url = this.environment.getBaseUrl() + `/site-create/validate`;

    return this.http.post(url, {siteName, companyName, partnerId }, { 'headers': headers })
    .pipe(map((res: Response) => res))
  }

  public fetchSitesListForPartnerId(partnerId, environment): Observable<any> {
    let authToken;
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';

    if (authToken) {
        headers= headers.append('Authorization', 'Bearer ' + authToken);
    }

    let url = this.environment.getBaseUrl() + `/site-create/fetch-sites`;

    return this.http.post(url, { partnerId, environment }, { 'headers': headers })
    .pipe(map((res: Response) => res))
  }

  public validateSiteName(siteName): Observable<any> {
    let authToken;
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';

    if (authToken) {
        headers= headers.append('Authorization', 'Bearer ' + authToken);
    }

    let url = this.environment.getBaseUrl() + `/site-create/validate-site`;

    return this.http.post(url, { siteName }, { 'headers': headers })
    .pipe(map((res: Response) => res))
  }

  public createSite(params): Observable<any> {
    let authToken;
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';

    if (authToken) {
        headers= headers.append('Authorization', 'Bearer ' + authToken);
    }

    let url = this.environment.getBaseUrl() + `/site-create/create-site`;

    return this.http.post(url, params, { 'headers': headers })
    .pipe(map((res: Response) => res))
  }

  public getSiteNamesFromMongo(environment): Observable<any> {
    let authToken;
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';

    if (authToken) {
        headers= headers.append('Authorization', 'Bearer ' + authToken);
    }

    let url = this.environment.getBaseUrl() + `/auditLogs/sites`;

    return this.http.post(url, { environment: environment }, { 'headers': headers })
    .pipe(map((res: Response) => res))
  }

  public getAllActiveSites(environment): Observable<any> {
    let authToken;
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';

    if (authToken) {
        headers= headers.append('Authorization', 'Bearer ' + authToken);
    }

    let url = this.environment.getBaseUrl() + `/site-decommission/get-active-sites`;

    return this.http.post(url, { environment }, { 'headers': headers })
    .pipe(map((res: Response) => res))
  }

  public updateSiteStatus(siteName, environment): Observable<any> {
    let authToken;
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';

    if (authToken) {
        headers= headers.append('Authorization', 'Bearer ' + authToken);
    }

    let url = this.environment.getBaseUrl() + `/site-decommission/update-site-status`;

    return this.http.post(url,{siteName, environment}, { 'headers': headers })
    .pipe(map((res: Response) => res))
  }

  public getAllDecommissionedSites(environment): Observable<any> {
    let authToken;
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';

    if (authToken) {
        headers= headers.append('Authorization', 'Bearer ' + authToken);
    }

    let url = this.environment.getBaseUrl() + `/site-recommission/get-decommissioned-sites`;

    return this.http.post(url, { environment }, { 'headers': headers })
    .pipe(map((res: Response) => res))
  }

  public updateSiteRecommissionStatus(siteObj): Observable<any> {
    let authToken;
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';

    if (authToken) {
        headers= headers.append('Authorization', 'Bearer ' + authToken);
    }

    let url = this.environment.getBaseUrl() + `/site-recommission/recommission-site`;

    return this.http.post(url,{siteObj}, { 'headers': headers })
    .pipe(map((res: Response) => res))
  }

  public getDeploymentStatus(): Observable<any> {
    let authToken;
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';

    if (authToken) {
      headers = headers.append('Authorization', 'Bearer ' + authToken);
    }

    let url = this.environment.getBaseUrl() + '/deployment/status';

    return this.http.get(url, { 'headers': headers })
    .pipe(map((res: Response) => res))
  }

  public updateDeploymentDate(params): Observable<any> {
    let authToken;
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';

    if (authToken) {
        headers= headers.append('Authorization', 'Bearer ' + authToken);
    }

    let url = this.environment.getBaseUrl() + `/deployment/update`;

    return this.http.post(url,params, { 'headers': headers })
    .pipe(map((res: Response) => res))
  }

  public enableNewConsoleSite(): Observable<any> {
    let authToken;
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';

    if (authToken) {
        headers= headers.append('Authorization', 'Bearer ' + authToken);
    }

    console.log('Abs url: ', this.environment.getAbsoluteUrl() + `/newconsole/api/public/initiateSite`);
    console.log('Base url: ', this.environment.getBaseUrl() + `/newconsole/api/public/initiateSite`);

    let url = this.environment.getAbsoluteUrl() + `/newconsole/api/public/initiateSite`;

    return this.http.get(url, { 'headers': headers })
    .pipe(map((res: Response) => res))
  }
}
