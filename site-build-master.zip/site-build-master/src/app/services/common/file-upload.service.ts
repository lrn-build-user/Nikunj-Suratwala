import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { EnvironmentService } from './environment.service';

@Injectable({
  providedIn: 'root'
})
export class FileUploadService {

  constructor(private http: HttpClient, private environmentService: EnvironmentService) { }

  formData: FormData = null;

  upload(file, fileName, siteName): Observable<any> {
    let authToken;
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';

    if (authToken) {
        headers= headers.append('Authorization', 'Bearer ' + authToken);
    }

    this.formData === null ? this.formData = new FormData() : this.formData;
    let fileNameWithExtension = (file.type === 'image/png' ? `${fileName}.png`: `${fileName}.gif`);
    this.formData.set("file", file, fileNameWithExtension);
    const siteNameToAppend = (siteName) ? siteName : 'LOGO';
    const url = this.environmentService.getBaseUrl() + '/file/upload/' + siteNameToAppend;
    return this.http.post(url, this.formData, { 'headers': headers });
  }

  bulkFileUpload(file, fileName, type): Observable<any> {
    let authToken;
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';

    if (authToken) {
        headers= headers.append('Authorization', 'Bearer ' + authToken);
    }

    this.formData === null ? this.formData = new FormData() : this.formData;
    this.formData.set("file", file, fileName);
    const url = this.environmentService.getBaseUrl() + '/bulkFile/upload';
    return this.http.post(url, this.formData, { 'headers': headers });
  }

}
