import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';
// import { PartnerViewService } from './partnerview.service';

import * as _ from 'lodash';
import { map } from 'rxjs/operators';
import { EnvironmentService } from './environment.service';

@Injectable()
export class AuthService {
    constructor(
        private http: HttpClient,
        private environmentService: EnvironmentService
        // public partnerViewService: PartnerViewService,
    ) { }

    // Authentication and User Validation
    isTokenValid() {
        let url = this.environmentService.getBaseUrl() + '/auth/jwt/verify';
        return this.http.get('/api/auth/jwt/verify').pipe(map((res: Response) => res));
    }
    getUserDetail() {
        let headers = new HttpHeaders(),
            authToken = localStorage.getItem('auth') || '';

        if (authToken) {
            headers= headers.append('Authorization', 'Bearer ' + authToken);
        }
        return this.http.get('/api/user/details', { 'headers': headers }).pipe(map((res: Response) => res))
    }

    // Logout API
    logout() {
        let headers = new HttpHeaders(),
            authToken = localStorage.getItem('auth') || '';

        if (authToken) {
            headers=headers.append('Authorization', 'Bearer ' + authToken);
        }

        let url = this.environmentService.getAbsoluteUrl() + '/api/user/logout';

        return this.http.post(url, '', { 'headers': headers }).pipe(map((res: Response) => res))
    }

    login() {
        location.href = location.origin + '/su';
    }

    // getAuthInfo() {
    //     let sitebuildUsrObj = JSON.parse(localStorage.getItem('sitebuildUsrObj'));

    //     if (this.partnerViewService.getIsPartnerView()) {
    //         return true;
    //     } else {
    //         return sitebuildUsrObj && (sitebuildUsrObj.userRole.id === 2 || sitebuildUsrObj.lcecSuperAdmin === 1);
    //     }
    // }

    validateToken() {
        let self = this;

        return new Promise((resolve, reject) => {
            self.isTokenValid()
                .subscribe(
                    (data:any) => {
                        if (data && data.jwt) {
                            localStorage.setItem('auth', data.jwt);
                            let tokenObj = JSON.parse(atob(String(data.jwt).split('.')[1]));
                            if (tokenObj.rl === 2) {
                                let sitebuildUsrObj;
                                sitebuildUsrObj=localStorage.getItem('usrObj');
                                localStorage.setItem('sitebuildUsrObj', sitebuildUsrObj);
                                resolve(data);
                            } else {
                                self.getUserDetail().subscribe(
                                    (userDetail:any) => {
                                        let sitebuildUsrObj = {};
                                        if (userDetail) {
                                            sitebuildUsrObj['company'] = {
                                                pid: tokenObj.pid
                                            }
                                            sitebuildUsrObj['userid'] = userDetail.userid;
                                            sitebuildUsrObj['name'] = userDetail.name;
                                            sitebuildUsrObj['lastName'] = userDetail.lastName;
                                            if (tokenObj.rl === 1) {
                                                sitebuildUsrObj['lcecSuperAdmin'] = tokenObj.rl;
                                            }
                                            sitebuildUsrObj['userRole'] = {
                                                id: userDetail.userRole.id
                                            }
                                        }
                                       
                                        localStorage.setItem('sitebuildUsrObj', JSON.stringify(sitebuildUsrObj));
                                        // if(userDetail.userRole.id != 1)
                                        // {
                                        //     location.pathname = "/dashboard";
                                        // }
                                        resolve(data);
                                    },
                                    error => {
                                        let errorObj = error.json();
                                        // let errorObj = JSON.parse(error._body);
                                        if (errorObj.success === false || errorObj.error) {
                                            // location.pathname = "/";
                                            // location.pathname = "/login";
                                            this.logout();
                                        }
                                    }
                                );
                            }
                        } else {
                            // location.pathname = "/";
                            // location.pathname = "/login";
                            this.logout();
                        }
                    },
                    error => {

                        console.log("error response object", error);
                        // let errorObj = JSON.parse(error._body);
                        if (error.success === false || error.error) {
                            // location.pathname = "/";
                            // location.pathname = "/login";
                            // this.logout();
                        }
                        // this.logout();
                        location.pathname = "/site-build/unauthorized";
                    }
                );
        });
    }

    // getCatalystPartnerSiteConfig(url) {
    //     let self = this;

    //     return new Promise((resolve, reject) => {
    //         self.executeGetRequest({ url: url })
    //             .subscribe(
    //                 data => {
    //                     if (data && data["tabs"] && data["tabs"]['analytics']['url']) {
    //                         self.partnerViewService.setSiteConfig(data);
    //                         resolve(data);
    //                     } else {
    //                         location.pathname = "/login";
    //                     }
    //                 },
    //                 error => {
    //                     console.log("error response object", error);
    //                     let errorObj = JSON.parse(error._body);
    //                     if (errorObj.success === false || errorObj.error) {
    //                         location.pathname = "/login";
    //                     }
    //                 }
    //             );
    //     });
    // }

       // Check access to Analytics direct url link
       executeGetRequest(req) {
        let headers = new HttpHeaders(),
            accessToken = localStorage.getItem('x-access-token') || '',
            authToken = localStorage.getItem('auth') || '';
        let tokenString = '';

        if (accessToken) {
            headers=headers.append('x-access-token', accessToken);
        }
        if (authToken) {
            headers= headers.append('Authorization', 'Bearer ' + authToken);
            tokenString = '?token="' + authToken + '"';
        }
        headers= headers.append("Content-Type", 'application/json');


        return this.http.get(req.url + tokenString, {headers:headers}).pipe(map((res: Response) => res));
    }

}