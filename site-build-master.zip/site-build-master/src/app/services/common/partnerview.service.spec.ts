import { TestBed } from '@angular/core/testing';

import { PartnerviewService } from './partnerview.service';

describe('PartnerviewService', () => {
  let service: PartnerviewService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PartnerviewService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
