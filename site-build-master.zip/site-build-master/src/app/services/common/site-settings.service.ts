import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { EnvironmentService } from './environment.service';

@Injectable({
  providedIn: 'root'
})
export class SiteSettingsService {

  constructor(private http: HttpClient, private environment: EnvironmentService) { }

  public getSAMLSettingNamesList(): Observable<any> {
    let authToken;
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';
    if (authToken) {
      headers = headers.append('Authorization', 'Bearer ' + authToken);
    }

    let url = this.environment.getBaseUrl() + '/settingNameList';
    

    return this.http.get(url, { 'headers': headers })
      .pipe(map((res: Response) => res))
  }

  public getSiteSAMLSettingsList(): Observable<any> {
    console.log('Here in service')
    let authToken;
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';
    if (authToken) {
      headers = headers.append('Authorization', 'Bearer ' + authToken);
    }

    let url = this.environment.getBaseUrl() + '/sitesettingList';

    return this.http.get(url, { 'headers': headers })
      .pipe(map((res: Response) => res))
  }
  public deleteNameData(data:any): Observable<any> {
    let authToken;
    console.log(data);
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';
    if (authToken) {
      headers = headers.append('Authorization', 'Bearer ' + authToken);
    }

    let url = this.environment.getBaseUrl() + '/deleteSiteSettingNames';
    

    return this.http.post(url,data, { 'headers': headers })
      .pipe(map((res: Response) => res))
  }
  public deleteSettingsData(data:any): Observable<any> {
    let authToken;
    console.log("In Delete Setting Service ===");
    console.log(data);
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';
    if (authToken) {
      headers = headers.append('Authorization', 'Bearer ' + authToken);
    }

    let url = this.environment.getBaseUrl() + '/deleteSiteSettings';
    

    return this.http.post(url,data, { 'headers': headers })
      .pipe(map((res: Response) => res))
  }

  public addSettingNameData(data:any): Observable<any> {
    let authToken;
    console.log("In Service");
    console.log(data);
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';
    if (authToken) {
      headers = headers.append('Authorization', 'Bearer ' + authToken);
    }

    let url = this.environment.getBaseUrl() + '/settingNames';
    

    return this.http.post(url,data, { 'headers': headers })
      .pipe(map((res: Response) => res))
  }
  public addSettingsData(data:any): Observable<any> {
    let authToken;
    console.log("In Add Settings Data Service ");
    console.log(data);
    let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';
    if (authToken) {
      headers = headers.append('Authorization', 'Bearer ' + authToken);
    }

    let url = this.environment.getBaseUrl() + '/siteSettings';
    

    return this.http.post(url,data, { 'headers': headers })
      .pipe(map((res: Response) => res))
  }

}
