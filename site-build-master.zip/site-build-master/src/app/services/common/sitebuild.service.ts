import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from "rxjs/operators";

@Injectable({
  providedIn: 'root'
})
export class SitebuildService {
  constructor(private httpClient: HttpClient) { }

  public getSiteBuildSchemaDetails(): Observable<any> {
    // let headers = new Headers({ "Content-Type": "application/json" });
    let authToken;
    let headers = new HttpHeaders();
            authToken = localStorage.getItem('auth') || '';
        if (authToken) {
            headers= headers.append('Authorization', 'Bearer ' + authToken);
        }

     return this.httpClient
     .get('http://localhost:3000/site-build/api/config/schema', { 'headers': headers })
     .pipe(map((res: Response) => res))

  }

  public setSiteBuildSchemaDetails(params): Observable<any> {
    let authToken;
    let headers = new HttpHeaders();
            authToken = localStorage.getItem('auth') || '';
        if (authToken) {
            headers= headers.append('Authorization', 'Bearer ' + authToken);
        }
     return this.httpClient
     .post('http://localhost:3000/site-build/api/config/update',params,{ 'headers': headers })
     .pipe(map((res: Response) => res))

  }
}
