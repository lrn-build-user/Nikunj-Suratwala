import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EnvironmentService {

  private hostname;
  constructor() {
    this.hostname = window.location.hostname;
    if (this.hostname === 'localhost') {
      this.hostname = 'http://localhost:3000';
    } else {
      this.hostname = window.location.origin;
    }
  }

  private baseUrl = '/site-build/api';

  getBaseUrl() {
    return this.hostname + this.baseUrl;
  }

  getAbsoluteUrl() {
    return this.hostname;
  }
}
