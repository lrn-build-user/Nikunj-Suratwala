import {Injectable} from '@angular/core';

@Injectable()
export class PartnerViewService {
    public isPartnerView = false;
    private siteParams = [];
    private activeSites = [];
    private activeSiteNames = [];
    private activeSitesString = '';
    private siteConfig = {
        "tabs": {
            "dashboard": false,
            "partners": false,
            "library": false,
            "adminTools": false,
            "analytics": {
                "tab": false,
                "url": false
            },
            "settings": false,
            "sitebuild": true,
        },
        "menu": {
            "profileUrl": null,
            "userGuides": true
        },
       
    };
    private hasPartnerData = false;
    
    constructor() {   }

    setSiteParams(params) {
        let self = this;
        self.siteParams = params;
    }

    getSiteParams() {
        return this.siteParams;
    }

    setActiveSites(sites) {
        let self = this;
        self.activeSites = sites;
    }

    getActiveSites() {
        return this.activeSites;
    }

    setIsPartnerView(flag) {
        let self = this;
        self.isPartnerView = flag;
    }

    getIsPartnerView() {
        let isLocalhost = window.location.hostname.indexOf('localhost') !== -1,
            partnerViewObj = {isPartnerView: false};

        if(isLocalhost) {
            partnerViewObj['isPartnerView'] = false;
        } else {
            partnerViewObj['isPartnerView'] = ['catalyst','localhost'].indexOf(window.location.hostname.split('.')[0]) === -1;
        }

        this.setIsPartnerView(partnerViewObj['isPartnerView']);
        return this.isPartnerView;
    }

    setActiveSiteNames(activeSiteNames) {
        this.activeSiteNames = activeSiteNames;

        this.activeSitesString = activeSiteNames.join(', ');
    }
    
    getActiveSiteNames() {
        return this.activeSiteNames;
    }

    getActiveSitesString() {
        return this.activeSitesString;
    }

    setSiteConfig(config) {
        let self = this;
        self.siteConfig = config;
    }

    getSiteConfig() {
        return this.siteConfig;
    }

    getSiteTabPermission(tabName) {
        return this.siteConfig['tabs'][tabName];
    }

    setHasPartnerData(hasPartnerData) {
        let self = this;
        self.hasPartnerData = hasPartnerData;
    }

    getHasPartnerData() {
        return this.hasPartnerData;
    }

}