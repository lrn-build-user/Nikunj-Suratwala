import {Injectable } from '@angular/core';


@Injectable()
export class JSONService {

    constructor() {}

    getObjectDiff(o1, o2, a) {
        let diff = a ? [] : {};
        if (!o1) {
            diff = o2;
            return Object.keys(diff).length > 0 ? diff : null;
        }
        for (let i in o2) {
            if (o2[i] instanceof Object || o2[i] instanceof Array) {
                diff[i] = this.getObjectDiff(o1[i], o2[i], o2[i] instanceof Array);
                if (!diff[i] || Object.keys(diff[i]).length == 0) {
                    delete diff[i];
                }
            } else {
                if (o1[i] != o2[i]) {
                    diff[i] = o2[i]
                } else if (a) {
                    diff[i] = o1[i]
                }
            }
        }
        return Object.keys(diff).length > 0 ? diff : null;
    }

    getJSONDiff(previous, current) {
        const resultObj = { changes: {}, additions: {}, deletions: {} };
        const jsonKeys = [];

        Object.keys(previous).forEach(key => {
            jsonKeys.push(key);
        });

        Object.keys(current).forEach(key => {
            if (!jsonKeys.includes(key)) {
                jsonKeys.push(key);
            }
        });

        /*
            1. loop through current
            2. check if each key exists in previous? 
            3. if exists check values as well
            4. if doesnt exist add it in the not present/deleted part

            o/p: {
                changes: // key present but value diff
                additions: // key not present in old
                deletions: // key not present in the current
            }

        */

        jsonKeys.forEach(key => {
            if (previous.hasOwnProperty(key) && current.hasOwnProperty(key)) {
                if (JSON.stringify(previous[key]) !== JSON.stringify(current[key])) {
                    resultObj.changes[key] = current[key];
                }
            }
            
            if (!previous.hasOwnProperty(key) && current.hasOwnProperty(key)) {
                resultObj.additions[key] = current[key];
            }

            if (previous.hasOwnProperty(key) && !current.hasOwnProperty(key)) {
                resultObj.deletions[key] = previous[key];
            }
        });
        
        return resultObj;
    }
}