import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from "rxjs/operators";
// import "rxjs/add/operator/toPromise";
// import 'rxjs/add/operator/catch'


const URL = "https://qatracking06.catalyst.qa7.lrn.com/site-build/api/config/schema";
// http://localhost:8001/watch

@Injectable({
  providedIn: 'root'
})
export class SitebuildschemaService {

  private readonly url: string = URL;

  constructor(private httpClient: HttpClient) { }

  public getSitebuildSchemaDetails(): Observable<any> {
    // let headers = new Headers({ "Content-Type": "application/json" });
    let authToken;
    // let options;
    let headers = new HttpHeaders();
            authToken = localStorage.getItem('auth') || '';
            // authToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOjE1NzQsImx1aWQiOiIyOTQ2NTQwMyIsInNpZCI6MTQxMCwicGlkIjozOTUsInJsIjoxLCJleHAiOjE1OTA1OTk3NDEsImlhdCI6MTU5MDU1NjU0MX0.T7JfooaVn90pmPxb0XW-YHw3srZ40qJxOMHzsVyBHqQ';

        if (authToken) {
            headers= headers.append('Authorization', 'Bearer ' + authToken);
        }
    // headers.append(environment.tokenHead, environment["authBearer"]);
    //  options = { 'headers': headers };
     return this.httpClient.
     get(this.url, { 'headers': headers })
     .pipe(map((res: Response) => res))

  }

}
