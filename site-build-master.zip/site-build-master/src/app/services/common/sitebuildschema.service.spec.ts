import { TestBed } from '@angular/core/testing';

import { SitebuildschemaService } from './sitebuildschema.service';

describe('SitebuildschemaService', () => {
  let service: SitebuildschemaService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SitebuildschemaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
