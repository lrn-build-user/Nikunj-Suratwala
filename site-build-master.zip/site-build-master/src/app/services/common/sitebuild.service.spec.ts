import { TestBed } from '@angular/core/testing';

import { SitebuildService } from './sitebuild.service';

describe('SitebuildService', () => {
  let service: SitebuildService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SitebuildService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
