import { Injectable } from "@angular/core";
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from "@angular/router";
import { AuthService } from "./authentication.service";
import { Observable, of } from 'rxjs';

@Injectable()
export class AuthenticatedGuard implements CanActivate {
    constructor(private authService: AuthService, private router: Router) { }

    canActivate(next: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
            // console.log(location.hostname.indexOf('localhost'));

        if (location.hostname.indexOf('localhost') !== -1) {
            return of(true);
        } else {
            return new Observable<any>((observer) => {
                this.authService.validateToken()
                    .then((data) => {
                        observer.next(true);
                        observer.complete();

                    })
                    .catch((error) => {
                        observer.next(false);
                        observer.complete();
                        console.log('Authentication failed:', error);
                    });

            })
        }

    }

}