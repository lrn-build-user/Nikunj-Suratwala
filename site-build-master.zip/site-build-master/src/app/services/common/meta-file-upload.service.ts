import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';
import { EnvironmentService } from './environment.service';
import * as $ from "jquery";

@Injectable({
providedIn: 'root'
})
export class FileUploadService {
	

	
constructor(private http:HttpClient, private environment: EnvironmentService) { }
// API url
baseApiUrl = this.environment.getBaseUrl() ;
absoluteUrl = this.environment.getAbsoluteUrl();
// Returns an observable
upload(file:any,company:any):Observable<any> {
	console.log("baseApiUrl is : "+this.baseApiUrl)
	
	let authToken;
	let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';
    if (authToken) {
      headers = headers.append('Authorization', 'Bearer ' + authToken);
    }
	// Create form data
	const formData = new FormData();
		
	// Store form name as "file" with file data
	formData.append("file", file, file.name);
	formData.append("company",company);	
	// Make http post request over api
	// with formData as req
	return this.http.post(this.baseApiUrl+"/upload", formData,{ 'headers': headers })
}

fetchFiles(company : any):Observable<any> {
	let authToken;
	let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';
    if (authToken) {
      headers = headers.append('Authorization', 'Bearer ' + authToken);
    }	
	return this.http.get(this.baseApiUrl+"/files",{ 'headers': headers })
}
fetchFilesVersions(company : any):Observable<any> {
	let authToken;
	let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';
    if (authToken) {
      headers = headers.append('Authorization', 'Bearer ' + authToken);
    }	
	return this.http.get(this.baseApiUrl+"/old/files",{ 'headers': headers })
}
fetchSPFiles(company : any):Observable<any> {
	let authToken;
	let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';
    if (authToken) {
      headers = headers.append('Authorization', 'Bearer ' + authToken);
    }	
	return this.http.get(this.baseApiUrl+"/sp/files",{ 'headers': headers })
}

generateSPmetadata(fileName : any,company : any):Observable<any> {
	let authToken;
	let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';
    if (authToken) {
      headers = headers.append('Authorization', 'Bearer ' + authToken);
    }	
	return this.http.get(this.baseApiUrl+"/generate/sp/files/"+fileName,{ 'headers': headers })
}

downloadFile(linkUrl:any, company : any) { 
	let authToken;
	let headers = new HttpHeaders();
    authToken = localStorage.getItem('auth') || '';
    if (authToken) {
      headers = headers.append('Authorization', 'Bearer ' + authToken);
	  headers = headers.append('responseType','blob' as 'json');
    }	
	return this.http.get(this.absoluteUrl+linkUrl,{'headers': headers,observe:'response',responseType:'blob' });
}
}
