import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule, APP_BASE_HREF } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { NgxLoaderModule } from '@tusharghoshbd/ngx-loader';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MatToolbarModule} from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTableModule } from '@angular/material/table';
import { MatRadioModule } from '@angular/material/radio';
import { MatProgressBarModule} from '@angular/material/progress-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { HttpClientModule } from '@angular/common/http';
import {MatExpansionModule} from '@angular/material/expansion';
import { from } from 'rxjs';
import { AuthenticatedGuard } from "./services/common/AuthenticatedGuard.service";
import { AuthService } from "./services/common/authentication.service";
import { environment } from '../environments/environment';

import { SitebuildComponent } from './sitebuild/sitebuild.component';
import { HeaderComponent } from './partial/header/header.component';
import {PartnerViewService} from './services/common/partnerview.service';
import {PartnerViewResolve } from './resolvers/PartnerViewResolve.resolver';
import { JSONService } from './services/common/json.service';
import { MaterialDesignFrameworkModule } from '@ajsf/material';
import { Bootstrap4FrameworkModule } from '@ajsf/bootstrap4';
import { FileUploadComponent } from './components/file-upload/file-upload.component';
import { DialogOverviewExampleDialog, UserDetailsComponent } from './components/user-details/user-details.component';
import { SiteBuildDetailsComponent } from './components/site-build-details/site-build-details.component';
import { LandingPageComponent } from './pages/landing-page/landing-page.component';
import { ChangesPopUpComponent, SiteCreatePageComponent, TimerPopUpComponent } from './pages/site-create-page/site-create-page.component';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CdkAccordionModule } from '@angular/cdk/accordion'; 
import { ScrollingModule } from '@angular/cdk/scrolling';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSelectModule } from '@angular/material/select';
import { LogoUploadComponent } from './components/logo-upload/logo-upload.component';
import { ToastComponent } from './components/toast/toast.component';
import { UnauthorizedComponent } from './components/unauthorized/unauthorized.component';
import { AuditLogsComponent, AuditLogsConfigsDisplayComponent, AuditLogsDialogComponent } from './components/audit-logs/audit-logs.component';
import { DecommissionSiteComponent } from './components/decommission-site/decommission-site.component';
import { SafeHtmlPipe } from './services/common/safe-html-pipe';
import { NewSiteComponent } from './components/new-site/new-site.component';
import { NewSiteStepperComponent } from './components/new-site-stepper/new-site-stepper.component';
import { MatStepperModule } from '@angular/material/stepper';
import { ErrorPageComponent } from './components/error-page/error-page.component';
import { DocumentationPageComponent } from './pages/documentation-page/documentation-page.component';
import { SiteRecreationComponent } from './components/site-recreation/site-recreation.component';
import { DataFilterComponent } from './components/data-filter/data-filter.component';
import { CustomRangePanelComponent } from './components/data-filter/custom-range-panel.component';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { DeploymentComponent, PopUpComponent } from './components/deployment/deployment.component';
import { NewFileUploadComponent } from './components/new-file-upload/new-file-upload.component';
import { DragDropDirective } from './directives/drag-drop.directive';
import { AccordianViewComponent } from './components/accordian-view/accordian-view.component';
import { BulkSiteCreateComponent } from './components/bulk-site-create/bulk-site-create.component';
import { PrintPdfComponent } from './components/print-pdf/print-pdf.component';
import { AdditionalConfigsComponent } from './components/additional-configs/additional-configs.component';
import { SiteSettingListComponent, SettingDeleteComponent } from './components/site-setting-list/site-setting-list.component';
import { SettingNameListComponent,SettingNameDialogComponent,SettingNameDeleteComponent } from './components/setting-name-list/setting-name-list.component';
import { SamlMetadataFileComponent } from './components/saml-metadata-file/saml-metadata-file.component';
// import { SiteConfigResolve } from './resolvers/SiteConfigResolve.resolver';


@NgModule({
  declarations: [
    AppComponent,
    SitebuildComponent,
    HeaderComponent,
    FileUploadComponent,
    UserDetailsComponent,
    SiteBuildDetailsComponent,
    LandingPageComponent,
    SiteCreatePageComponent,
    LogoUploadComponent,
    ToastComponent,
    UnauthorizedComponent,
    AuditLogsComponent,
    DecommissionSiteComponent,
    AuditLogsConfigsDisplayComponent,
    SafeHtmlPipe,
    NewSiteComponent,
    NewSiteStepperComponent,
    ErrorPageComponent,
    DialogOverviewExampleDialog,
    AuditLogsDialogComponent,
    ChangesPopUpComponent,
    PopUpComponent,
    TimerPopUpComponent,
    DocumentationPageComponent,
    SiteRecreationComponent,
    DataFilterComponent,
    DataFilterComponent,
    CustomRangePanelComponent,
    DeploymentComponent,
    NewFileUploadComponent,
    DragDropDirective,
    AccordianViewComponent,
    BulkSiteCreateComponent,
    PrintPdfComponent,
    SiteSettingListComponent,
    SettingNameListComponent,
    SamlMetadataFileComponent,
    SettingNameDialogComponent,
    SettingNameDeleteComponent,
    SettingDeleteComponent,
    AdditionalConfigsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatToolbarModule,
    MatIconModule,
    MatCardModule,
    MatTabsModule,
    MatRadioModule,
    MatFormFieldModule,
    ReactiveFormsModule,
    MatProgressSpinnerModule,
    MatProgressBarModule,
    HttpClientModule,
    CommonModule,
    FormsModule,
    Bootstrap4FrameworkModule,
    MaterialDesignFrameworkModule,
    DragDropModule,
    ScrollingModule,
    MatInputModule,
    MatCheckboxModule,
    MatSelectModule,
    MatStepperModule,
    CdkAccordionModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatAutocompleteModule,
    NgxLoaderModule,
    MatExpansionModule,
    MatTableModule
    // NgxPaginationModule
  ],
  providers: [{ provide: APP_BASE_HREF, useValue: '/' },
  { provide: AuthService, useClass: AuthService },
  { provide: AuthenticatedGuard, useClass: AuthenticatedGuard },
  PartnerViewResolve,
  { provide: PartnerViewService, useClass: PartnerViewService },
  { provide: JSONService, useClass: JSONService },
  { provide: "config", useValue: environment },
  SiteCreatePageComponent,
  NewSiteStepperComponent
],
  bootstrap: [AppComponent],
  entryComponents: [
    AuditLogsConfigsDisplayComponent, 
    SiteBuildDetailsComponent, 
    UserDetailsComponent, 
    DialogOverviewExampleDialog, 
    AuditLogsDialogComponent, 
    ChangesPopUpComponent,
    PopUpComponent,
    TimerPopUpComponent,
    DataFilterComponent,
    CustomRangePanelComponent,
    PrintPdfComponent,
    SiteSettingListComponent,
    SettingNameDialogComponent,
    SettingNameDeleteComponent,
    SettingDeleteComponent
  ]

})
export class AppModule { }

