import { Component, Inject, OnInit } from '@angular/core';
import { JSONService } from '../../services/common/json.service';
import { DataService } from '../../services/data.service';
import { SharedDataService } from '../../services/shared-data.service';
import Swal from 'sweetalert2'
import { EnvironmentService } from '../../services/common/environment.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../services/common/authentication.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-site-create-page',
  templateUrl: './site-create-page.component.html',
  styleUrls: ['./site-create-page.component.css']
})
export class SiteCreatePageComponent implements OnInit {

  constructor(
    private dataService: DataService,
    private sharedDataService: SharedDataService,
    private jsonService: JSONService,
    private envService: EnvironmentService,
    public route: ActivatedRoute,
    public router: Router,
    public authService: AuthService,
    private dialog: MatDialog
  ) { }

  resultApi = null;
  finalConfigForm = null;
  finalUserForm = null;
  previousConfigs = null;
  removedFields = [];
  submitLoading = null;
  displayNameColumnNameMap = {};
  userCustomFieldsArray = [];
  atTheBottom = false;
  atTheTop = false;
  selectedTabIndex = 0;
  largeLogoStatus = null;
  smallLogoStatus = null;
  configsFromDraft = [];

  isAdditionalConfigsAdded = false;

  additionalConfigs = null;
  tempAdditionalConfigs = {};
  visited = false;

  defaultConfigs = {
    "allowSAMLSuperUserAccess": false,
    "allowSAMLLRNUserAccess": false,
    "allowNewCertificationManager": false,
    "showLegacyFilter": false,
    "allowContentManager": true,
    "allowCatalystConnect": false,
    "isSalesSite": false,
    "allowNewCampaignManager": true
  }

  columnNameMap = {
    "COLUMN_NAME": `Mapping Field`,
    "DISPLAY_NAME": `Screen Label`,
    "REPORT_POSITION": 'Field Position',
    "SEARCH_CRITERIA": 'Filter In Reports',
    "PRIVILEGE_VISIBILITY_LEVEL": 'Hide in User Profile',
    "REQUIRED_FIELD": 'Required Field?',
    "PROTECTED_FIELD": 'Protected Field?',
    "FIELD_FORMAT": 'Field Format (Regex)',
    "BULKLOAD_MAPPING": `Header Label`,
    "MAX_LENGTH": 'Maximum Length',
    "SIZE": 'Field Size',
    "DROPDOWN_ENUM": "Dropdown Values"
  };

  emailConfigType = ['Webmaster', 'BulkloadEmailSender'];
  pendingLogs = false;
  siteName = '';

  newConsoleApi = '';

  ngOnInit(): void {
    this.getTabIndexFromLocalStorage();
    this.scrollToTop();

    this.newConsoleApi = this.envService.getAbsoluteUrl() + `/newconsole/api/public/initiateSite`;

    if (this.envService.getAbsoluteUrl().includes("internal.catalyst")) {
      this.router.navigate(['/site-build/internal']);
      return;
    }

    this.getCofigData();
    this.sharedDataService.getConfigSchemaData().subscribe((result) => {
      this.finalConfigForm = result;
    });
    this.sharedDataService.getUserSchemaData().subscribe((result) => {
      this.finalUserForm = result;
    });
    this.userCustomFieldsArray = this.sharedDataService.getCustomColumnsOrder();
    this.sharedDataService.getRemovedFields().subscribe(vals => {
      this.removedFields = vals;
    });
    this.sharedDataService.getPendingLogsStatus().subscribe(status => {
      this.pendingLogs = status;
    });
    this.sharedDataService.getAdditionalConfigs().subscribe((result) => {
      this.additionalConfigs = result;
    });
    this.sharedDataService.getLargeLogoStatus().subscribe((status) => {
      this.largeLogoStatus = status;
    });
    this.sharedDataService.getSmallLogoStatus().subscribe((status) => {
      this.smallLogoStatus = status;
    });
    this.sharedDataService.getSiteConfigDraftChanges().subscribe((res) => {
      console.log("Config draft changes from site create: ", res);
    });
    this.scrollToTop();
  }

  clone(obj) {
    if (obj == null || typeof obj != "object") return obj;

    var temp = new obj.constructor();
    for (var key in obj) temp[key] = this.clone(obj[key]);

    return temp;
  }

  transformCustomUserData = (userData) => {
    const newTempObj = this.clone(userData);
    if (userData && userData['custom_field']) {
      userData['custom_field'].forEach((customField) => {
        newTempObj[customField.COLUMN_NAME] = customField;
      });
      delete newTempObj['custom_field'];
    }
    return newTempObj;
  }

  onChange(item){
    if(!this.visited){
      for(var i in this.additionalConfigs){
        var key = this.additionalConfigs[i].key;
        this.defaultConfigs[key] = this.additionalConfigs[i].value;
      }
      this.visited = true;
    }
    item.value = !item.value;
    this.tempAdditionalConfigs[item.key] = item.value;
  }

  getCofigData() {
    this.dataService.getConfigsForASite().subscribe((result) => {
      this.resultApi = result;
      this.previousConfigs = this.clone(result.data);
      this.sharedDataService.setSiteId(this.resultApi.data.site_id);
      this.sharedDataService.getConfigSchemaData().next(this.resultApi.data.site_configs);
      this.sharedDataService.getUserSchemaData().next(this.resultApi.data.user_configs);
      this.sharedDataService.getCompleteSchema().next(this.resultApi.schema);
      this.sharedDataService.getSchemaApiResult().next(this.resultApi);
      this.sharedDataService.getAdditionalConfigs().next(this.resultApi.data.additional_configs);
    }, (error) => {
      if (error && error.status === 401) {
        location.pathname = "/site-build/unauthorized";
      } else {
        this.router.navigateByUrl('/error');
      }
    });
  }

  mapDisplayNameWithColumnName(userConfigs) {
    if (userConfigs) {
      Object.keys(userConfigs).forEach(field => {
        if(field !== 'custom_field') {
          this.displayNameColumnNameMap[field] = userConfigs[field]['DISPLAY_NAME'];
        }
      });
      if (userConfigs['custom_field']) {
        userConfigs['custom_field'].forEach(customFieldObj => {
          this.displayNameColumnNameMap[customFieldObj['COLUMN_NAME']] = customFieldObj['DISPLAY_NAME'];
        });
      }
    }
  };

  splitLanguageField(language){
    if (language && language.includes("-")) {
      const result=language.split("- ");
      return result[1];
    } else {
      return language;
    }
  }

  validateFormData(diff, prevConfigs, resultApi) {
    let htmlString = '';
    let status = true;

    if (!resultApi) {
      resultApi = this.resultApi;
    }
    if (diff.site_configs !== null && diff.site_configs !== undefined) {
      const siteConfigsHeading = '<h3>Site Configs</h3>';
      const siteConfigs = diff.site_configs;
      for(let field in siteConfigs) {
        const configValue = (typeof siteConfigs[field] === 'string') ? siteConfigs[field].trim() : siteConfigs[field];
        if ((configValue === '' || configValue === undefined) && field !== 'ProfileColumn' && field !== 'DMARCDomains') {
          status = false;
          if (!htmlString.includes(siteConfigsHeading)) {
            htmlString += siteConfigsHeading;
          }
          htmlString += `<div><b>${resultApi.schema.properties.site_configs.properties[field].title}</b> should not be empty</div>`;
        }
        if (this.emailConfigType.includes(field)) {
          const regex = new RegExp('^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+[.]{1}[a-zA-Z]+$');
          if (!regex.test(configValue) && (configValue !== undefined && configValue !== null && configValue !== '')) {
            status = false;
            if (!htmlString.includes(siteConfigsHeading)) {
              htmlString += siteConfigsHeading;
            }
            htmlString += `<div><b>${resultApi.schema.properties.site_configs.properties[field].title}</b> should be in a proper e-mail format</div>`;
          }
        }
      }
    }

    if (diff.user_configs !== null && diff.user_configs !== undefined) {
      const userConfigHeading = '<h3>User Configs</h3>';
      const userConfigs = diff.user_configs;

      const customColumnNameMap = () => {
        const map = {};
        const customFields = prevConfigs['custom_field'] ? prevConfigs['custom_field'] : [];
        customFields.forEach((eachField) => {
          map[eachField['COLUMN_NAME']] = eachField['DISPLAY_NAME'];
        });
        return map;
      };

      const columnMap = customColumnNameMap();

      // Checking Duplicate data fields
      const duplicateFields = [];

      Object.keys(userConfigs).forEach((field, i) => {
        Object.keys(userConfigs).forEach((field2, j) => {
          if (i !== j && field2 !== field && (userConfigs[field]['DISPLAY_NAME'].trim() === userConfigs[field2]['DISPLAY_NAME'].trim() || userConfigs[field]['BULKLOAD_MAPPING'].trim() === userConfigs[field2]['BULKLOAD_MAPPING'].trim())) {
            status = false;
            if (duplicateFields.indexOf(userConfigs[field]['DISPLAY_NAME'].trim()) === -1) {
              duplicateFields.push(userConfigs[field]['DISPLAY_NAME'].trim());
            }
          }
        });
      });

      duplicateFields.forEach(field => {
        if (!htmlString.includes(userConfigHeading)) {
          htmlString += userConfigHeading;
        }
        const msg = `<div>There are two data fields with the same name <b>${field}</b>. Please change the name of one of them</div>`;
        if (!htmlString.includes(msg) && field !== undefined && field !== '' && field !== null) {
          htmlString += msg;
        }
      });


      // Checking for empty data fields
      const ignoreColumns = ['REPORT_POSITION','SOURCE_OF_DATA','INSTRUCTION_TEXT','SIZE', 'COLUMN_NAME', 'ATTRIBUTE_TYPE', 'FIELD_TYPE', 'MAPPED_FIELD_NAME',
      'FIELD_DISPLAY_NAME', 'FIELD_POSITION', 'FIELD_MATCH', 'FIELD_NAME', 'FIELD_LENGTH', 'DROPDOWN_ENUM'];
      const requiredColumns = ['DISPLAY_NAME', 'MAX_LENGTH', 'FIELD_FORMAT'];
      let index = 0;
      for(let field in userConfigs) {
        index++;
        for(let column in userConfigs[field]) {
          if ((requiredColumns.includes(column)) && (userConfigs[field][column] === undefined || userConfigs[field][column] === null || (this.columnNameMap[column] && userConfigs[field][column].toString().trim() === ''))) {
            status = false;
            if (!htmlString.includes(userConfigHeading)) {
              htmlString += userConfigHeading;
            }
            htmlString += `<div><b>${this.columnNameMap[column]}</b> should not be empty for <b>Field ${index}</b></div>`;
          }
        }
      }
    }

    return {
      string: htmlString,
      status: status
    }
  };

  buildDifferenceString(diff, prevDiff, currentConfigs, previousConfigs, prevConfigsCustom, resultApi) {
    const validateResult = this.validateFormData(currentConfigs, prevConfigsCustom, resultApi);
    if (!validateResult.status) {
      return validateResult.string;
    }

    let finalString = '';
    finalString += '<table>'

    /* if (this.sharedDataService.getLargeLogoStatus() || this.sharedDataService.getSmallLogoStatus()) {
      finalString+= '<tr><th style="text-align:center"><div style="margin-top:15px;font-weight:bold; font-size:14px">LOGO UPDATES</div></th></tr>';
      if(this.sharedDataService.getLargeLogoStatus()){
        finalString += `<tr style="padding:5px;"><td style="padding: 5px;text-align:left; width:250px"><div style="font-size:12px; font-weight:500">Large Logo Uploaded</div></td></tr>`;
      }
      if(this.sharedDataService.getSmallLogoStatus()){
        finalString += `<tr style="padding:5px;"><td style="padding: 5px;text-align:left; width:250px"><div style="font-size:12px; font-weight:500">Small Logo Uploaded</div></td></tr>`;
      }
    } */

    if ((!this.smallLogoStatus && !this.largeLogoStatus) && (finalString === '<table>') && (((diff === null || diff === {} || (diff && Object.keys(diff).length === 0)) && (prevDiff === null || prevDiff === {} || (prevDiff && Object.keys(prevDiff).length === 0))) )) {
      return null;
    }
    if (diff.site_configs !== null && diff.site_configs !== undefined) {
      const siteConfigsHeading = '<tr><th style="text-align:left"><div style="font-weight:bold; font-size:16px">Site App Config</div></th></tr>';
      const siteConfigs = diff.site_configs;
      for(let field in siteConfigs) {
        if (resultApi.schema.properties.site_configs.properties[field]) {
          if (!finalString.includes(siteConfigsHeading)) {
            finalString += siteConfigsHeading;
          finalString+=`<tr style="padding:5px;"><td style="padding: 5px;text-align:left; width:250px"><div style="font-size:14px; font-weight:600">Field</td><td style="padding: 5px; font-size:14px; font-weight:600">Current Value</div></td></tr>`
          }
          if (field === 'ProfileColumn') {
            finalString += `<tr style="padding:5px;"><td style="padding: 5px;text-align:left; width:250px; "><div style="font-size:12px; font-weight:500;">Internationalization:</td><td style="padding: 5px;text-align:left;">${siteConfigs[field] ? siteConfigs[field] : 'disabled'}</div></td></tr>`;
          } else {
            finalString += `<tr style="padding:5px;"><td style="padding: 5px;text-align:left; width:250px"><div style="font-size:12px; font-weight:500;">${resultApi.schema.properties.site_configs.properties[field].title}:</td><td style="padding: 5px;text-align:left;">${siteConfigs[field]}</div></td></tr>`;
          }
        }
      }
    }
    if ((diff.user_configs !== null && diff.user_configs !== undefined) || (prevDiff && prevDiff.user_configs !== null && prevDiff.user_configs !== undefined)) {
      const userConfigHeading = '<tr><th style="text-align:right color: #000000"><div style="margin-top:15px;font-weight:600; font-size:16px">User Data Fields</div></th></tr>';
      const userConfigs = diff.user_configs;

      for(let field in userConfigs) {
        const fieldName = this.displayNameColumnNameMap[field] ? this.displayNameColumnNameMap[field] :userConfigs[field]['DISPLAY_NAME'];
        if (field && userConfigs[field] && userConfigs[field]['ADDED_ELEMENT'] === true) {
          if (!finalString.includes(userConfigHeading)) {
            finalString += userConfigHeading;
          }
          finalString += `<tr style="padding:5px; color: #1B242B"><td style="text-align:left; width:250px"><div style="font-size:14px; font-weight: 500">Added user field <b>${fieldName}</b></div></td></tr>`;
        }
      }

      const currentDiffDisplayNameArray = [];
      const prevDiffDisplayNameArray = [];

      Object.keys(currentConfigs.user_configs).forEach(key => {
        currentDiffDisplayNameArray.push(currentConfigs['user_configs'][key]['DISPLAY_NAME']);
      });
      Object.keys(previousConfigs.user_configs).forEach(key => {
        prevDiffDisplayNameArray.push(previousConfigs['user_configs'][key]['DISPLAY_NAME']);
      });

      if (prevDiff !== null && prevDiff.user_configs !== null && prevDiff.user_configs !== undefined && this.removedFields.length > 0) {
        this.removedFields.forEach(field => {
          if (prevDiffDisplayNameArray.includes(field) && !currentDiffDisplayNameArray.includes(field)) {
            finalString += `<tr><td style="font-size: 14px; float:left; color: #1B242B">Removed the field <b>${field}</b></td></tr>`
          }
        });
      }

      for(let field in userConfigs) {
        const fieldName = this.displayNameColumnNameMap[field] ? this.displayNameColumnNameMap[field] :userConfigs[field]['DISPLAY_NAME'];
        if (userConfigs[field] && userConfigs[field]['ADDED_ELEMENT'] === undefined) {
          if (!finalString.includes(userConfigHeading)) {
            finalString += userConfigHeading;
            finalString += `<tr style="padding:5px; color: #1B242B"><td style="text-align:left; width:250px"><div style="font-size:14px; font-weight: 600">Field</div></td><td style="text-align:left; width:250px"><div style="font-size:14px; font-weight: 600">User Configuration</div></td><td style="text-align:left; width:250px"><div style="font-size:14px; font-weight: 600">Current Value</div></td></tr>`
          }
          finalString += `<tr style="padding:5px; color: #1B242B"><td style="text-align:left; width:250px"><div style="font-size:14px; font-weight: 400">${fieldName}</div></td>`;
          for(let column in userConfigs[field]) {
            if (this.columnNameMap[column]) {
              finalString += `<td style="padding: 5px;text-align:left; width:200px; color: #1B242B"><div style="font-size:14px;">${this.columnNameMap[column]}:</td><td style="padding: 5px;text-align:left"><span style="color:#1B242B">${prevDiff && prevDiff.user_configs && prevDiff.user_configs[field] &&  prevDiff.user_configs[field][column] ? prevDiff.user_configs[field][column] : 'null'}</span> ${prevDiff && prevDiff.user_configs ? '--->' : ''} <span style="color:#1B242B">${userConfigs[field][column]}</span></div></td>`;
              finalString += `<tr style="padding:5px; color: #964303"><td style="text-align:left; width:250px"><div style="font-size:14px; font-weight: 500;" hidden="true">${fieldName}</div></td>`;
            }
          }
          finalString+= '</tr>'
        }
      }
    }

    if (this.smallLogoStatus || this.largeLogoStatus) {
      finalString += '<tr><th style="text-align:left"><div style="font-weight:600; font-size:16px">Logo Uploads</div></th></tr>';
      if (this.smallLogoStatus) {
        finalString += `<tr><td style="padding: 5px; font-size: 14px; float:left;">Small Logo Added</td></tr>`;
      }
      if (this.largeLogoStatus) {
        finalString += `<tr><td style="padding: 5px; font-size: 14px; float:left;">Large Logo Added</td></tr>`
      }
    }

    finalString += '</table>'
    return finalString;
  }

  buildDiffStringforAdditionalConfigs(configs){
    var diffString = '';
    diffString += '<table>'
    if(configs !== null || configs !== undefined){
      var heading = '<tr><th style="text-align:center"><div style="font-weight:bold; font-size:14px">ADDITIONAL CONFIGS</div></th></tr>';
      Object.keys(configs).forEach(key => {
        if(key !== 'siteId'){
          if(!diffString.includes(heading)){
            diffString += heading;
          }
          diffString += `<tr style="padding:5px;"><td style="padding: 5px;text-align:left; width:250px"><div style="font-size:12px; font-weight:500">     ${key}</td><td style="padding: 5px;text-align:left;">${configs[key]}\n</div></td></tr>`;
        }
      })
    }
    if(diffString === '' || diffString === '<table>'){
      diffString = null;
    } else {
      diffString += '</table>'
    }

    return diffString;
  }

  deleteConfigsFromDiff(diff) {
    const newDiff = this.clone(diff);
    delete newDiff['site_configs'].SiteURL;
    delete newDiff['site_configs'].AllowSelfReg;
    delete newDiff['site_configs'].AllowSelfEdit;
    delete newDiff['site_configs'].AutoBulkload;
    // delete newDiff['site_configs'].CourseAkamai;
    delete newDiff['site_configs'].CumulativeTimeTracking;
    // delete newDiff['site_configs'].CompletionCertificate;
    // delete newDiff['site_configs'].DriveAssignment;
    delete newDiff['site_configs'].internationalize_site;
    delete newDiff['site_configs'].DefaultViewAllModules;
    delete newDiff['site_configs'].ProfileColumnDefault;
    delete newDiff['site_configs'].SSLRequire;
    delete newDiff['site_configs'].SSOEnabled;
    delete newDiff['site_configs'].SiteCustomizer;
    return newDiff;
  }

  handleDefaultConfigs(params) {
    const reqBodyParams = this.clone(params);
    // reqBodyParams.currentConfig.site_configs['CourseAkamai'] = true;
    // reqBodyParams.currentConfig.site_configs['SSLRequire'] = true;
    // reqBodyParams.currentConfig.site_configs['DriveAssignment'] = true;
    // reqBodyParams.currentConfig.site_configs['CompletionCertificate'] = true;
    // reqBodyParams.currentConfig.site_configs['SiteCustomizer'] = true;
    delete reqBodyParams.currentConfig.site_configs['SiteURL'];
    delete reqBodyParams.currentConfig.site_configs['internationalize_site'];
    // reqBodyParams.currentConfig.site_configs['DefaultViewAllModules'] = false;
    // reqBodyParams.currentConfig.site_configs['CumulativeTimeTracking'] = true;
    reqBodyParams.currentConfig.site_configs['ProfileColumnDefault'] = reqBodyParams.currentConfig.site_configs['DefaultLanguage'];
    const type_1 = 'Type 1 (Client uploading users via files through Bulkload Manager)';
    const type_2 = 'Type 2 (Initial bulkload and then Self-register)';
    if(reqBodyParams.currentConfig.site_configs['RegistrationType'] === undefined){
      reqBodyParams.currentConfig.site_configs['RegistrationType'] = type_1;
    }
    if(reqBodyParams.currentConfig.site_configs['RegistrationType'] === type_1){
      reqBodyParams.currentConfig.site_configs['AllowSelfReg'] = false;
      reqBodyParams.currentConfig.site_configs['AutoBulkload'] = true;
      reqBodyParams.currentConfig.site_configs['AllowSelfEdit'] = false;
    } else if(reqBodyParams.currentConfig.site_configs['RegistrationType'] === type_2){
      reqBodyParams.currentConfig.site_configs['AllowSelfReg'] = true;
      reqBodyParams.currentConfig.site_configs['AutoBulkload'] = true;
      reqBodyParams.currentConfig.site_configs['AllowSelfEdit'] = true;
    } else {
      reqBodyParams.currentConfig.site_configs['AllowSelfReg'] = true;
      reqBodyParams.currentConfig.site_configs['AutoBulkload'] = false;
      reqBodyParams.currentConfig.site_configs['AllowSelfEdit'] = true;
    }
    if(reqBodyParams.currentConfig.site_configs['silent_logon'] === 'Silent Logon Only'){
      reqBodyParams.currentConfig.site_configs['SSOEnabled'] = 'only';
    } else if(reqBodyParams.currentConfig.site_configs['silent_logon'] === 'Conventional'){
      reqBodyParams.currentConfig.site_configs['SSOEnabled'] = false;
    } else if (reqBodyParams.currentConfig.site_configs['silent_logon'] === 'Silent Logon and Conventional'){
      reqBodyParams.currentConfig.site_configs['SSOEnabled'] = true;
    }
    reqBodyParams.currentConfig.user_configs['Login_name']['REQUIRED_FIELD'] = true;
    reqBodyParams.currentConfig.user_configs['Password']['REQUIRED_FIELD'] = true;

    return reqBodyParams;
  }

  addEnglishLanguage(params) {
    const newParams = this.clone(params);
    const customFields = newParams.currentConfig.user_configs['custom_field'];
    let languageIndex = -1;
    customFields.forEach((eachField, index) => {
      if (eachField.COLUMN_NAME === 'Language') {
        languageIndex = index;
      }
    });
    if (languageIndex !== -1) {
      let dropDownVal = newParams.currentConfig.user_configs['custom_field'][languageIndex]['DROPDOWN_ENUM'];
      if (!dropDownVal) {
        dropDownVal = "English - en";
      } else {
        if (!dropDownVal.includes('English - en')) {
          dropDownVal += ', "English - en"';
        }
      }
      newParams.currentConfig.user_configs['custom_field'][languageIndex]['DROPDOWN_ENUM'] = dropDownVal;
    }

    const dropDownValueFinal = (languageIndex !== -1) ? newParams.currentConfig.user_configs['custom_field'][languageIndex]['DROPDOWN_ENUM'] : '';
    // if (!dropDownValueFinal.includes(newParams.currentConfig.site_configs.DefaultLanguage)) {
    //   newParams.currentConfig.site_configs.DefaultLanguage = 'English - en';
    // }
    return newParams;
  }

  updateDropdownValues(userConfigs) {
    userConfigs['custom_field'].forEach((field) => {
      if (field['FIELD_FORMAT'].includes("YY")) {
        field['DROPDOWN_ENUM'] = "";
      }
    });
    return userConfigs;
  }

  protectConfigValues(siteConfigs) {
    Object.keys(siteConfigs).forEach(key => {
      if (typeof siteConfigs[key] !== 'boolean') {
        if (siteConfigs[key]) {
          siteConfigs[key] = siteConfigs[key].replace(/<\/?[^>]+(>|$)/g, "").replace(/(\r\n|\r|\n){2}/g, '');
        }
      }
    });
    return siteConfigs;
  };

  updateDefaultLanguage(siteConfigs, userConfigs) {
    let languageDropdownValue = null;
    userConfigs['custom_field'].forEach(field => {
      if (field['COLUMN_NAME'] === 'Language') {
        if (field['DROPDOWN_ENUM']) {
          languageDropdownValue = field['DROPDOWN_ENUM'];
        }
      }
    });
    if (languageDropdownValue && !languageDropdownValue.includes(siteConfigs['DefaultLanguage'])) {
      siteConfigs['DefaultLanguage'] = "English - en";
      siteConfigs['ProfileColumnDefault'] = "en";
    }
    return siteConfigs;
  };

  submitForm(status) {
    const siteId = this.sharedDataService.getSiteId();
    this.finalConfigForm = this.updateDefaultLanguage(this.finalConfigForm, this.finalUserForm);
    this.finalConfigForm = this.protectConfigValues(this.finalConfigForm);

    var isAdditionalConfigsChanged = false;
    var updatedAdditionalConfigs = {
      "siteId": siteId,
    }

    for(var config in this.additionalConfigs){
      var configKey = this.additionalConfigs[config].key;
      if(this.additionalConfigs[config].value !== this.defaultConfigs[configKey] && configKey in this.tempAdditionalConfigs){
        updatedAdditionalConfigs[this.additionalConfigs[config].key] = this.tempAdditionalConfigs[configKey];
        this.isAdditionalConfigsAdded = true;
      }
    }

    Object.keys(updatedAdditionalConfigs).forEach(key => {
      if(key !== 'siteId'){
        isAdditionalConfigsChanged = true;
      }
    })

    const finalForm = {
      "site_id": siteId,
      "user_configs": this.finalUserForm,
      "site_configs": this.finalConfigForm
    }
    let reqBodyParams = {
      "status": status ? status : 'SUBMIT',
      "currentConfig": finalForm,
      "previousConfig": this.previousConfigs,
      "additionalConfigs": updatedAdditionalConfigs
    }

    const tempDiffObjectPrevious = {
      "site_id": siteId,
      "user_configs": this.transformCustomUserData(this.previousConfigs['user_configs']),
      "site_configs": this.previousConfigs['site_configs']
    };

    const tempDiffObjectCurrent = {
      "site_id": siteId,
      "user_configs": this.transformCustomUserData(this.finalUserForm),
      "site_configs": this.finalConfigForm
    };

    var siteDetails = {
      siteId : siteId,
      additionalConfigs : isAdditionalConfigsChanged
    }
    this.mapDisplayNameWithColumnName(this.finalUserForm);
    let diff = this.jsonService.getObjectDiff(tempDiffObjectPrevious, tempDiffObjectCurrent, false);
    const prevDiff = this.jsonService.getObjectDiff(tempDiffObjectCurrent, tempDiffObjectPrevious, false);

    if(diff && diff['site_configs']) {
      diff = this.deleteConfigsFromDiff(diff);
    }

    if(diff && diff['site_configs'] && Object.keys(diff['site_configs']).length === 0) {
      delete diff['site_configs'];
    }

    // const diffString = this.buildDifferenceString(diff);
    var diffString = this.buildDifferenceString(diff, prevDiff, tempDiffObjectCurrent, tempDiffObjectPrevious, this.previousConfigs['user_configs'], this.resultApi);

    if(this.isAdditionalConfigsAdded){
      const diffStringforAdditionalConfigs = this.buildDiffStringforAdditionalConfigs(updatedAdditionalConfigs);
      if(diffString === null) {
        diffString = diffStringforAdditionalConfigs;
      } else if( diffStringforAdditionalConfigs !== null) {
        diffString += diffStringforAdditionalConfigs;
      }
    }

    const dialogRef = this.dialog.open(ChangesPopUpComponent, {
      maxWidth: '850px',
      maxHeight: '600px',
      autoFocus: false,
      data: { diffString: diffString, diff, prevDiff, tempDiffObjectCurrent, tempDiffObjectPrevious, 
        previousConfigs: this.previousConfigs['user_configs'], resultApi: this.resultApi, removedFields: this.removedFields,
        additionalConfigsChanges: this.isAdditionalConfigsAdded, additionalConfigs: updatedAdditionalConfigs, largeLogo: this.largeLogoStatus,
        smallLogo: this.smallLogoStatus, newSiteCreation: false
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result?.submitted) {
        reqBodyParams = this.handleDefaultConfigs(reqBodyParams);
        reqBodyParams = this.addEnglishLanguage(reqBodyParams);
        reqBodyParams['changesString'] = diffString;
        reqBodyParams['siteDetails'] = siteDetails;
        reqBodyParams['logosUpdated'] = this.smallLogoStatus || this.largeLogoStatus;
        this.submitLoading = true;
        this.dataService.saveSchemaDetails(reqBodyParams).subscribe(response => {
          this.previousConfigs = reqBodyParams.currentConfig;
          this.submitLoading = false;
          const timerDialog = this.dialog.open(TimerPopUpComponent, {
            maxWidth: '850px',
            maxHeight: '350px',
            data: { timer: 5, status: true }
          });

          timerDialog.afterClosed().subscribe(() => {
            location.reload();
          });
        }, err => {
            console.log('There is some error. Uh oh', err);
            const timerDialog = this.dialog.open(TimerPopUpComponent, {
              maxWidth: '850px',
              maxHeight: '350px',
              data: { timer: 5, status: false }
            });

            timerDialog.afterClosed().subscribe(() => {
              this.authService.login();
            });
        });
      }
    });
  }

  enableConsoleSite() {
    this.dataService.enableNewConsoleSite().subscribe(response => {
      const timerDialog = this.dialog.open(TimerPopUpComponent, {
        maxWidth: '850px',
        maxHeight: '350px',
        data: { timer: 5, status: true, message: 'Enabling New Console Site...' }
      });

      timerDialog.afterClosed().subscribe(() => {
        location.reload();
      });
    }, err => {
        console.log('There is some error. Uh oh', err);
        const timerDialog = this.dialog.open(TimerPopUpComponent, {
          maxWidth: '850px',
          maxHeight: '350px',
          data: { timer: 5, status: false }
        });

        timerDialog.afterClosed().subscribe(() => {
          this.authService.login();
        });
    });
    
  }

  scrollToTop() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
    this.atTheTop = true;
    this.atTheBottom = false;
  }

  scrollToBottom() {
    document.body.scrollTop = document.body.scrollHeight;
    document.documentElement.scrollTop = document.body.scrollHeight;
    this.atTheBottom = true;
    this.atTheTop = false;
  }

  handleScrollingOnPage(event) {
    if (event && event.path && event.path[0].className.includes('mat-tab-label')) {
      this.scrollToTop();
    }
  }

  onScroll(event) {
    const scrollTop = event.target.scrollingElement.scrollTop;
    const scrollHeight = event.target.scrollingElement.scrollHeight;
    const limit = scrollHeight - scrollTop;
    this.atTheBottom = false;
    this.atTheTop = false;
    if (scrollTop === 0 ) {
      this.atTheTop = true;
    }
    if (scrollTop >= limit-1) {
      this.atTheBottom = true;
    }
  }

  onTabChange(tabIndex) {
    this.selectedTabIndex = tabIndex;
    localStorage.setItem('tabIndex', tabIndex.toString());
  }

  getTabIndexFromLocalStorage() {
    this.selectedTabIndex = parseInt(localStorage.getItem('tabIndex'));
  }
}

export interface DialogData {
  diffString: any,
  diff: any,
  prevDiff: any,
  tempDiffObjectCurrent: any,
  tempDiffObjectPrevious: any,
  previousConfigs: any,
  removedFields: any,
  resultApi: any,
  additionalConfigsChanges: any,
  additionalConfigs: any,
  largeLogo: any,
  smallLogo: any,
  newSiteCreation: any
}
@Component({
  selector: 'changes-pop-up',
  templateUrl: './changes-pop-up.html'
})
export class ChangesPopUpComponent implements OnInit {
  ngOnInit(): void {
    delete this.data.additionalConfigs.siteId;
  };
  constructor(public dialogRef: MatDialogRef<ChangesPopUpComponent>,
    public siteCreateComponent: SiteCreatePageComponent,
    @Inject(MAT_DIALOG_DATA) public data: DialogData){}

  additionalConfigsDetails ={
      "allowNewCertificationManager":"New Certification Manager",
      "showLegacyFilter":"Legacy Filter",
      "allowContentManager":"Content Manager",
      "allowCatalystConnect":"Catalyst Connect"
  };
  userFieldsToIgnore = ['SOURCE_OF_DATA','INSTRUCTION_TEXT','SIZE', 'ATTRIBUTE_TYPE', 'FIELD_TYPE', 'FIELD_DISPLAY_NAME', 'FIELD_POSITION', 'FIELD_MATCH', 'FIELD_NAME', 'FIELD_LENGTH', 'MAPPED_FIELD_NAME'];
  siteConfigsDiffs = this.data.diff.site_configs ? this.data.diff.site_configs : null;
  userConfigsDiffs = this.data.diff.user_configs ? this.data.diff.user_configs : null;
  largeLogoStatus = this.data.largeLogo;
  smallLogoStatus = this.data.smallLogo;
  noChanges = ((this.data.diff === null || (this.data.diff && Object.keys(this.data.diff).length === 0)) && (this.data.prevDiff === null || (this.data.prevDiff && Object.keys(this.data.prevDiff).length === 0)) && (!this.largeLogoStatus && !this.smallLogoStatus));
  siteChanges = this.data.diff.site_configs !== null && this.data.diff.site_configs !== undefined;
  userChanges = (this.data.diff.user_configs !== null && this.data.diff.user_configs !== undefined) || (this.data.prevDiff && this.data.prevDiff.user_configs !== null && this.data.prevDiff.user_configs !== undefined);
  removedUsersConfigs = this.data.prevDiff !== null && this.data.prevDiff.user_configs !== null && this.data.prevDiff.user_configs !== undefined && this.data.removedFields.length > 0;
  validateResult = this.siteCreateComponent.validateFormData(this.data.tempDiffObjectCurrent, this.data.previousConfigs, this.data.resultApi);
  additionalConfigs = this.data.additionalConfigs;
  fromNewSiteCreation = this.data.newSiteCreation;

  onButtonClick(val) {
    this.dialogRef.close({ submitted: val });
  }  
}

export interface DialogData {
  timer: number,
  status: boolean,
  message: string
}
@Component({
  selector: 'timer-pop-up',
  templateUrl: './timer-pop-up.html'
})
export class TimerPopUpComponent implements OnInit {
  ngOnInit(): void {
    this.countDownTimer();
  };
  constructor(public dialogRef: MatDialogRef<ChangesPopUpComponent>,
    public siteCreateComponent: SiteCreatePageComponent,
    @Inject(MAT_DIALOG_DATA) public data: DialogData){}

  timerSeconds = this.data.timer;
  message = this.data.message;

  countDownTimer() {
    const timerInterval = setInterval(() => {
      if (this.timerSeconds === 1) {
        clearInterval(timerInterval);
        this.dialogRef.close({});
      }
      this.timerSeconds = this.timerSeconds-1;
    }, 1000);
  }
}