import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-documentation-page',
  templateUrl: './documentation-page.component.html',
  styleUrls: ['./documentation-page.component.css']
})
export class DocumentationPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
